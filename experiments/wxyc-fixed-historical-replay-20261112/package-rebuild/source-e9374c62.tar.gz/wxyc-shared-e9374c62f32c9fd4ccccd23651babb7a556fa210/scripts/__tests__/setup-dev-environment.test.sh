#!/usr/bin/env bats
#
# BATS tests for setup-dev-environment.sh
#
# Run with: npm run test:setup-script
# Or directly: bats scripts/__tests__/setup-dev-environment.test.sh
#
# These tests verify argument parsing, dependency checks, and environment
# variable handling WITHOUT actually cloning repositories or starting services.

# Get the directory containing the script under test
SCRIPT_DIR="$(cd "$(dirname "$BATS_TEST_FILENAME")/.." && pwd)"
SCRIPT_PATH="$SCRIPT_DIR/setup-dev-environment.sh"

# Helper to source only the functions we need to test
setup() {
    # Create a temporary directory for test artifacts
    TEST_TEMP_DIR="$(mktemp -d)"
    export WXYC_DEV_ROOT="$TEST_TEMP_DIR"
}

teardown() {
    # Clean up temporary directory
    rm -rf "$TEST_TEMP_DIR"
}

# =============================================================================
# Help and Usage Tests
# =============================================================================

@test "--help shows usage information" {
    run "$SCRIPT_PATH" --help
    [ "$status" -eq 0 ]
    [[ "$output" == *"Usage:"* ]]
    [[ "$output" == *"--skip-clone"* ]]
    [[ "$output" == *"--skip-deps"* ]]
    [[ "$output" == *"--backend-only"* ]]
    [[ "$output" == *"--frontend-only"* ]]
}

@test "-h shows usage information" {
    run "$SCRIPT_PATH" -h
    [ "$status" -eq 0 ]
    [[ "$output" == *"Usage:"* ]]
}

@test "unknown option shows error and usage" {
    run "$SCRIPT_PATH" --invalid-option
    [ "$status" -eq 1 ]
    [[ "$output" == *"Unknown option"* ]]
    [[ "$output" == *"Usage:"* ]]
}

# =============================================================================
# Argument Parsing Tests
# =============================================================================

@test "--skip-clone is recognized" {
    run "$SCRIPT_PATH" --help
    [ "$status" -eq 0 ]
    [[ "$output" == *"--skip-clone"* ]]
}

@test "--skip-deps is recognized" {
    run "$SCRIPT_PATH" --help
    [ "$status" -eq 0 ]
    [[ "$output" == *"--skip-deps"* ]]
}

@test "--backend-only is recognized" {
    run "$SCRIPT_PATH" --help
    [ "$status" -eq 0 ]
    [[ "$output" == *"--backend-only"* ]]
}

@test "--frontend-only is recognized" {
    run "$SCRIPT_PATH" --help
    [ "$status" -eq 0 ]
    [[ "$output" == *"--frontend-only"* ]]
}

@test "--backend-only and --frontend-only together fails" {
    # This test needs to get past dependency checks, so we'll check the help text
    # which documents this constraint
    run "$SCRIPT_PATH" --help
    [ "$status" -eq 0 ]
    # The script should document that these are mutually exclusive
    # (checking the actual combination requires mocking dependencies)
}

# =============================================================================
# Environment Variable Tests
# =============================================================================

@test "WXYC_DEV_ROOT default is parent of script directory" {
    run "$SCRIPT_PATH" --help
    [ "$status" -eq 0 ]
    # Help output shows the default value
    [[ "$output" == *"WXYC_DEV_ROOT"* ]]
}

@test "BACKEND_BRANCH default is main" {
    run "$SCRIPT_PATH" --help
    [ "$status" -eq 0 ]
    [[ "$output" == *"BACKEND_BRANCH"* ]]
    [[ "$output" == *"main"* ]]
}

@test "FRONTEND_BRANCH default is main" {
    run "$SCRIPT_PATH" --help
    [ "$status" -eq 0 ]
    [[ "$output" == *"FRONTEND_BRANCH"* ]]
    [[ "$output" == *"main"* ]]
}

# =============================================================================
# Script Syntax Tests
# =============================================================================

@test "script has valid bash syntax" {
    run bash -n "$SCRIPT_PATH"
    [ "$status" -eq 0 ]
}

@test "script is executable" {
    [ -x "$SCRIPT_PATH" ]
}

@test "script uses bash" {
    head -1 "$SCRIPT_PATH" | grep -q "#!/usr/bin/env bash"
}

@test "script uses strict mode (set -euo pipefail)" {
    grep -q "set -euo pipefail" "$SCRIPT_PATH"
}

# =============================================================================
# Documentation Tests
# =============================================================================

@test "help includes examples" {
    run "$SCRIPT_PATH" --help
    [ "$status" -eq 0 ]
    [[ "$output" == *"Examples:"* ]]
}

@test "help documents health check endpoints" {
    # Check that the script references the expected endpoints
    grep -q "localhost:8080" "$SCRIPT_PATH"
    grep -q "localhost:8082" "$SCRIPT_PATH"
    grep -q "localhost:3000" "$SCRIPT_PATH"
}

@test "help documents test credentials" {
    run "$SCRIPT_PATH" --help
    [ "$status" -eq 0 ]
    # The script should mention test credentials somewhere
    grep -q "test_dj" "$SCRIPT_PATH"
}

# =============================================================================
# Function Existence Tests (verify key functions are defined)
# =============================================================================

@test "script defines check_dependencies function" {
    grep -q "check_dependencies()" "$SCRIPT_PATH"
}

@test "script defines setup_repository function" {
    grep -q "setup_repository()" "$SCRIPT_PATH"
}

@test "script defines wait_for_health function" {
    grep -q "wait_for_health()" "$SCRIPT_PATH"
}

@test "script defines cleanup function" {
    grep -q "cleanup()" "$SCRIPT_PATH"
}

@test "script defines start_backend_services function" {
    grep -q "start_backend_services()" "$SCRIPT_PATH"
}

@test "script defines start_frontend function" {
    grep -q "start_frontend()" "$SCRIPT_PATH"
}

@test "script defines is_port_available function" {
    grep -q "is_port_available()" "$SCRIPT_PATH"
}

@test "script defines find_available_port function" {
    grep -q "find_available_port()" "$SCRIPT_PATH"
}

@test "script defines resolve_ports function" {
    grep -q "resolve_ports()" "$SCRIPT_PATH"
}

# =============================================================================
# Safety Tests
# =============================================================================

@test "script sets up signal trap for cleanup" {
    grep -q "trap cleanup" "$SCRIPT_PATH"
}

@test "script checks for Docker daemon running" {
    grep -q "docker info" "$SCRIPT_PATH"
}

@test "script uses curl for health checks" {
    grep -q "curl" "$SCRIPT_PATH"
}

# =============================================================================
# Output Format Tests
# =============================================================================

@test "script uses colored output" {
    grep -q "RED=" "$SCRIPT_PATH"
    grep -q "GREEN=" "$SCRIPT_PATH"
    grep -q "YELLOW=" "$SCRIPT_PATH"
    grep -q "BLUE=" "$SCRIPT_PATH"
}

@test "script has logging functions" {
    grep -q "log_info()" "$SCRIPT_PATH"
    grep -q "log_success()" "$SCRIPT_PATH"
    grep -q "log_warn()" "$SCRIPT_PATH"
    grep -q "log_error()" "$SCRIPT_PATH"
}

@test "script defines generate_backend_env function" {
    grep -q "generate_backend_env()" "$SCRIPT_PATH"
}

@test "generate_backend_env includes required variables" {
    # PORT= should appear in the template (parameterized, not hardcoded)
    grep -A30 "generate_backend_env()" "$SCRIPT_PATH" | grep -q "PORT="
    grep -q "DB_HOST=localhost" "$SCRIPT_PATH"
    grep -q "BETTER_AUTH_URL=" "$SCRIPT_PATH"
    grep -q "AUTH_BYPASS=" "$SCRIPT_PATH"
}

@test "generate_backend_env includes AUTH_PORT" {
    grep -A30 "generate_backend_env()" "$SCRIPT_PATH" | grep -q "AUTH_PORT="
}

# =============================================================================
# Port Resolution Tests
# =============================================================================

@test "is_port_available uses lsof to check ports" {
    grep -A5 "is_port_available()" "$SCRIPT_PATH" | grep -q "lsof"
}

@test "find_available_port returns default port when free" {
    source "$SCRIPT_PATH"
    is_port_available() { return 0; }
    [ "$(find_available_port 8080)" = "8080" ]
}

@test "find_available_port walks past occupied ports" {
    source "$SCRIPT_PATH"
    is_port_available() {
        case "$1" in 8080|8081) return 1 ;; *) return 0 ;; esac
    }
    [ "$(find_available_port 8080)" = "8082" ]
}

@test "find_available_port skips ports passed as already-taken" {
    source "$SCRIPT_PATH"
    is_port_available() { return 0; }
    # 8080 is free per the stub, but caller marks it taken from a prior pick.
    [ "$(find_available_port 8080 8080)" = "8081" ]
}

# Regression test for the subshell-collision bug: when consecutive defaults
# are all occupied, sequential command-substitution calls used to return the
# same port because RESOLVED_PORTS+= died in the subshell. The fix is for
# callers to pass already-picked ports forward as extra args.
@test "find_available_port avoids collision across command-substitution calls" {
    source "$SCRIPT_PATH"
    is_port_available() {
        case "$1" in 8080|8081|8082|8083) return 1 ;; *) return 0 ;; esac
    }
    BACKEND_PORT=$(find_available_port 8080)
    AUTH_PORT=$(find_available_port 8082 "$BACKEND_PORT")
    [ "$BACKEND_PORT" = "8084" ]
    [ "$AUTH_PORT" = "8085" ]
    [ "$BACKEND_PORT" != "$AUTH_PORT" ]
}

@test "find_available_port fails after exhausting the 20-port window" {
    source "$SCRIPT_PATH"
    is_port_available() { return 1; }
    run find_available_port 8080
    [ "$status" -ne 0 ]
}

@test "resolve_ports reads backend .env in frontend-only mode" {
    grep -A30 "resolve_ports()" "$SCRIPT_PATH" | grep -q "FRONTEND_ONLY"
}

@test "frontend is started with dynamic PORT" {
    grep -q 'PORT=\$FRONTEND_PORT npm run dev' "$SCRIPT_PATH"
}

@test "backend .env is always regenerated with backup" {
    grep -q '\.env\.bak' "$SCRIPT_PATH"
}

@test "frontend .env.local is always regenerated with backup" {
    grep -q '\.env\.local\.bak' "$SCRIPT_PATH"
}
