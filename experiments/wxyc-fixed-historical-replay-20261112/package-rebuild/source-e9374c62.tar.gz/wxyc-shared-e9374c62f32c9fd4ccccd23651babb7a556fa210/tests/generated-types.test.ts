/**
 * Tests for generated TypeScript types
 *
 * Validates that the codegen script produces correct TypeScript types with
 * enum const objects that match the OpenAPI spec values.
 */

import { describe, it, expect } from 'vitest';
import type { paths } from '../src/generated/openapi-types.js';
import {
  type FlowsheetEntryResponse,
  type FlowsheetSongEntry,
  type FlowsheetCreateSongFromCatalog,
  type FlowsheetCreateSongFreeform,
  type FlowsheetUpdateRequest,
  type FlowsheetV2TrackEntry,
  type Album,
  type AlbumSearchResult,
  type Label,
  type ScheduleShift,
  type SongRequest,
  type AlbumMetadataResponse,
  type ArtistMetadataResponse,
  type TrackListItem,
  type ReconciledIdentity,
  type HealthCheckResponse,
  type ReadinessResponse,
  type LibrarySearchItem,
  type LookupResultItem,
  type LookupRequest,
  type LookupResponse,
  type DiscogsMatchResult,
  type DiscogsWriterCredits,
  type TrackMatchHint,
  RotationBin,
  RequestStatus,
  MetadataSource,
  MetadataStatus,
  TrackMatchSource,
} from '../src/generated/models/index.js';

describe('Generated TypeScript Types', () => {
  describe('FlowsheetEntryResponse', () => {
    it('should accept a valid object literal', () => {
      const entry: FlowsheetEntryResponse = {
        id: 12345,
        play_order: 100,
        show_id: 42,
        request_flag: false,
        segue: false,
        track_title: 'Test Song',
        album_title: 'Test Album',
        artist_name: 'Test Artist',
        record_label: 'Test Label',
        rotation_bin: 'H',
      };

      expect(entry.id).toBe(12345);
      expect(entry.track_title).toBe('Test Song');
      expect(entry.rotation_bin).toBe(RotationBin.H);
    });

    it('should allow nullable metadata fields', () => {
      const entry: FlowsheetEntryResponse = {
        id: 1,
        play_order: 1,
        show_id: 1,
        request_flag: false,
        segue: false,
        artwork_url: null,
        spotify_url: null,
        release_year: null,
      };

      expect(entry.artwork_url).toBeNull();
      expect(entry.spotify_url).toBeNull();
    });

    it('should allow message entries without song fields', () => {
      const entry: FlowsheetEntryResponse = {
        id: 1,
        play_order: 50,
        show_id: 42,
        request_flag: false,
        segue: false,
        message: 'Talkset - station ID',
      };

      expect(entry.message).toBe('Talkset - station ID');
      expect(entry.track_title).toBeUndefined();
    });
  });

  describe('Album', () => {
    it('should accept a valid object literal', () => {
      const album: Album = {
        id: 1001,
        artist_id: 500,
        album_title: 'Kind of Blue',
        code_number: 42,
        genre_id: 5,
        format_id: 2,
        label: 'Columbia Records',
        add_date: '2024-01-15T00:00:00Z',
      };

      expect(album.album_title).toBe('Kind of Blue');
      expect(typeof album.add_date).toBe('string');
    });

    it('should allow omitting optional fields', () => {
      const album: Album = {
        id: 1,
        artist_id: 1,
        album_title: 'Minimal',
        code_number: 1,
        genre_id: 1,
        format_id: 1,
      };

      expect(album.label).toBeUndefined();
      expect(album.add_date).toBeUndefined();
    });
  });

  describe('Label', () => {
    it('should accept a valid object literal', () => {
      const label: Label = {
        id: 1,
        label_name: 'Merge Records',
      };

      expect(label.id).toBe(1);
      expect(label.label_name).toBe('Merge Records');
    });

    it('should handle optional parent_label_id', () => {
      const label: Label = {
        id: 2,
        label_name: 'Domino USA',
        parent_label_id: 42,
      };

      expect(label.parent_label_id).toBe(42);
    });

    it('should allow omitting optional fields', () => {
      const label: Label = {
        id: 1,
        label_name: 'Sub Pop',
      };

      expect(label.parent_label_id).toBeUndefined();
    });
  });


  describe('ScheduleShift', () => {
    it('takes the integer day the schedule column actually holds', () => {
      const shift: ScheduleShift = {
        id: 1,
        dj_id: 100,
        dj_name: 'Test DJ',
        // 0 = Monday, per `// days {0: mon, ... , 6: sun}` on the table. This
        // was `DayOfWeek.Monday` — the string 'Monday' — until #372 removed the
        // enum for contradicting the column on type and week-start alike.
        day: 0,
        start_time: '14:00',
        end_time: '16:00',
      };

      expect(shift.day).toBe(0);
    });
  });

  describe('SongRequest', () => {
    it('should accept RequestStatus enum values', () => {
      const request: SongRequest = {
        id: 1,
        device_id: 'device-123',
        message: 'Play some jazz please!',
        created_at: '2024-01-15T12:00:00Z',
        status: RequestStatus.pending,
      };

      expect(request.status).toBe('pending');
    });
  });

  describe('AlbumMetadataResponse', () => {
    it('should accept enriched metadata fields', () => {
      const response: AlbumMetadataResponse = {
        discogsReleaseId: 12345,
        releaseYear: 2024,
        artworkUrl: 'https://example.com/art.jpg',
        genres: ['Electronic', 'Experimental'],
        styles: ['IDM', 'Ambient'],
        label: 'Warp',
        discogsArtistId: 67890,
        fullReleaseDate: '2024-03-15',
        tracklist: [
          { position: '1', title: 'VI Scose Poise', duration: '5:23' },
          { position: '2', title: 'Cfern' },
        ],
      };

      expect(response.genres).toEqual(['Electronic', 'Experimental']);
      expect(response.styles).toEqual(['IDM', 'Ambient']);
      expect(response.label).toBe('Warp');
      expect(response.discogsArtistId).toBe(67890);
      expect(response.fullReleaseDate).toBe('2024-03-15');
      expect(response.tracklist).toHaveLength(2);
      expect(response.tracklist![0].duration).toBe('5:23');
      expect(response.tracklist![1].duration).toBeUndefined();
    });

    it('should allow omitting all new optional fields', () => {
      const response: AlbumMetadataResponse = {
        discogsReleaseId: 12345,
        artworkUrl: 'https://example.com/art.jpg',
      };

      expect(response.genres).toBeUndefined();
      expect(response.styles).toBeUndefined();
      expect(response.label).toBeUndefined();
      expect(response.discogsArtistId).toBeUndefined();
      expect(response.fullReleaseDate).toBeUndefined();
      expect(response.tracklist).toBeUndefined();
    });
  });

  describe('ArtistMetadataResponse', () => {
    it('should accept imageUrl field', () => {
      const response: ArtistMetadataResponse = {
        discogsArtistId: 67890,
        bio: 'Autechre are an English electronic music duo...',
        wikipediaUrl: 'https://en.wikipedia.org/wiki/Autechre',
        imageUrl: 'https://example.com/artist.jpg',
      };

      expect(response.imageUrl).toBe('https://example.com/artist.jpg');
    });

    it('should allow omitting imageUrl', () => {
      const response: ArtistMetadataResponse = {
        discogsArtistId: 67890,
        bio: 'Autechre are an English electronic music duo...',
      };

      expect(response.imageUrl).toBeUndefined();
    });

    // Pin the consumer-facing contract for bioTokens (#251): optional +
    // nullable array of DiscogsResolvedToken, pass-through of
    // DiscogsArtistDetails.profile_tokens at the proxy boundary.
    it('should accept bioTokens as an array of DiscogsResolvedToken', () => {
      const response: ArtistMetadataResponse = {
        discogsArtistId: 67890,
        bio: 'Autechre are an English electronic music duo...',
        bioTokens: [
          { type: 'plainText', text: 'Autechre are an English electronic music duo from ' },
          {
            type: 'artistLink',
            name: 'Autechre',
            display_name: 'Autechre',
            url: 'https://www.discogs.com/artist/97545',
          },
        ],
      };

      expect(response.bioTokens).toHaveLength(2);
      expect(response.bioTokens?.[0].type).toBe('plainText');
      expect(response.bioTokens?.[1].type).toBe('artistLink');
    });

    it('should accept null bioTokens (the backend emits an explicit `?? null`)', () => {
      const response: ArtistMetadataResponse = {
        discogsArtistId: 67890,
        bioTokens: null,
      };

      expect(response.bioTokens).toBeNull();
    });

    it('should allow omitting bioTokens', () => {
      const response: ArtistMetadataResponse = {
        discogsArtistId: 67890,
        bio: 'Autechre are an English electronic music duo...',
      };

      expect(response.bioTokens).toBeUndefined();
    });
  });

  describe('TrackListItem', () => {
    it('should require position and title', () => {
      const track: TrackListItem = {
        position: 'A1',
        title: 'VI Scose Poise',
      };

      expect(track.position).toBe('A1');
      expect(track.title).toBe('VI Scose Poise');
      expect(track.duration).toBeUndefined();
    });

    it('should accept optional duration', () => {
      const track: TrackListItem = {
        position: '1',
        title: 'VI Scose Poise',
        duration: '5:23',
      };

      expect(track.duration).toBe('5:23');
    });
  });

  describe('ReconciledIdentity', () => {
    it('should accept all six external identifiers', () => {
      const identity: ReconciledIdentity = {
        discogs_artist_id: 7894,
        musicbrainz_artist_id: 'd7b8a3a5-9080-487c-8c3c-2f6a3a3d44b2',
        wikidata_qid: 'Q470892',
        spotify_artist_id: '4uSftVc3FPWe6RJuMZNEe9',
        apple_music_artist_id: '88495919',
        bandcamp_id: 'stereolab',
      };

      expect(identity.discogs_artist_id).toBe(7894);
      expect(identity.bandcamp_id).toBe('stereolab');
    });

    it('should allow all fields to be omitted (fully unresolved identity)', () => {
      const identity: ReconciledIdentity = {};

      expect(identity.discogs_artist_id).toBeUndefined();
      expect(identity.spotify_artist_id).toBeUndefined();
    });

    it('should allow null for any identifier (resolved-but-absent)', () => {
      const identity: ReconciledIdentity = {
        discogs_artist_id: 7894,
        musicbrainz_artist_id: null,
        wikidata_qid: null,
        spotify_artist_id: null,
        apple_music_artist_id: null,
        bandcamp_id: null,
      };

      expect(identity.discogs_artist_id).toBe(7894);
      expect(identity.musicbrainz_artist_id).toBeNull();
    });
  });

  describe('HealthCheckResponse', () => {
    it('should accept the three documented status values', () => {
      const healthy: HealthCheckResponse = { status: 'healthy' };
      const degraded: HealthCheckResponse = { status: 'degraded' };
      const unhealthy: HealthCheckResponse = { status: 'unhealthy' };

      expect(healthy.status).toBe('healthy');
      expect(degraded.status).toBe('degraded');
      expect(unhealthy.status).toBe('unhealthy');
    });

    it('should accept arbitrary extension properties (additionalProperties: true)', () => {
      // semantic-index extends the base shape with `artist_count`; the type
      // must accept that without type errors.
      const extended: HealthCheckResponse = {
        status: 'healthy',
        artist_count: 12345,
        version: 'abc123',
      };

      expect(extended.status).toBe('healthy');
      expect(extended.artist_count).toBe(12345);
    });
  });

  describe('ReadinessResponse', () => {
    it('should require status and a services map', () => {
      const ready: ReadinessResponse = {
        status: 'healthy',
        services: {
          postgres: 'ok',
          discogs: 'unavailable',
          spotify: 'timeout',
        },
      };

      expect(ready.status).toBe('healthy');
      expect(ready.services.postgres).toBe('ok');
      expect(ready.services.discogs).toBe('unavailable');
      expect(ready.services.spotify).toBe('timeout');
    });

    it('should allow an empty services map', () => {
      const ready: ReadinessResponse = {
        status: 'degraded',
        services: {},
      };

      expect(ready.services).toEqual({});
    });
  });

  describe('Enums', () => {
    it('should define RotationBin values', () => {
      expect(RotationBin.H).toBe('H');
      expect(RotationBin.M).toBe('M');
      expect(RotationBin.L).toBe('L');
      expect(RotationBin.S).toBe('S');
    });

    // `Genre` and `Format` no longer generate a const object: #367 deleted
    // both components, so there is nothing here to export. Their absence is
    // pinned in tests/api-spec.test.ts, at the spec level where it is caused.

    it('should define RequestStatus values', () => {
      expect(RequestStatus.pending).toBe('pending');
      expect(RequestStatus.played).toBe('played');
      expect(RequestStatus.rejected).toBe('rejected');
    });

    it('should define MetadataSource values', () => {
      expect(MetadataSource.discogs).toBe('discogs');
      expect(MetadataSource.spotify).toBe('spotify');
      expect(MetadataSource.cache).toBe('cache');
      expect(MetadataSource.none).toBe('none');
    });

    it('should define TrackMatchSource values', () => {
      expect(TrackMatchSource.cta).toBe('cta');
      expect(TrackMatchSource.discogs_release).toBe('discogs_release');
      expect(TrackMatchSource.discogs_master).toBe('discogs_master');
      expect(TrackMatchSource.library_identity).toBe('library_identity');
    });
  });

  describe('TrackMatchHint (catalog-track-search §5.2)', () => {
    it('should accept a minimal object with only required fields', () => {
      const hint: TrackMatchHint = {
        title: 'VI Scose Poise',
        source: TrackMatchSource.discogs_master,
      };

      expect(hint.title).toBe('VI Scose Poise');
      expect(hint.source).toBe('discogs_master');
    });

    it('should accept all optional fields', () => {
      const hint: TrackMatchHint = {
        title: 'In a Sentimental Mood',
        artist_credit: 'Duke Ellington & John Coltrane',
        position: 'A1',
        confidence: 0.95,
        source: TrackMatchSource.cta,
      };

      expect(hint.position).toBe('A1');
      expect(hint.confidence).toBe(0.95);
      expect(hint.artist_credit).toBe('Duke Ellington & John Coltrane');
    });

    it('should accept null for nullable optional fields', () => {
      const hint: TrackMatchHint = {
        title: 'la paradoja',
        artist_credit: null,
        position: null,
        confidence: null,
        source: TrackMatchSource.discogs_release,
      };

      expect(hint.artist_credit).toBeNull();
      expect(hint.position).toBeNull();
      expect(hint.confidence).toBeNull();
    });
  });

  describe('matched_via on result schemas (catalog-track-search §5.1)', () => {
    it('AlbumSearchResult.matched_via is optional and typed as TrackMatchHint[]', () => {
      const withoutHint: AlbumSearchResult = {
        id: 60359,
        add_date: '2026-05-12T00:00:00Z',
        album_title: 'Confield',
        artist_name: 'Autechre',
        code_letters: 'AU',
        code_number: 8,
        code_artist_number: 3,
        format_name: 'CD',
        genre_name: 'Electronic',
        label: 'Warp Records',
      };

      const withHint: AlbumSearchResult = {
        ...withoutHint,
        matched_via: [
          { title: 'VI Scose Poise', source: TrackMatchSource.discogs_master },
        ],
      };

      expect(withoutHint.matched_via).toBeUndefined();
      expect(withHint.matched_via?.[0].title).toBe('VI Scose Poise');
    });

    it('LibrarySearchItem.matched_via is optional and typed as TrackMatchHint[]', () => {
      const item: LibrarySearchItem = {
        id: 65880,
        title: 'Confield',
        artist: 'Autechre',
        matched_via: [
          { title: 'VI Scose Poise', source: TrackMatchSource.discogs_master, confidence: 0.85 },
        ],
      };

      expect(item.matched_via?.[0].source).toBe('discogs_master');
    });

    it('LookupResultItem.matched_via is optional and typed as TrackMatchHint[]', () => {
      const result: LookupResultItem = {
        library_item: {
          id: 60359,
          title: 'Confield',
          artist: 'Autechre',
        },
        matched_via: [
          { title: 'VI Scose Poise', source: TrackMatchSource.library_identity, confidence: 0.92 },
        ],
      };

      expect(result.matched_via?.[0].source).toBe('library_identity');
    });

    it('matched_via supports multiple hints per release (e.g., comps with two matching tracks)', () => {
      const item: LibrarySearchItem = {
        id: 6468,
        title: "Jazz: The 50's, Volume I",
        artist: 'Various Artists',
        matched_via: [
          { title: 'In a Sentimental Mood', artist_credit: 'Duke Ellington', source: TrackMatchSource.cta, confidence: 1.0 },
          { title: 'Whistling Away The Dark', artist_credit: 'Abbey Lincoln', source: TrackMatchSource.cta, confidence: 1.0 },
        ],
      };

      expect(item.matched_via?.length).toBe(2);
    });
  });

  describe('track_position on flowsheet schemas (catalog-track-search §5.3)', () => {
    it('FlowsheetSongEntry accepts optional track_position', () => {
      const withoutPosition: FlowsheetSongEntry = {
        id: 12345,
        play_order: 100,
        show_id: 42,
        track_title: 'VI Scose Poise',
        artist_name: 'Autechre',
        album_title: 'Confield',
        record_label: 'Warp Records',
        request_flag: false,
      };

      const withPosition: FlowsheetSongEntry = {
        ...withoutPosition,
        track_position: '2',
      };

      expect(withoutPosition.track_position).toBeUndefined();
      expect(withPosition.track_position).toBe('2');
    });

    it('FlowsheetSongEntry accepts null track_position', () => {
      const entry: FlowsheetSongEntry = {
        id: 12345,
        play_order: 100,
        show_id: 42,
        track_title: 'VI Scose Poise',
        artist_name: 'Autechre',
        album_title: 'Confield',
        record_label: 'Warp Records',
        request_flag: false,
        track_position: null,
      };

      expect(entry.track_position).toBeNull();
    });

    it('FlowsheetEntryResponse accepts vinyl-style track_position strings', () => {
      const entry: FlowsheetEntryResponse = {
        id: 12345,
        play_order: 100,
        show_id: 42,
        request_flag: false,
        track_title: 'In a Sentimental Mood',
        track_position: 'A1',
      };

      expect(entry.track_position).toBe('A1');
    });

    // Write-side schemas (PR #134 / E6-1). These pin the *generated TypeScript*
    // contract that BS/dj-site/iOS callers actually import. If a future
    // api.yaml edit accidentally promotes `track_position` to required (e.g.,
    // adds it to the schema's `required:` list), openapi-typescript will emit
    // `track_position: string` instead of `track_position?: string` and these
    // tests fail-fast before that lands.
    it('FlowsheetCreateSongFromCatalog accepts optional track_position', () => {
      const withoutPosition: FlowsheetCreateSongFromCatalog = {
        album_id: 1001,
        track_title: 'la paradoja',
        request_flag: false,
      };

      const withPosition: FlowsheetCreateSongFromCatalog = {
        ...withoutPosition,
        track_position: 'A1',
      };

      expect(withoutPosition.track_position).toBeUndefined();
      expect(withPosition.track_position).toBe('A1');
    });

    // BS#1295 — POST /flowsheet/join carries an optional `dj_name_override`
    // that supersedes the caller's `auth_user.dj_name`-derived name on the
    // `show_start` marker text, the `flowsheet.dj_name` column of every
    // entry in this show, and `shows.legacy_dj_name` for the lifetime of
    // the show. Scoped to the start-show path; the co-host /join branch
    // intentionally ignores it (BS-side enforcement, not surfaced on the
    // wire). The inline schema means we reach into the path operation
    // directly rather than a named component — mirrors how BS's
    // `JoinRequestBody` lives in apps/backend/controllers/flowsheet.controller.ts.
    it('POST /flowsheet/join accepts optional dj_name_override', () => {
      type JoinBody =
        paths['/flowsheet/join']['post']['requestBody']['content']['application/json'];

      const withoutOverride: JoinBody = {
        dj_id: 42,
        show_name: 'Aubrey Hearst',
      };

      const withOverride: JoinBody = {
        ...withoutOverride,
        dj_name_override: 'DJ Guest Host',
      };

      expect(withoutOverride.dj_name_override).toBeUndefined();
      expect(withOverride.dj_name_override).toBe('DJ Guest Host');
    });

    // BS#1308 — POST /flowsheet/ for a track on a rotation album that isn't in
    // the WXYC library catalog. BS already persists `rotation_id` alongside
    // `album_id IS NULL` in the snapshot/else branch
    // (apps/backend/controllers/flowsheet.controller.ts), but the freeform
    // wire schema didn't declare `rotation_id`, forcing dj-site to either
    // synthesize a negative `album_id` (defect class: dj-site#564/#608/#698/#701)
    // or drop the linkage on the wire (PR #699 shape). Declaring it here
    // matches what BS already accepts.
    it('FlowsheetCreateSongFreeform accepts optional rotation_id', () => {
      const withoutRotation: FlowsheetCreateSongFreeform = {
        artist_name: 'Noura Mint Seymali',
        album_title: 'Tzenni',
        track_title: 'Tzenni',
        request_flag: false,
      };

      const withRotation: FlowsheetCreateSongFreeform = {
        ...withoutRotation,
        rotation_id: 5001,
      };

      expect(withoutRotation.rotation_id).toBeUndefined();
      expect(withRotation.rotation_id).toBe(5001);
    });

    it('FlowsheetUpdateRequest accepts optional track_position', () => {
      const empty: FlowsheetUpdateRequest = {};
      const withPosition: FlowsheetUpdateRequest = {
        track_position: '1-12',
      };

      expect(empty.track_position).toBeUndefined();
      expect(withPosition.track_position).toBe('1-12');
    });

    it('FlowsheetV2TrackEntry accepts optional + nullable track_position', () => {
      const baseEntry: FlowsheetV2TrackEntry = {
        id: 1,
        show_id: 42,
        play_order: 100,
        add_time: '2024-06-15T14:30:00.000Z',
        entry_type: 'track',
        request_flag: false,
      };

      const withPosition: FlowsheetV2TrackEntry = {
        ...baseEntry,
        track_position: 'B3',
      };

      const nullPosition: FlowsheetV2TrackEntry = {
        ...baseEntry,
        track_position: null,
      };

      expect(baseEntry.track_position).toBeUndefined();
      expect(withPosition.track_position).toBe('B3');
      expect(nullPosition.track_position).toBeNull();
    });
  });

  describe('LookupRequest extended-metadata flags (PR #133)', () => {
    // These tests pin the *generated TypeScript* contract for `extended` and
    // `warm_cache`. If a future api.yaml edit accidentally adds `default: false`
    // back to either field, openapi-typescript will promote them to required
    // (`extended: boolean` instead of `extended?: boolean`) and every existing
    // LML/BS/iOS/dj-site caller stops typechecking — these tests fail-fast
    // before that lands.
    it('treats `extended` and `warm_cache` as optional (callers can omit both)', () => {
      const minimal: LookupRequest = {
        artist: 'Stereolab',
        album: 'Aluminum Tunes',
      };

      expect(minimal.artist).toBe('Stereolab');
      // Compile-time assertion: omitting `extended`/`warm_cache` must be legal.
      expect(minimal.extended).toBeUndefined();
      expect(minimal.warm_cache).toBeUndefined();
    });

    it('accepts `extended` and `warm_cache` when callers opt in', () => {
      const opted: LookupRequest = {
        artist: 'Jessica Pratt',
        album: 'On Your Own Love Again',
        extended: true,
        warm_cache: true,
      };

      expect(opted.extended).toBe(true);
      expect(opted.warm_cache).toBe(true);
    });
  });

  describe('DiscogsMatchResult extended-metadata fields (PR #133)', () => {
    // Same pattern as above: pin the consumer-facing contract that the
    // new extended-metadata fields are optional + nullable.
    it('accepts a result with none of the extended fields set', () => {
      const baseline: DiscogsMatchResult = {
        release_id: 12345,
        release_url: 'https://www.discogs.com/release/12345',
      };

      expect(baseline.discogs_artist_id).toBeUndefined();
      expect(baseline.tracklist).toBeUndefined();
      expect(baseline.genres).toBeUndefined();
      expect(baseline.styles).toBeUndefined();
      expect(baseline.label).toBeUndefined();
      expect(baseline.full_release_date).toBeUndefined();
      expect(baseline.artist_image_url).toBeUndefined();
      expect(baseline.profile_tokens).toBeUndefined();
    });

    it('accepts a result with all extended fields populated', () => {
      const full: DiscogsMatchResult = {
        release_id: 12345,
        release_url: 'https://www.discogs.com/release/12345',
        discogs_artist_id: 999,
        tracklist: [{ position: 'A1', title: 'In a Sentimental Mood' }],
        genres: ['Jazz'],
        styles: ['Modal'],
        label: 'Impulse Records',
        full_release_date: '1963-02-07',
        artist_image_url: 'https://img.discogs.com/foo.jpg',
        profile_tokens: [{ type: 'plainText', text: 'American jazz pianist.' }],
      };

      expect(full.discogs_artist_id).toBe(999);
      expect(full.label).toBe('Impulse Records');
      expect(full.profile_tokens?.[0].type).toBe('plainText');
    });

    it('accepts null for every nullable extended field', () => {
      const nulled: DiscogsMatchResult = {
        release_id: 12345,
        release_url: 'https://www.discogs.com/release/12345',
        discogs_artist_id: null,
        tracklist: null,
        genres: null,
        styles: null,
        label: null,
        full_release_date: null,
        artist_image_url: null,
        profile_tokens: null,
      };

      expect(nulled.label).toBeNull();
      expect(nulled.profile_tokens).toBeNull();
    });
  });

  describe('DiscogsMatchResult master_id (Phase-2 catalog popularity, LML#688)', () => {
    // Pin the consumer-facing contract: master_id is optional + nullable, so a
    // caller can collapse pressings/formats of one logical album by the
    // Discogs master id. WXYC/Backend-Service#1486.
    it('accepts a result with master_id populated', () => {
      const withMaster: DiscogsMatchResult = {
        release_id: 12345,
        release_url: 'https://www.discogs.com/release/12345',
        master_id: 67890,
      };

      expect(withMaster.master_id).toBe(67890);
    });

    it('accepts a result with master_id null (release has no master)', () => {
      const noMaster: DiscogsMatchResult = {
        release_id: 12345,
        release_url: 'https://www.discogs.com/release/12345',
        master_id: null,
      };

      expect(noMaster.master_id).toBeNull();
    });

    it('accepts a result that omits master_id entirely', () => {
      const baseline: DiscogsMatchResult = {
        release_id: 12345,
        release_url: 'https://www.discogs.com/release/12345',
      };

      expect(baseline.master_id).toBeUndefined();
    });
  });

  describe('DiscogsMatchResult writer_credits (BMI composer, LML#699)', () => {
    // Pin the consumer-facing contract: writer_credits is optional, so a caller
    // that omits it (no resolved composer) is unaffected. Backend reads it off
    // the album_metadata passthrough to populate a flowsheet composer for BMI.
    it('accepts a result with release-level writer_credits', () => {
      const withWriters: DiscogsMatchResult = {
        release_id: 12345,
        release_url: 'https://www.discogs.com/release/12345',
        writer_credits: {
          names: ['Juana Molina'],
          roles: ['Written-By'],
          provenance: 'release',
          track_position: null,
        },
      };

      expect(withWriters.writer_credits?.names).toEqual(['Juana Molina']);
      expect(withWriters.writer_credits?.provenance).toBe('release');
    });

    it('accepts a standalone track-scoped DiscogsWriterCredits with a position', () => {
      const trackScoped: DiscogsWriterCredits = {
        names: ['Duke Ellington', 'John Coltrane'],
        roles: ['Written-By'],
        provenance: 'track',
        track_position: 'A1',
      };

      expect(trackScoped.provenance).toBe('track');
      expect(trackScoped.track_position).toBe('A1');
    });

    it('accepts a result that omits writer_credits entirely', () => {
      const baseline: DiscogsMatchResult = {
        release_id: 12345,
        release_url: 'https://www.discogs.com/release/12345',
      };

      expect(baseline.writer_credits).toBeUndefined();
    });
  });

  describe('LookupResponse degraded/cache-only discriminator (BS#943)', () => {
    it('degraded is a boolean and degraded_reason is an optional closed reason union', () => {
      const full: LookupResponse = { results: [], degraded: false };
      const shed: LookupResponse = {
        results: [],
        degraded: true,
        degraded_reason: 'deadline_exceeded',
      };

      expect(full.degraded).toBe(false);
      expect(shed.degraded_reason).toBe('deadline_exceeded');

      // degraded_reason is a closed string-literal union in the generated type.
      const reasons: NonNullable<LookupResponse['degraded_reason']>[] = [
        'deadline_exceeded',
        'cache_only',
        'upstream_unavailable',
      ];
      expect(reasons).toHaveLength(3);
    });

    it('omits degraded_reason on a non-degraded response', () => {
      const ok: LookupResponse = { results: [], degraded: false };
      expect(ok.degraded_reason).toBeUndefined();
    });
  });

  describe('DiscogsMatchResult per-service streaming_status (LML#1053)', () => {
    // Pin the consumer-facing contract BS#1915's self-heal reads: each streaming
    // service carries verified / absent / unresolved, disambiguating a transient
    // null (unresolved -> safe to re-ask) from a terminal absence (absent -> never
    // re-ask). Independent of the sibling `*_url` fields, which keep their meaning.
    it('accepts a result carrying per-service streaming statuses', () => {
      const withStatus: DiscogsMatchResult = {
        release_id: 12345,
        release_url: 'https://www.discogs.com/release/12345',
        apple_music_url: null,
        spotify_url: 'https://open.spotify.com/album/abc',
        streaming_status: {
          apple_music: 'unresolved',
          spotify: 'verified',
          bandcamp: 'absent',
        },
      };

      expect(withStatus.streaming_status?.apple_music).toBe('unresolved');
      expect(withStatus.streaming_status?.spotify).toBe('verified');
      expect(withStatus.streaming_status?.bandcamp).toBe('absent');
    });

    it('treats the per-service status as a closed verified/absent/unresolved union', () => {
      const statuses: NonNullable<
        NonNullable<DiscogsMatchResult['streaming_status']>['apple_music']
      >[] = ['verified', 'absent', 'unresolved'];
      expect(statuses).toHaveLength(3);
    });

    it('represents a never-consulted service by omitting its key (not `absent`)', () => {
      const partial: DiscogsMatchResult = {
        release_id: 12345,
        release_url: 'https://www.discogs.com/release/12345',
        streaming_status: {
          apple_music: 'verified',
          // bandcamp never probed on the /lookup/bulk path -> key omitted, not `absent`
        },
      };
      expect(partial.streaming_status?.bandcamp).toBeUndefined();
    });

    it('accepts a result that omits streaming_status entirely', () => {
      const baseline: DiscogsMatchResult = {
        release_id: 12345,
        release_url: 'https://www.discogs.com/release/12345',
      };
      expect(baseline.streaming_status).toBeUndefined();
    });
  });

  describe('discogsUnavailable trio on AlbumMetadataResponse / AlbumSearchResult / FlowsheetEntryResponse (#285 / #282 / BS#1908)', () => {
    it('AlbumMetadataResponse accepts the discogsUnavailable trio', () => {
      const response: AlbumMetadataResponse = {
        discogsReleaseId: 12345,
        artworkUrl: 'https://example.com/art.jpg',
        discogsUnavailable: true,
        discogsUnavailableNote: 'Embargoed promo-only pressing',
        lastDiscogsRecheckAt: '2026-08-01T00:00:00Z',
      };

      expect(response.discogsUnavailable).toBe(true);
      expect(response.discogsUnavailableNote).toBe('Embargoed promo-only pressing');
      expect(response.lastDiscogsRecheckAt).toBe('2026-08-01T00:00:00Z');
    });

    it('AlbumMetadataResponse allows omitting the discogsUnavailable trio', () => {
      const response: AlbumMetadataResponse = {
        discogsReleaseId: 12345,
        artworkUrl: 'https://example.com/art.jpg',
      };

      expect(response.discogsUnavailable).toBeUndefined();
      expect(response.discogsUnavailableNote).toBeUndefined();
      expect(response.lastDiscogsRecheckAt).toBeUndefined();
    });

    it('AlbumSearchResult accepts the discogsUnavailable trio', () => {
      const result: AlbumSearchResult = {
        id: 60359,
        add_date: '2026-05-12T00:00:00Z',
        album_title: 'DOGA',
        artist_name: 'Juana Molina',
        code_letters: 'MO',
        code_number: 8,
        code_artist_number: 3,
        format_name: 'CD',
        genre_name: 'Rock',
        label: 'Sonamos',
        discogsUnavailable: true,
        discogsUnavailableNote: null,
        lastDiscogsRecheckAt: null,
      };

      expect(result.discogsUnavailable).toBe(true);
      expect(result.discogsUnavailableNote).toBeNull();
      expect(result.lastDiscogsRecheckAt).toBeNull();
    });

    it('AlbumSearchResult allows omitting the discogsUnavailable trio', () => {
      const result: AlbumSearchResult = {
        id: 60359,
        add_date: '2026-05-12T00:00:00Z',
        album_title: 'DOGA',
        artist_name: 'Juana Molina',
        code_letters: 'MO',
        code_number: 8,
        code_artist_number: 3,
        format_name: 'CD',
        genre_name: 'Rock',
        label: 'Sonamos',
      };

      expect(result.discogsUnavailable).toBeUndefined();
    });

    it('FlowsheetEntryResponse accepts discogsUnavailable + discogsUnavailableNote', () => {
      const entry: FlowsheetEntryResponse = {
        id: 1,
        play_order: 1,
        show_id: 1,
        request_flag: false,
        segue: false,
        artist_name: 'Jessica Pratt',
        track_title: 'Back, Baby',
        album_title: 'On Your Own Love Again',
        discogsUnavailable: true,
        discogsUnavailableNote: 'Self-released cassette, never listed',
      };

      expect(entry.discogsUnavailable).toBe(true);
      expect(entry.discogsUnavailableNote).toBe('Self-released cassette, never listed');
    });

    it('FlowsheetEntryResponse allows omitting non-nullable discogsUnavailable while note is explicitly null', () => {
      // discogsUnavailable is non-nullable (matching the other Album surfaces),
      // so a row without the flag omits it rather than sending null;
      // discogsUnavailableNote stays nullable.
      const entry: FlowsheetEntryResponse = {
        id: 1,
        play_order: 1,
        show_id: 1,
        request_flag: false,
        segue: false,
        discogsUnavailableNote: null,
      };

      expect(entry.discogsUnavailable).toBeUndefined();
      expect(entry.discogsUnavailableNote).toBeNull();
    });
  });

  describe('local-first base fields on AlbumMetadataResponse (#318 / BS#1827)', () => {
    it('accepts recordLabel, labelId and metadataStatus alongside the enriched fields', () => {
      const response: AlbumMetadataResponse = {
        recordLabel: 'Houndstooth',
        labelId: 4271,
        metadataStatus: MetadataStatus.enriched_match,
        // Enriched, upstream-dependent siblings. `label` is the Discogs
        // *release* label and is a different value from `recordLabel`; both
        // ride the same response.
        label: 'Houndstooth Recordings',
        discogsReleaseId: 32346192,
        artworkUrl: 'https://example.com/art.jpg',
      };

      expect(response.recordLabel).toBe('Houndstooth');
      expect(response.labelId).toBe(4271);
      expect(response.metadataStatus).toBe('enriched_match');
      expect(response.label).toBe('Houndstooth Recordings');
    });

    it('allows omitting all three (the free-text row that never linked to an album_id)', () => {
      const response: AlbumMetadataResponse = {
        discogsReleaseId: 32346192,
        artworkUrl: 'https://example.com/art.jpg',
      };

      expect(response.recordLabel).toBeUndefined();
      expect(response.labelId).toBeUndefined();
      expect(response.metadataStatus).toBeUndefined();
    });

    it('types metadataStatus as the shared MetadataStatus enum, not a bare string', () => {
      // Assignability in both directions pins the alias to the enum union: a
      // bare `string` here would let an arbitrary literal through.
      const status: MetadataStatus = 'enriching';
      const response: AlbumMetadataResponse = { metadataStatus: status };
      const roundTrip: MetadataStatus | undefined = response.metadataStatus;

      expect(roundTrip).toBe(MetadataStatus.enriching);
      expect(Object.values(MetadataStatus)).toEqual([
        'pending',
        'enriching',
        'enriched_match',
        'enriched_no_match',
        'failed_no_retry',
      ]);
    });

    it('shares one enum alias with the V2 flowsheet track entry', () => {
      // Same type on both surfaces, so a client can reconcile the proxy
      // response against the feed row it came from.
      const track: FlowsheetV2TrackEntry = {
        id: 1,
        show_id: 1,
        play_order: 1,
        entry_type: 'track',
        request_flag: false,
        metadata_status: MetadataStatus.enriched_no_match,
      };
      const response: AlbumMetadataResponse = { metadataStatus: track.metadata_status };

      expect(response.metadataStatus).toBe(track.metadata_status);
    });
  });
});
