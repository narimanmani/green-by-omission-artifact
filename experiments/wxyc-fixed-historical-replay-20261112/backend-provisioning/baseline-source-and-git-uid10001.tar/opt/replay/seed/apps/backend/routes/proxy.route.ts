import { requirePermissions } from '@wxyc/authentication';
import { Router } from 'express';
import * as proxyController from '../controllers/proxy.controller.js';
import { proxyRateLimit } from '../middleware/rateLimiting.js';
import { trackActivity } from '../middleware/trackActivity.js';

export const proxy_route = Router();

// All proxy routes require JWT auth + activity tracking + rate limiting
proxy_route.use(requirePermissions({}), trackActivity, proxyRateLimit);

proxy_route.get('/artwork/search', proxyController.searchArtwork);
proxy_route.get('/metadata/album', proxyController.getAlbumMetadata);
proxy_route.get('/metadata/artist', proxyController.getArtistMetadata);
proxy_route.get('/entity/resolve', proxyController.resolveEntity);
proxy_route.get('/spotify/track/:id', proxyController.getSpotifyTrack);
proxy_route.get('/library/search', proxyController.librarySearch);
proxy_route.get('/library/:libraryId/tracks', proxyController.libraryTracks);
