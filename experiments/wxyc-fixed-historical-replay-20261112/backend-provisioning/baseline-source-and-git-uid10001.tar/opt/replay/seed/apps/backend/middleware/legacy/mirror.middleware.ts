import { NextFunction, Request, Response } from 'express';
import * as Sentry from '@sentry/node';
import { MirrorCommandQueue } from './commandqueue.mirror';
import { getPostHogClient } from '../../utils/posthog.js';

/**
 * Check the PostHog `backend-mirror` feature flag. If PostHog is not
 * configured (no API key), the mirror is enabled by default so that
 * local development and E2E tests work without external dependencies.
 *
 * `resolveShowIdentity` (optional) supplies the SHOW's primary DJ as the flag
 * identity. That — not the caller — is the correct unit of decision: the flag
 * has to answer the same way for every payload belonging to one show, or a
 * mixed-DJ show mirrors in half. It is resolved lazily, so the lookup it may
 * cost is only paid on the PostHog-configured path.
 *
 * The `req.auth?.id` fallback covers registrations with no show in the payload.
 * req.auth is what the auth middleware sets (shared/authentication
 * auth.middleware.ts) — nothing in this codebase ever assigns req.user, so the
 * pre-BS#1119-follow-up `req.user?.id` read meant every evaluation fell back to
 * req.ip, one EC2-local value.
 */
async function isMirrorEnabled(req: Request, resolveShowIdentity?: () => Promise<string | null>): Promise<boolean> {
  if (!process.env.POSTHOG_API_KEY) {
    console.log('[mirror] enabled=true source=env-default');
    return true;
  }

  let showIdentity: string | null = null;
  if (resolveShowIdentity) {
    try {
      showIdentity = await resolveShowIdentity();
    } catch (e) {
      // Never fail the flag check on an identity lookup: fall back to the
      // caller, the same identity every registration without a resolver uses.
      console.warn('[mirror] Failed to resolve the show flag identity; falling back to the caller:', e);
    }
  }

  const client = getPostHogClient();
  const distinctId = showIdentity ?? req.auth?.id ?? req.ip ?? 'anonymous';
  const enabled = await client.isFeatureEnabled('backend-mirror', distinctId);
  if (enabled === undefined) {
    // PostHog couldn't resolve the flag (client error/timeout/unknown flag):
    // fail closed, under a distinct source label so a deliberate flag-off
    // (source=posthog) stays distinguishable from this default in the logs.
    console.log('[mirror] enabled=false source=posthog-default');
    return false;
  }
  console.log(`[mirror] enabled=${enabled} source=posthog`);
  return enabled;
}

/**
 * Optional per-registration behavior shared by both mirror factories.
 *
 * `shouldMirror` gates the payload SHAPE before any other work: a route that
 * serves two response shapes through one registration (BS#1119 —
 * /flowsheet/end answers a ShowDJ for guest leaves, /flowsheet/join a ShowDJ
 * for co-host joins) passes a type-guard predicate so non-mirrorable payloads
 * skip out here, before the PostHog round-trip `isMirrorEnabled` pays in prod,
 * and so the `as T` cast in the handler is backed by a runtime check instead
 * of hope.
 *
 * `resolveFlagIdentity` supplies the show's primary DJ as the `backend-mirror`
 * flag identity (see `isMirrorEnabled`). Every registration that can name a
 * show should pass one: it keeps the live mirror's decision per-SHOW, matching
 * `jobs/legacy-mirror-reconcile`, which keys the same flag on `primary_dj_id`.
 * Without it, a show whose co-host resolves the flag differently from its
 * primary reaches tubafrenzy half-mirrored — the one state the reconcile cron
 * refuses to auto-heal (re-driving would append out of order).
 */
type MirrorOptions<T> = {
  shouldMirror?: (data: unknown) => data is T;
  resolveFlagIdentity?: (data: T) => Promise<string | null> | string | null;
};

export const createBackendMirrorMiddleware =
  <T>(createCommand: (req: Request, data: T) => Promise<string[]>, options: MirrorOptions<T> = {}) =>
  async (req: Request, res: Response, next: NextFunction) => {
    tapJsonResponse(res);

    // After the response is sent, decide whether to enqueue work
    res.once('finish', () => {
      void (async () => {
        try {
          console.log('Response finished, checking for mirror work...');
          const ok = res.statusCode >= 200 && res.statusCode < 305;
          const data = (res.locals as any).mirrorData as T | undefined;

          console.log('Response status:', res.statusCode, 'ok?', ok);

          if (!ok || data == null) return;
          if (options.shouldMirror && !options.shouldMirror(data)) return;

          const mirrorOn = await isMirrorEnabled(req, identityResolver(options, data));
          if (!mirrorOn) return;

          const statements = await createCommand(req, data);
          // An empty statement list means "nothing to mirror" (e.g. deleteEntry
          // of a row with no tubafrenzy id). Skip the enqueue rather than push an
          // empty `START TRANSACTION; COMMIT;` for the SSH executor to run.
          if (statements.length === 0) return;

          console.log('Enqueuing mirror work...');

          const queue = MirrorCommandQueue.instance();
          queue.enqueue(statements);
        } catch (e) {
          console.error('Error in mirror middleware:', e);
          Sentry.captureException(e, { tags: { subsystem: 'legacy-mirror', variant: 'sql' } });
        }
      })();
    });

    next();
  };

/** Bind a registration's optional identity resolver to this request's payload. */
function identityResolver<T>(options: MirrorOptions<T>, data: T): (() => Promise<string | null>) | undefined {
  const resolve = options.resolveFlagIdentity;
  return resolve ? () => Promise.resolve(resolve(data)) : undefined;
}

/**
 * HTTP mirror middleware factory. Same response-tapping and PostHog feature flag
 * check as createBackendMirrorMiddleware, but calls an async callback that makes
 * HTTP calls instead of returning SQL strings for the command queue.
 *
 * See `MirrorOptions` for `shouldMirror` and `resolveFlagIdentity`.
 */
export const createHttpMirrorMiddleware =
  <T>(execute: (req: Request, data: T) => Promise<void>, options: MirrorOptions<T> = {}) =>
  async (req: Request, res: Response, next: NextFunction) => {
    tapJsonResponse(res);

    res.once('finish', () => {
      void (async () => {
        try {
          const ok = res.statusCode >= 200 && res.statusCode < 305;
          const data = (res.locals as any).mirrorData as T | undefined;

          if (!ok || data == null) return;
          if (options.shouldMirror && !options.shouldMirror(data)) return;

          const mirrorOn = await isMirrorEnabled(req, identityResolver(options, data));
          if (!mirrorOn) return;

          await execute(req, data);
        } catch (e) {
          console.error('Error in HTTP mirror middleware:', e);
          Sentry.captureException(e, { tags: { subsystem: 'legacy-mirror', variant: 'http' } });
        }
      })();
    });

    next();
  };

/**
 * Stash the UNPROJECTED row for the mirror before the controller sends the
 * projected client response (BS#1513 / PR #1532). `tapJsonResponse` captures
 * the HTTP body into `res.locals.mirrorData`, but the flowsheet mutation
 * responses are projected through the client-facing allow-list — which strips
 * `legacy_entry_id`, the column the flowsheet mirror's BS#908 loop guards and
 * restart fallback read. Controllers call this with the raw service row; the
 * tap then leaves the stashed value in place. The JSON round-trip reproduces
 * the exact parsed-body shape the mirror handlers were built against (dates
 * as ISO strings, `undefined` keys dropped).
 *
 * A nullish row is a no-op — not a crash, not a poisoned stash: the tap falls
 * back to capturing the response body, exactly the pre-stash behavior. This
 * protects the mirror seam only (a `JSON.parse(String(undefined))` SyntaxError,
 * or a `null` stash that silently unplugs the mirror). It does NOT keep the
 * response itself from 500ing — `sendProjectedEntry` calls `projectFlowsheetEntry`
 * on the same row, which throws on undefined; the callers' missing-row 404
 * guards are what stop that, and every mutation site has one.
 */
export function stashMirrorData(res: Response, row: unknown): void {
  if (row == null) return;
  (res.locals as any).mirrorData = JSON.parse(JSON.stringify(row));
  (res.locals as any).mirrorDataStashed = true;
}

function tapJsonResponse(res: Response) {
  const origSend = res.send.bind(res);

  res.send = ((body?: any) => {
    // A controller pre-stashed the unprojected row via `stashMirrorData`
    // (BS#1513); don't clobber it with the projected body. Keyed on the flag
    // rather than `mirrorData === undefined` so the unstashed tap stays
    // last-write-wins: `res.send(object)` re-enters this wrapper through
    // `res.json`, and the final, serialized pass — the parsed-JSON shape the
    // mirror handlers were built against — must be the one captured.
    if ((res.locals as any).mirrorDataStashed) {
      return origSend(body);
    }

    let captured: unknown = body;

    const ct = (res.getHeader('content-type') || '').toString().toLowerCase();
    if (typeof body === 'string' && ct.includes('application/json')) {
      try {
        captured = JSON.parse(body);
      } catch {
        // ignore parse errors; keep raw string
      }
    }

    if (Buffer.isBuffer(body) && ct.includes('application/json')) {
      try {
        captured = JSON.parse(body.toString('utf8'));
      } catch {
        /* ignore */
      }
    }
    (res.locals as any).mirrorData = captured;
    return origSend(body);
  }) as any;
}
