import { and, asc, desc, eq, inArray, isNull, ne, notInArray, or, sql, SQL, type Column } from 'drizzle-orm';
import { LRUCache } from 'lru-cache';
import * as Sentry from '@sentry/node';
import type { ReconciledIdentity, TrackMatchHint } from '@wxyc/shared/dtos';
import { RotationAddRequest } from '../controllers/library.controller.js';
import WxycError from '../utils/error.js';
import { db, type RotationBin } from '@wxyc/database';
import {
  AlbumFormat,
  Artist,
  NewAlbum,
  NewAlbumFormat,
  NewArtist,
  NewGenre,
  RotationRelease,
  album_plays,
  album_popularity,
  artist_library_crossreference,
  artists,
  bins,
  compilation_track_artist,
  flowsheet,
  genre_artist_crossreference,
  format,
  genres,
  library,
  library_delete_denylist,
  library_identity,
  library_identity_source,
  library_watermark,
  rotation,
  LibraryArtistViewEntry,
} from '@wxyc/database';
import {
  LibraryResult,
  EnrichedLibraryResult,
  enrichLibraryResult,
  ArtistMatchHint,
  ArtistSearchAliasSource,
} from './requestLine/types.js';
import {
  getRelease,
  lookupBySong,
  lookupMetadata,
  isLmlConfigured,
  LmlClientError,
  resolveIdentity,
  type LookupResponse,
  type DiscogsTrackItem,
  type DiscogsReleaseMetadata,
} from '@wxyc/lml-client';
import { lmlLookupCoordinator } from './lml/index.js';
import { filterSpacerGif } from './metadata/metadata.service.js';
import { checkLibraryArtistNameHealth } from './library-artist-name-assertion.service.js';
import { getConfig as getCatalogTrackSearchConfig } from '../config/catalogTrackSearch.js';
import { getConfig as getCatalogSearchAliasConfig } from '../config/catalogSearchAlias.js';
import { isCompilationArtist } from './requestLine/matching/index.js';
import { ilikeEscaped } from '../utils/sql-like.js';
import {
  buildAliasHitsCte,
  buildFuzzyAliasTier,
  buildDirectMatchTieBreak,
  ALIAS_HITS_PROJECTION,
  ALIAS_HITS_PROJECTION_NULLS,
  type AliasHitFields,
} from '../utils/alias-hits.js';
import { rawProjection } from '../utils/sql-projection.js';
import { recordCacheLookup, recordCacheEviction, type RegisteredCache } from './observability/cache-stats.js';

// Schema-qualified reference to the `fold_artist_name(text)` SQL function
// (migration 0134 / BS#1897). Derived from `WXYC_SCHEMA_NAME` the same way the
// `@wxyc/database` `pgSchema` object and the job SQL builders are, so the
// per-worker test-isolation schema resolves correctly. `""`-escaped for the
// (theoretical) quoted-identifier case, mirroring `worklist.ts`.
const FOLD_SCHEMA = (process.env.WXYC_SCHEMA_NAME || 'wxyc_schema').replace(/"/g, '""');
const FOLD_ARTIST_NAME_FN = sql.raw(`"${FOLD_SCHEMA}"."fold_artist_name"`);

/**
 * Catalog freshness watermark for the conditional-GET path (BS#1467 / Epic F
 * pattern). Returns `library_watermark.last_modified_at`, the single-row
 * sibling table advanced by the `touch_library_watermark` AFTER STATEMENT
 * trigger on `library` (migration 0104). The trigger fires on every
 * INSERT/UPDATE/DELETE — including the daily `jobs/library-etl/` write that
 * bypasses this service layer — so the watermark is correct even though most
 * catalog mutations never call into `library.service`.
 *
 * The conditional-GET middleware (`conditionalGet(getCatalogLastModifiedAt)`)
 * reads this on every poll; PK lookup is O(1). Returns the epoch
 * (`new Date(0)`) only as a defensive fallback — the migration seeds the
 * singleton row at apply time, so in production the SELECT always returns
 * exactly one row.
 *
 * Analogue of `flowsheet.service.getLastModifiedAt`.
 */
export const getCatalogLastModifiedAt = async (): Promise<Date> => {
  const result = await db.select({ at: library_watermark.last_modified_at }).from(library_watermark).limit(1);
  return result[0]?.at ?? new Date(0);
};

/**
 * Source columns on `artists` (and any joined / view-projected row) that
 * comprise a ReconciledIdentity. Kept in sync with the @wxyc/shared schema;
 * if a new external-ID field appears on the shared type, add it here too.
 */
const RECONCILED_IDENTITY_KEYS = [
  'discogs_artist_id',
  'musicbrainz_artist_id',
  'wikidata_qid',
  'spotify_artist_id',
  'apple_music_artist_id',
  'bandcamp_id',
] as const;

type ReconciledIdentityKey = (typeof RECONCILED_IDENTITY_KEYS)[number];

/**
 * A library_artist_view row that may carry an attached `matched_via` hint when
 * the cascade's CTA or LML `/lookup` fallback surfaced it (catalog-track-search
 * plan §5.1), or a `matched_via_alias` hint when the artist-search-alias
 * UNION ALL branch surfaced it (artist-search-alias plan §PR 5, post-#1318).
 * Wraps `LibraryArtistViewEntry` rather than replacing it so downstream
 * functions (enrichWithArtwork, serializeReconciledIdentity) accept tagged
 * rows without signature changes.
 */
export type TaggedLibraryViewEntry = LibraryArtistViewEntry & {
  matched_via?: TrackMatchHint[];
  matched_via_alias?: ArtistMatchHint[];
};

/**
 * Attach `matched_via_alias` to a tagged row when the alias UNION ALL branch
 * surfaced a non-null hit. No-op when all three alias fields are null (the
 * row matched via the underlying trigram predicate, not via the alias cache).
 */
function attachAliasHint<R extends LibraryArtistViewEntry & AliasHitFields>(row: R): TaggedLibraryViewEntry {
  // Strip the alias-only fields off the wire-shape; matched_via_alias carries
  // the same information in the public sibling-type shape.
  const { alias_max_sim, alias_matched_variant, alias_matched_source, ...rest } = row;
  // Defensive: require non-nullish numeric and truthy variant + source. The
  // alias branch should never emit empty-string fields, but mirror the same
  // guard `toAlbumSearchResultRow` uses in library-search.service so the
  // catalog (/library/query) and request-line surfaces agree on what counts
  // as an alias hit.
  if (alias_max_sim === null || alias_max_sim === undefined || !alias_matched_variant || !alias_matched_source) {
    return rest as TaggedLibraryViewEntry;
  }
  return {
    ...(rest as TaggedLibraryViewEntry),
    matched_via_alias: [
      { matched_variant: alias_matched_variant, source: alias_matched_source as ArtistSearchAliasSource },
    ],
  };
}

/**
 * A row that carries the three BS#1281 discogs-unavailable columns
 * (`library` directly, or any join projection over it).
 */
type DiscogsUnavailableSource = {
  discogs_unavailable: boolean;
  discogs_unavailable_note: string | null;
  last_discogs_recheck_at: Date | null;
};

/**
 * Rename the three BS#1281 discogs-unavailable columns from their DB
 * snake_case to the camelCase wire shape wxyc-shared's api.yaml (Album /
 * UpdateAlbumRequest schemas, #156) deliberately uses for this trio — the
 * PATCH write path (`library.controller.ts#UPDATABLE_ALBUM_FIELDS`) already
 * reads `discogsUnavailable`/`discogsUnavailableNote` off the request body in
 * camelCase; this is the matching read-side rename (BS#1895). `Date` values
 * pass through unconverted — `res.json()` serializes them to ISO strings via
 * `Date.prototype.toJSON`, same as every other Date-typed field on these
 * read surfaces (`add_date`, `last_modified`, ...).
 */
function withDiscogsUnavailableCamelCase<T extends DiscogsUnavailableSource>(
  row: T
): Omit<T, keyof DiscogsUnavailableSource> & {
  discogsUnavailable: boolean;
  discogsUnavailableNote: string | null;
  lastDiscogsRecheckAt: Date | null;
} {
  const { discogs_unavailable, discogs_unavailable_note, last_discogs_recheck_at, ...rest } = row;
  return {
    ...rest,
    discogsUnavailable: discogs_unavailable,
    discogsUnavailableNote: discogs_unavailable_note,
    lastDiscogsRecheckAt: last_discogs_recheck_at,
  };
}

/** A row that carries the six external-ID fields (artist row, view row, or any join projection). */
type ReconciledIdentitySource = {
  discogs_artist_id: number | null;
  musicbrainz_artist_id: string | null;
  wikidata_qid: string | null;
  spotify_artist_id: string | null;
  apple_music_artist_id: string | null;
  bandcamp_id: string | null;
};

/**
 * Build a shared `ReconciledIdentity` from any row carrying the six external-ID
 * fields, or null when all six are populated as null. Matching the semantic-index
 * pattern lets consumers distinguish "no IDs resolved yet" from "resolved with
 * some null IDs."
 */
export function toReconciledIdentity(row: ReconciledIdentitySource): ReconciledIdentity | null {
  const identity: ReconciledIdentity = {
    discogs_artist_id: row.discogs_artist_id,
    musicbrainz_artist_id: row.musicbrainz_artist_id,
    wikidata_qid: row.wikidata_qid,
    spotify_artist_id: row.spotify_artist_id,
    apple_music_artist_id: row.apple_music_artist_id,
    bandcamp_id: row.bandcamp_id,
  };
  if (RECONCILED_IDENTITY_KEYS.every((key) => identity[key] === null)) {
    return null;
  }
  return identity;
}

/**
 * Strip the six flat external-ID fields from a row and replace them with a
 * nested `reconciled_identity` object. Works for any shape that includes the
 * six fields (artist rows, view rows, ad-hoc join projections), so all four
 * library read endpoints can return the same wire shape.
 */
export function serializeReconciledIdentity<T extends ReconciledIdentitySource>(
  row: T
): Omit<T, ReconciledIdentityKey> & { reconciled_identity: ReconciledIdentity | null } {
  const {
    discogs_artist_id: _discogs,
    musicbrainz_artist_id: _mb,
    wikidata_qid: _qid,
    spotify_artist_id: _spotify,
    apple_music_artist_id: _apple,
    bandcamp_id: _bandcamp,
    ...rest
  } = row;
  return { ...rest, reconciled_identity: toReconciledIdentity(row) } as Omit<T, ReconciledIdentityKey> & {
    reconciled_identity: ReconciledIdentity | null;
  };
}

/**
 * Wire-format for an artist response. Replaces the six flat external-ID
 * columns with a nested `reconciled_identity` object that conforms to the
 * shared @wxyc/shared schema.
 */
export type ArtistResponse = Omit<Artist, ReconciledIdentityKey> & {
  reconciled_identity: ReconciledIdentity | null;
};

/**
 * Convert a Drizzle `artists` row to the public-facing artist response.
 * Strips the six flat external-ID columns and replaces them with a nested
 * `reconciled_identity` object.
 */
export function serializeArtist(artist: Artist): ArtistResponse {
  return serializeReconciledIdentity(artist);
}

export const getFormatsFromDB = async () => {
  const formats = await db
    .select()
    .from(format)
    .where(sql`true`);
  return formats;
};

export const insertFormat = async (new_format: NewAlbumFormat) => {
  const response = await db.insert(format).values(new_format).returning();
  return response[0];
};

/**
 * Look up a single format row by id. Used by PATCH /library/:id to validate an
 * incoming `format_id` against the `format` table so a stale/guessed id
 * surfaces as a 400 instead of tripping the NOT NULL FK (PG 23503) → 500
 * (BS#1550), mirroring `labelsService.getLabelById`.
 */
export const getFormatById = async (id: number): Promise<AlbumFormat | undefined> => {
  const result = await db.select().from(format).where(eq(format.id, id)).limit(1);
  return result[0];
};

export interface Rotation {
  id: number | null;
  code_letters: string | null;
  code_artist_number: number | null;
  code_number: number | null;
  artist_name: string | null;
  alphabetical_name: string | null;
  album_title: string | null;
  record_label: string | null;
  label_id: number | null;
  genre_name: string | null;
  format_name: string | null;
  rotation_id: number;
  add_date: Date | null;
  rotation_add_date: string;
  rotation_bin: RotationBin;
  rotation_kill_date: string | null;
  plays: number | null;
  // Nullable (unlike AlbumSearchResult/BinLibraryDetails/AlbumInfoResponse,
  // all of which guarantee a real library row): a library-unlinked rotation
  // row has no library row at all, hence no legacy id (BS#2128).
  legacy_release_id: number | null;
  reconciled_identity: ReconciledIdentity | null;
}

/**
 * Raw row shape returned by the rotation query before reconciled-identity
 * serialization. Mirrors the SELECT list in `getRotationFromDB`. Carries
 * the six external-ID columns flat; `serializeReconciledIdentity` strips
 * them and replaces them with a nested `reconciled_identity` object.
 *
 * Most fields are nullable because the LEFT JOINs (#689) intentionally
 * surface rotation rows whose `album_id` doesn't resolve to a `library`
 * row; those rows fall back to rotation's denormalized
 * artist/album/label snapshot fields and have NULL ancillary metadata
 * (`code_letters`, `genre_name`, `format_name`, identity ids).
 */
type RotationRow = Omit<Rotation, 'reconciled_identity'> & ReconciledIdentitySource;

/**
 * Read-side query for `GET /library/rotation`.
 *
 * **Shape rules** (see #689 / #694, BS CLAUDE.md `SOURCE: tubafrenzy`
 * annotation on the rotation table). Tubafrenzy is the upstream writer
 * and BS is downstream; we cannot constrain what tubafrenzy writes, so
 * the read collapses the full upstream shape on the way out.
 *
 * - **LEFT JOIN to library, artists, format, genres,
 *   genre_artist_crossreference.** Tubafrenzy permits rotation rows
 *   with NULL `album_id` (rotation entries that pre-date or didn't
 *   link to a library row); ~147 such rows are currently active in
 *   prod and were dropped by the previous INNER JOIN. We instead
 *   surface them and `COALESCE` artist_name/album_title/record_label
 *   from rotation's denormalized snapshot columns when the library
 *   join is NULL.
 *
 * - **DISTINCT ON `(coalesce(album_id::bigint, -(abs(hashtext(lower(artist)||'|'||lower(album))::bigint) + 1)), rotation_bin)`
 *   ORDER BY same key, then `add_date DESC, id ASC`.**
 *   Tubafrenzy permits multiple active rows per
 *   `(album_id, rotation_bin)` over an album's lifecycle (re-bins,
 *   re-adds, label-driven re-promotes); we collapse those duplicates
 *   to one row per group on the way out, picking the most-recently
 *   added (tie-broken by lowest rotation id for deterministic output).
 *   When `album_id IS NULL` (151/310 active rows in the 2026-05-14
 *   prod snapshot — tubafrenzy entries that never resolved to a
 *   library row), we partition on a hash of the denormalized
 *   `(artist_name, album_title)` snapshot columns instead. This both
 *   keeps NULL-album rows in their own groups (Postgres DISTINCT ON
 *   would otherwise treat NULLs as equal and collapse all 151 to one)
 *   AND collapses unlinked dupes that share the same release — fixing
 *   #862, where the dropdown surfaced the same release ×3 because the
 *   prior `-id` trick was unique-per-row and never collapsed.
 *   `hashtext` is deterministic and cheap; collisions at this row
 *   count are negligible (birthday-bound ~32k for a 32-bit space and
 *   we're at ~151). `abs(hashtext::bigint) + 1` is always >= 1 (no
 *   int4 overflow on `abs(INT_MIN)` because it widens to bigint
 *   cleanly); negating gives a strictly negative key so it can never
 *   collide with a positive `album_id`.
 *
 * - **`kill_date IS NULL OR kill_date > CURRENT_DATE`.** Active rows
 *   only; the planner-stable predicate also excludes future-dated
 *   kills correctly.
 */
export const getRotationFromDB = async (): Promise<Rotation[]> => {
  // Stable partition key for the DISTINCT ON / ORDER BY: real album_id when
  // present, else a hash of the (artist_name, album_title) snapshot so
  // unlinked duplicates collapse together (#862). The expression is computed
  // entirely in bigint to defuse two latent failures:
  //   1. `hashtext` returns int4; negating `INT_MIN` raises `integer out of
  //      range` on Postgres rather than wrapping.
  //   2. Naïvely negating a negative `hashtext` produces a positive value
  //      that could collide with a real positive `album_id` in the COALESCE
  //      and silently drop a real-album row from the output.
  // `abs(hashtext::bigint) + 1` is always >= 1 (no overflow because
  // `abs(INT_MIN)` widens to bigint cleanly); negating gives <= -1 — strictly
  // negative, so it can never collide with a positive `album_id`.
  const partitionKey = sql`COALESCE(
    ${rotation.album_id}::bigint,
    -(abs(hashtext(lower(coalesce(${rotation.artist_name}, '')) || '|' || lower(coalesce(${rotation.album_title}, '')))::bigint) + 1)
  )`;
  const query = sql`
    SELECT DISTINCT ON (${partitionKey}, ${rotation.rotation_bin})
      ${library.id} AS id,
      ${artists.code_letters} AS code_letters,
      ${genre_artist_crossreference.artist_genre_code} AS code_artist_number,
      ${library.code_number} AS code_number,
      COALESCE(${artists.artist_name}, ${rotation.artist_name}) AS artist_name,
      COALESCE(${artists.alphabetical_name}, ${rotation.artist_name}) AS alphabetical_name,
      COALESCE(${library.album_title}, ${rotation.album_title}) AS album_title,
      COALESCE(${library.label}, ${rotation.record_label}) AS record_label,
      ${library.label_id} AS label_id,
      ${genres.genre_name} AS genre_name,
      ${format.format_name} AS format_name,
      ${rotation.id} AS rotation_id,
      ${library.add_date} AS add_date,
      ${rotation.add_date} AS rotation_add_date,
      ${rotation.rotation_bin} AS rotation_bin,
      ${rotation.kill_date} AS rotation_kill_date,
      ${library.plays} AS plays,
      ${library.legacy_release_id} AS legacy_release_id,
      ${artists.discogs_artist_id} AS discogs_artist_id,
      ${artists.musicbrainz_artist_id} AS musicbrainz_artist_id,
      ${artists.wikidata_qid} AS wikidata_qid,
      ${artists.spotify_artist_id} AS spotify_artist_id,
      ${artists.apple_music_artist_id} AS apple_music_artist_id,
      ${artists.bandcamp_id} AS bandcamp_id
    FROM ${rotation}
    LEFT JOIN ${library} ON ${library.id} = ${rotation.album_id}
    LEFT JOIN ${artists} ON ${artists.id} = ${library.artist_id}
    LEFT JOIN ${format} ON ${library.format_id} = ${format.id}
    LEFT JOIN ${genres} ON ${library.genre_id} = ${genres.id}
    LEFT JOIN ${genre_artist_crossreference}
      ON ${genre_artist_crossreference.artist_id} = ${library.artist_id}
      AND ${genre_artist_crossreference.genre_id} = ${library.genre_id}
    WHERE ${rotation.kill_date} > CURRENT_DATE OR ${rotation.kill_date} IS NULL
    ORDER BY ${partitionKey},
             ${rotation.rotation_bin},
             ${rotation.add_date} DESC,
             ${rotation.id} ASC
  `;

  const response = await db.execute(query);
  const rows = response as unknown as RotationRow[];

  return rows.map((row) => serializeReconciledIdentity(row));
};

/**
 * BS#1380: Sentry counter `lml.resolve.fallback_to_null` reason buckets.
 * Each value signals a different operational response:
 *   - `timeout`: LML latency/capacity (look at LML p95)
 *   - `5xx`:     LML deploy regression (look at LML release notes)
 *   - `4xx`:     BS-side caller bug (the library_identity row pointed at
 *                a sentinel ID LML rejects, etc.)
 *   - `network`: infra noise (transient TCP/DNS failures)
 *   - `other`:   uncategorised — investigate per-event
 *
 * Surfaced separately so a per-bucket regression doesn't get masked by the
 * rollup. Revisit (split the knob or tune the value) if Sentry shows p95
 * user-facing add-to-rotation > 2.5 s OR fallback rate > 5% in any bucket.
 */
export type LmlResolveFallbackReason = 'timeout' | '5xx' | '4xx' | 'network' | 'other';

/**
 * Classify the error caught from `resolveIdentity(...)` into one of the
 * five operational buckets above. Pulled out so the unit test can
 * exhaustively exercise every branch without spinning up an LML server.
 *
 * `LmlClientError` is the wrapper `lmlFetch` throws; its `statusCode` was
 * already translated upstream (5xx → 502, AbortError → 504). The catch
 * here untranslates so the Sentry attribute reads as the original
 * operational signal.
 */
export function classifyLmlResolveError(err: unknown): LmlResolveFallbackReason {
  if (!err || typeof err !== 'object') return 'other';
  const e = err as { name?: string; code?: string; statusCode?: number; message?: string };
  if (e.name === 'AbortError') return 'timeout';
  if (err instanceof LmlClientError) {
    // `lmlFetch` translates `AbortError` → 504 and upstream 5xx → 502; restore
    // the operational bucket from those translations + the raw status range.
    if (e.statusCode === 504) return 'timeout';
    if (e.statusCode === 502) {
      // 502 is overloaded: it's the wrapper for both upstream 5xx and a raw
      // fetch failure (the catch-all in `lmlFetch`). Disambiguate from the
      // message — "LML request failed" is the fetch-threw path.
      return typeof e.message === 'string' && e.message.startsWith('LML request failed') ? 'network' : '5xx';
    }
    if (typeof e.statusCode === 'number') {
      if (e.statusCode >= 500) return '5xx';
      if (e.statusCode >= 400) return '4xx';
    }
    return 'other';
  }
  if (e.code === 'ECONNRESET' || e.code === 'ENOTFOUND' || e.code === 'ECONNREFUSED') {
    return 'network';
  }
  return 'other';
}

/**
 * Add an album to rotation (dj-site path, `POST /library/rotation`).
 *
 * Synchronously triple-writes `(discogs_release_id, discogs_release_id_source =
 * 'library_identity', lml_identity_id)` when the album's `library_identity`
 * row supplies a non-NULL `discogs_release_id` (BS#1380):
 *
 *   1. Read `library_identity.discogs_release_id` for the requested
 *      `album_id`. `library_identity.library_id` is the PRIMARY KEY
 *      (see schema.ts:1391-1393); `LIMIT 1` is defensive.
 *   2. If non-NULL, `await resolveIdentity({kind:'release',
 *      source:'discogs_release', external_id})` to mint a stable
 *      `lml_identity_id`. The hop runs inside this handler — the response
 *      row carries the populated columns without needing a follow-up
 *      patch.
 *   3. INSERT all three columns. On resolve failure (timeout / 5xx /
 *      network), `lml_identity_id` falls back to NULL but
 *      `discogs_release_id` + `discogs_release_id_source = 'library_identity'`
 *      still land — the *source of the Discogs id* is library_identity
 *      regardless of whether the mint succeeded. The daily backfill cron
 *      catches up within ~24h.
 *
 * Rationale for synchronous-before-INSERT: dj-site's optimistic UI
 * (WXYC/dj-site#648) covers the latency tail at the client side — the row
 * appears in-rotation immediately on click. Blocking the music director on
 * an LML outage is worse than a temporarily-incomplete row, so the catch
 * arm proceeds rather than rethrowing.
 */
export const addToRotation = async (newRotation: RotationAddRequest) => {
  const values: RotationAddRequest = { ...newRotation };

  // Allowlist guard already runs at the controller layer, but the server-
  // derived fields below must always come from this function, not the
  // request — defense in depth.
  if (values.album_id != null) {
    const [identityRow] = await db
      .select({ discogs_release_id: library_identity.discogs_release_id })
      .from(library_identity)
      .where(eq(library_identity.library_id, values.album_id))
      .limit(1);
    const discogsReleaseId = identityRow?.discogs_release_id ?? null;

    // BS#1429: rotation.discogs_release_id rejects `0` and negative ids via
    // CHECK constraint. library_identity.discogs_release_id has no such
    // fence today, so a poisoned upstream value would 23514 this INSERT and
    // surface as a 5xx to the music director. Treat any non-positive value
    // as "no Discogs handle" — same graceful-degradation path the LML
    // resolve-failure catch arm already takes.
    if (discogsReleaseId != null && discogsReleaseId > 0) {
      // The source-of-the-Discogs-id is library_identity, regardless of
      // whether the LML mint that follows succeeds.
      values.discogs_release_id = discogsReleaseId;
      values.discogs_release_id_source = 'library_identity';

      let lmlIdentityId: number | null = null;
      try {
        const resolved = await resolveIdentity({
          kind: 'release',
          source: 'discogs_release',
          external_id: String(discogsReleaseId),
        });
        lmlIdentityId = resolved.identity_id;
      } catch (err) {
        const reason = classifyLmlResolveError(err);
        // BS#1380: classify once at fallback time so each reason bucket
        // signals a different operational response (timeout → LML
        // latency, 5xx → LML deploy regression, 4xx → BS-side caller bug,
        // network → infra noise). v10 SDK shape — `Sentry.metrics.count(
        // name, value, {attributes})`. Pre-v8
        // `Sentry.metrics.increment(..., {tags})` was removed.
        try {
          Sentry.metrics.count('lml.resolve.fallback_to_null', 1, {
            attributes: { caller: 'add_to_rotation', reason },
          });
        } catch {
          // Observability must never break the request path; swallow.
        }
        // lml_identity_id stays NULL; INSERT proceeds.
      }
      values.lml_identity_id = lmlIdentityId;
    }
  }

  const insertedRotation: RotationRelease[] = await db.insert(rotation).values(values).returning();
  return insertedRotation[0];
};

/**
 * Partial-update payload for `PATCH /library/rotation/:id` (BS#2113). Every
 * field is optional — `updateRotation` only SETs keys that are present, so
 * a typo fix on `artist_name` can't wipe `record_label` or reset
 * `kill_date`. Covers exactly the five columns the JSP editor's field set
 * maps onto a real `rotation` column (see the controller's
 * `ROTATION_NO_COLUMN_FIELDS` for the three that don't).
 *
 * `kill_date` additionally accepts a raw `SQL<unknown>` fragment — the sole
 * caller of that widened type is `killRotationInDB` below, whose no-date
 * default is `CURRENT_DATE` evaluated server-side. The public controller
 * surface only ever passes a plain ISO string or `null`.
 */
export type UpdateRotationRow = {
  artist_name?: string;
  album_title?: string;
  record_label?: string;
  add_date?: string;
  kill_date?: string | SQL<unknown> | null;
};

/**
 * The three denormalized snapshot columns `updateRotation` may only set on
 * an unlinked row — see the controller's `updateRotation` JSDoc for why.
 *
 * Exported, and the single declaration of this tuple in the codebase. The
 * compare-and-set WHERE, the tracklist-cache invalidation branch below
 * (BS#2113 review findings 4 and 1), and the controller's request validation +
 * 409 message builder all read off it. An earlier revision declared it here and
 * again in the controller as `ROTATION_SNAPSHOT_FIELDS` — two lists governing
 * one invariant, which is precisely the drift this comment claimed to prevent.
 */
export const ROTATION_SNAPSHOT_COLUMNS = ['artist_name', 'album_title', 'record_label'] as const;

/**
 * Outcome of a `PATCH /library/rotation/:id` write attempt (BS#2113).
 * `linked_conflict` carries the row's `album_id` as observed by the write
 * itself — not by an earlier read — so the controller's 409 names the
 * correct release even when the link happened concurrently with the
 * request (review finding 4).
 */
export type UpdateRotationOutcome =
  | { outcome: 'updated'; rotation: RotationRelease }
  | { outcome: 'not_found' }
  | { outcome: 'linked_conflict'; albumId: number };

/**
 * Sole writer of the five in-scope `rotation` columns among the
 * `/library/rotation*` HTTP surfaces (BS#2113): both
 * `PATCH /library/rotation/:id` (`updateRotation` controller handler) and
 * `PATCH /library/rotation` (`killRotation`, via `killRotationInDB` below)
 * delegate here rather than issuing their own UPDATE — the
 * `rotation_bin` divergence (two writers, one column, drifting SET clauses)
 * is the failure mode a shared writer forecloses.
 *
 * NOT the only writer of `rotation.kill_date` process-wide: the tubafrenzy
 * webhook in `apps/backend/routes/internal.route.ts` sets it directly on its
 * kill/unkill branches, keyed on `legacy_rotation_id` rather than `id`. That
 * is a deliberately separate write path (a legacy-id-keyed mirror, not an
 * HTTP edit surface) — grep before assuming exclusivity.
 *
 * Two review findings folded into this one function rather than left as two
 * separate patches:
 *
 *   - **Finding 1 (stale tracklist-picker cache).** Editing any member of
 *     the snapshot trio changes the text `resolveRotationDiscogsReleaseViaLml`
 *     (the tier-3 tracklist-picker cascade) keys its cache on, so the same
 *     write NULLs `rotation.tracklist_lookup_attempted_at` in its own SET and
 *     evicts this `rotation_id` from both `rotationLmlPositiveCache` and
 *     `rotationLmlNegativeCache` once the transaction has committed.
 *
 *     Scope, stated precisely because an earlier revision of this comment
 *     overstated it: this clears **tier 3 only**. `resolveRotationPickerSource`
 *     returns at its `stored !== null` short-circuit — on
 *     `rotation.discogs_release_id`, or the `library_identity` fallback —
 *     *before* it consults either the stamp or these caches. So on a row
 *     already carrying a direct release id, correcting the free text does not
 *     change which release the picker serves, even though the text that id was
 *     derived from just changed. Clearing a machine-derived
 *     `discogs_release_id` on a snapshot edit is the real fix; it means
 *     reasoning about `discogs_release_id_source` (a trust-gated column —
 *     `md_verified` and `tubafrenzy_paste` must survive), so it is deliberately
 *     not done here. Tracked in BS#2214.
 *   - **Finding 4 (TOCTOU).** The snapshot trio may only be set on an
 *     unlinked row (`album_id IS NULL`). `rotation` is a live ingest
 *     target — the tubafrenzy rotation webhook
 *     (`POST /internal/rotation-webhook`) can link this exact row in the
 *     window between a caller's read and a naive write — so the precondition
 *     is asserted in the UPDATE's own WHERE, never trusted from an earlier
 *     SELECT. A zero-row result while the trio is present means "this row
 *     is linked as of right now", not "this row doesn't exist" or "the
 *     write silently no-opped". Mirrors the re-guarded-WHERE discipline in
 *     `linkRotationToAlbum` / `legacy-linkage-resolve`: a guarded write, then
 *     one more read — inside the same transaction — to tell "no such row"
 *     apart from "row changed under us" when the write matches nothing.
 */
export const updateRotation = async (
  rotation_id: number,
  updates: UpdateRotationRow
): Promise<UpdateRotationOutcome> => {
  const set: Record<string, unknown> = {};
  for (const key of ['artist_name', 'album_title', 'record_label', 'add_date', 'kill_date'] as const) {
    if (updates[key] !== undefined) set[key] = updates[key];
  }
  // Drizzle's `mapUpdateSet` throws `No values to set` on an empty payload
  // before it generates any SQL. Refuse it here instead, so a future direct
  // caller gets a message naming this function rather than an opaque ORM
  // error. Unreachable through either HTTP surface: the controller 400s on
  // an empty body and `killRotationInDB` always supplies a `kill_date`.
  if (Object.keys(set).length === 0) {
    throw new WxycError('updateRotation requires at least one column to set', 400);
  }

  const touchesSnapshot = ROTATION_SNAPSHOT_COLUMNS.some((key) => key in set);

  // Only the snapshot path needs a transaction. Its guarded UPDATE can match
  // zero rows for two different reasons, and telling them apart takes a second
  // read that has to see the same snapshot. The other path — an `add_date` /
  // `kill_date`-only edit, which is every `PATCH /library/rotation` kill via
  // `killRotationInDB` — is a single statement, so wrapping it would turn one
  // round trip into three (BEGIN / UPDATE / COMMIT) and hold a pooled
  // connection across all three on a box that also serves the live flowsheet.
  // That endpoint issued one bare UPDATE before BS#2113; keep it that way.
  if (!touchesSnapshot) {
    const [updated] = await db.update(rotation).set(set).where(eq(rotation.id, rotation_id)).returning();
    // No guard beyond `id` in the WHERE — zero rows really does mean "no such
    // row", exactly as before this function returned a bare row.
    return updated ? { outcome: 'updated' as const, rotation: updated } : { outcome: 'not_found' as const };
  }

  set.tracklist_lookup_attempted_at = null;

  const outcome = await db.transaction(async (tx): Promise<UpdateRotationOutcome> => {
    const updatedRows = await tx
      .update(rotation)
      .set(set)
      .where(and(eq(rotation.id, rotation_id), isNull(rotation.album_id)))
      .returning();
    const updated = updatedRows[0];
    if (updated) {
      return { outcome: 'updated' as const, rotation: updated };
    }

    // The guarded UPDATE matched nothing: either the row doesn't exist, or a
    // concurrent writer linked it since the caller last looked. One more
    // read, inside the same transaction, tells the two apart.
    const [current] = await tx
      .select({ album_id: rotation.album_id })
      .from(rotation)
      .where(eq(rotation.id, rotation_id))
      .limit(1);
    if (!current || current.album_id === null) {
      // Either genuinely gone, or (a second concurrent write unlinked it
      // again in the instant between our failed guarded UPDATE and this
      // read) not actually linked after all. Neither is a 409 the caller
      // can act on, so report not-found rather than fabricate an album id.
      return { outcome: 'not_found' as const };
    }
    return { outcome: 'linked_conflict' as const, albumId: current.album_id };
  });

  // Evict AFTER the commit, never inside it. Between an in-transaction evict
  // and the commit, a concurrent `/library/rotation/:id/tracks` read on its own
  // connection still sees the pre-commit text and can re-prime the very entry
  // this write just cleared — which would then outlive the commit for the full
  // TTL. Post-commit, any racing reader primes from the new text instead.
  if (outcome.outcome === 'updated') {
    rotationLmlPositiveCache.delete(rotation_id);
    rotationLmlNegativeCache.delete(rotation_id);
  }
  return outcome;
};

/**
 * Explicit SELECT list for `GET /library/rotation/uncatalogued` (BS#2109).
 *
 * Deliberately a projection, not `select()`. `rotation` also carries
 * `legacy_rotation_id`, `legacy_library_release_id`, `discogs_release_id`,
 * `discogs_release_id_source`, `lml_identity_id`,
 * `tracklist_lookup_attempted_at` and
 * `discogs_release_id_resolve_attempted_at` — server-derived plumbing that
 * `getRotationFromDB`'s SELECT list does not publish either, and that
 * `tests/integration/library.spec.js` pins the rotation surface against
 * exposing flat. A bare `select()` would also auto-publish every column a
 * future migration adds, and WXYC/wxyc-shared#354 transcribes whatever this
 * returns into a published contract.
 */
const UNCATALOGUED_ROTATION_PROJECTION = {
  id: rotation.id,
  album_id: rotation.album_id,
  rotation_bin: rotation.rotation_bin,
  add_date: rotation.add_date,
  kill_date: rotation.kill_date,
  artist_name: rotation.artist_name,
  album_title: rotation.album_title,
  record_label: rotation.record_label,
} as const;

/**
 * Derived from the projection rather than restating its key list, so adding a
 * column to `UNCATALOGUED_ROTATION_PROJECTION` without widening the type (or
 * the reverse) is a compile error instead of silent drift.
 */
export type UncataloguedRotationRow = Pick<RotationRelease, keyof typeof UNCATALOGUED_ROTATION_PROJECTION>;

/**
 * Project a full `rotation` row down to the published surface — the same eight
 * columns `UNCATALOGUED_ROTATION_PROJECTION` selects, so the rotation surface
 * has ONE published shape rather than one per endpoint.
 *
 * Applied by the CALLER, deliberately not inside `updateRotation`'s
 * `.returning()`. `killRotationInDB` delegates to that same writer and
 * unwraps `outcome.rotation` straight onto `PATCH /library/rotation`'s
 * response, so narrowing the writer would silently change a pre-existing
 * endpoint's wire shape as a side effect of adding a new one. That endpoint's
 * leak of the server-derived columns is real but is its own change, with its
 * own consumer check.
 */
export function toRotationRowSummary(row: RotationRelease): UncataloguedRotationRow {
  // Destructured explicitly rather than built via `Object.fromEntries(...) as
  // UncataloguedRotationRow`. That form type-checks through `fromEntries`'s
  // `{[k: string]: T}` return, so the `as` silences exactly the drift error
  // `UncataloguedRotationRow`'s own docblock promises: widen
  // `UNCATALOGUED_ROTATION_PROJECTION` without widening the type (or the
  // reverse) and the cast keeps compiling. Written out, either direction is a
  // compile error — which is the guarantee that was being advertised.
  const { id, album_id, rotation_bin, add_date, kill_date, artist_name, album_title, record_label } = row;
  return { id, album_id, rotation_bin, add_date, kill_date, artist_name, album_title, record_label };
}

/**
 * Ceiling on `?limit=` for the uncatalogued queue, and the default when the
 * caller omits it — so "omit `limit`" means "give me the largest page I could
 * have asked for", never "give me the whole table".
 *
 * The cap is deliberately not a per-endpoint concern. It lives on the query
 * because an unbounded default is a property of the read, not of one route:
 * the backlog is ~3.8k rows (≈700 KB of JSON) and this runs on a single-worker
 * 1 GB box that also serves the live flowsheet. It is also cheaper to set now
 * than later — `wxyc-shared#354` is about to transcribe this shape into the
 * published cross-repo contract, and narrowing "omit ⇒ everything" after a
 * client depends on it is a breaking change.
 */
export const UNCATALOGUED_ROTATION_MAX_LIMIT = 500;

/** Optional window over the queue. `limit` defaults to the max above. */
export type UncataloguedRotationPage = { limit?: number; offset?: number };

/**
 * Read-side query for `GET /library/rotation/uncatalogued` (BS#2109).
 *
 * The cataloging-backlog queue. Unlike `getRotationFromDB`, this is
 * deliberately:
 *
 *   - **NOT `DISTINCT ON`-collapsed.** Two physically distinct promos
 *     sharing an artist and title are two separate rows a librarian has to
 *     catalogue; `getRotationFromDB`'s dedup exists for its dropdown shape
 *     and would silently hide one of them here.
 *   - **Not `LEFT JOIN`ed to `library`/`artists`/`format`/`genres`.** Every
 *     row this predicate selects is unlinked by definition, so those joins
 *     would return NULL for every column on every row. Returns the raw
 *     `rotation` snapshot columns instead.
 *   - **Not restricted to active (`kill_date`) rows.** The queue is the
 *     full cataloging backlog (killed/historical releases still need
 *     cataloguing, or a record of never having been), not a live dropdown.
 *
 * **`album_id IS NULL` is the whole unlinked predicate.** An earlier draft
 * used `COALESCE(album_id, 0) = 0` on the belief that tubafrenzy writes a
 * `0` sentinel here. It does not: `rotation.album_id` carries
 * `rotation_album_id_library_id_fk → library.id`, `library.id` is a `serial`
 * starting at 1, so a stored `0` would violate the FK; the webhook writer
 * normalizes its raw upstream id with `rawLibraryId || null`
 * (`internal.route.ts`) before `resolveAlbumId`; and the seed clone holds
 * zero `album_id = 0` rows out of 21,625. The 0/NULL duality is real but
 * lives on `legacy_library_release_id`, a different column. `IS NULL` is
 * also sargable against `album_id_idx`, which `COALESCE(...)` was not.
 * `addRotation` (400 on `album_id: 0`) and `linkRotationToAlbum`
 * (`isNull(rotation.album_id)`) agree with this reading.
 */
export const getUncataloguedRotationFromDB = async (
  page: UncataloguedRotationPage = {}
): Promise<UncataloguedRotationRow[]> => {
  const { limit = UNCATALOGUED_ROTATION_MAX_LIMIT, offset } = page;
  const windowed = db
    .select(UNCATALOGUED_ROTATION_PROJECTION)
    .from(rotation)
    .where(isNull(rotation.album_id))
    .orderBy(desc(rotation.add_date), asc(rotation.id))
    .limit(limit);

  return offset == null ? windowed : windowed.offset(offset);
};

export type LinkRotationOutcome =
  | { outcome: 'linked'; rotation: UncataloguedRotationRow }
  | { outcome: 'rotation_not_found' }
  | { outcome: 'already_linked' }
  | { outcome: 'album_not_found' };

/**
 * Links an uncatalogued rotation row to a library release (BS#2109's
 * `PATCH /library/rotation/:rotation_id/link` — the "Import to Library"
 * step of the tubafrenzy `/wxycdb` workflow).
 *
 * **Review round 3 finding 1: deliberately does NOT clear `artist_name` /
 * `album_title` / `record_label`.** The first revision cleared the trio in
 * the same transaction, matching `jobs/legacy-linkage-resolve` — reasoning
 * that display reads through the `library` join once linked, so stale free
 * text would never surface. True for `getRotationFromDB`
 * (`COALESCE(artists.artist_name, rotation.artist_name)` always prefers the
 * joined canonical value once `album_id` resolves; clearing the snapshot is
 * display-invisible there) but wrong for `resolveRotationPickerSource`'s
 * three-tier tracklist resolution: tier 1 (`rotation.discogs_release_id`)
 * and tier 2 (`library_identity.discogs_release_id` via the `album_id`
 * bridge, ~24% coverage) are both very likely still NULL immediately after a
 * link — `addToRotation`'s synchronous `library_identity` → `resolveIdentity`
 * hop only runs on `POST /library/rotation`, never here — and clearing the
 * snapshot also removed tier 3's only input:
 * `resolveRotationDiscogsReleaseViaLml(rotationId, artist_name, album_title)`
 * short-circuits on `if (!artistName || !albumTitle) return null`. The
 * picker ended up strictly worse than before the link, with no self-heal:
 * `jobs/rotation-release-id-backfill`'s candidate query requires
 * `artist_name IS NOT NULL AND album_title IS NOT NULL`, and
 * `jobs/rotation-lml-identity-backfill`'s requires
 * `discogs_release_id IS NOT NULL` — each needs what only the other could
 * have produced.
 *
 * Leaving the trio in place costs nothing display-side and re-opens both
 * self-heal paths: tier 3 keeps working immediately after the link, and
 * `rotation-release-id-backfill`'s 6-hourly cron (17 minutes past the hour,
 * every sixth hour, UTC) can now pick the row up
 * (its candidate query has no `album_id` predicate) and mint
 * `discogs_release_id`, which unblocks `rotation-lml-identity-backfill` in
 * turn. The alternative fix — replicate `addToRotation`'s synchronous
 * `library_identity` → `resolveIdentity` hop inside this transaction — was
 * rejected: it only helps the ~24% of albums `library_identity` already has
 * a resolved handle for, and it would add an LML round-trip inside a
 * librarian-facing, otherwise-instant endpoint's transaction for no benefit
 * on the other 76%.
 *
 * This produces the "`album_id` set AND snapshot set" shape — and, unlike an
 * earlier revision, it now simply persists. That earlier revision paired
 * this function with a `POST /internal/rotation-webhook` SET clause that
 * nulled the trio out on the row's next `/wxycdb` edit; that CASE-based
 * gating was itself the bug (it starved both self-heal paths above of the
 * columns they need) and has been removed — the webhook's UPDATE path now
 * writes `excluded.*` unconditionally for the trio, same as this function.
 * So the shape lasts until `jobs/rotation-release-id-backfill` mints a
 * `discogs_release_id` for the row (its candidate query has no `album_id`
 * predicate, so a linked row with a populated snapshot is picked up the same
 * as an unlinked one) — the self-heal path this function exists to keep
 * open by leaving the trio in place.
 *
 * The final UPDATE re-guards `album_id IS NULL` in its own WHERE (not just
 * the earlier SELECT) so a concurrent link between the check and the write
 * can't silently double-link the row — mirrors the `f.album_id IS NULL` /
 * `r.album_id IS NULL` re-check discipline in `legacy-linkage-resolve`.
 *
 * "Unlinked" is NULL and only NULL here, matching
 * `getUncataloguedRotationFromDB`'s read predicate and `addRotation`'s
 * rejection of `album_id: 0` — see that function's doc for why no `0`
 * sentinel exists on this column.
 *
 * **Review round 3 finding 4:** `.returning()` is projected through the same
 * `UNCATALOGUED_ROTATION_PROJECTION` the queue read uses, rather than a bare
 * `.returning()` — the raw row publishes the same seven server-derived
 * columns (`legacy_rotation_id`, `legacy_library_release_id`,
 * `discogs_release_id`, `discogs_release_id_source`, `lml_identity_id`, and
 * the two attempt-at markers) that projection exists to keep off the wire,
 * and `tests/integration/library.spec.js` pins the rotation surface against
 * exposing them. `addRotation`'s unprojected `.returning()` is pre-existing
 * and out of scope here — it publishes onto a freshly-inserted row this
 * client just supplied every field of, not a read of someone else's data.
 */
export const linkRotationToAlbum = async (rotationId: number, albumId: number): Promise<LinkRotationOutcome> => {
  return db.transaction(async (tx) => {
    const [albumRow] = await tx.select({ id: library.id }).from(library).where(eq(library.id, albumId)).limit(1);
    if (!albumRow) {
      return { outcome: 'album_not_found' as const };
    }

    const [existingRotation] = await tx
      .select({ album_id: rotation.album_id })
      .from(rotation)
      .where(eq(rotation.id, rotationId))
      .limit(1);
    if (!existingRotation) {
      return { outcome: 'rotation_not_found' as const };
    }
    if (existingRotation.album_id != null) {
      return { outcome: 'already_linked' as const };
    }

    const [updated] = await tx
      .update(rotation)
      .set({ album_id: albumId })
      .where(and(eq(rotation.id, rotationId), isNull(rotation.album_id)))
      .returning(UNCATALOGUED_ROTATION_PROJECTION);

    if (!updated) {
      // Race: another request linked this row between the check above and
      // this UPDATE's own re-guarded WHERE.
      return { outcome: 'already_linked' as const };
    }

    return { outcome: 'linked' as const, rotation: updated };
  });
};

export const killRotationInDB = async (rotationId: number, updatedKillDate?: string) => {
  const outcome = await updateRotation(rotationId, { kill_date: updatedKillDate || sql`CURRENT_DATE` });
  return outcome.outcome === 'updated' ? outcome.rotation : undefined;
};

export const insertAlbum = async (newAlbum: NewAlbum) => {
  const response = await db.insert(library).values(newAlbum).returning();
  return response[0];
};

/**
 * Look up the resolved Discogs release id for a library row by its
 * legacy id — the id the dj-site flowsheet picker carries (LML
 * `library.db.id` = BS `library.legacy_release_id`). JOINs `library`
 * to `library_identity` via that bridge in a single query.
 *
 * Returns null when any of these holds (the picker degrades to free-text):
 *   - legacy id doesn't map to a BS library row,
 *   - the row has no `library_identity` entry (not yet backfilled by BS#802), or
 *   - the identity row has no resolved `discogs_release_id`.
 *
 * Used by `/proxy/library/{id}/tracks` (E6-5 / BS#836) to compose against
 * LML's `/api/v1/discogs/release/{id}` for the tracklist.
 */
export async function getDiscogsReleaseIdByLegacyId(legacyId: number): Promise<number | null> {
  const rows = await db
    .select({ discogs_release_id: library_identity.discogs_release_id })
    .from(library)
    .innerJoin(library_identity, eq(library_identity.library_id, library.id))
    .where(eq(library.legacy_release_id, legacyId))
    .limit(1);
  return rows[0]?.discogs_release_id ?? null;
}

/**
 * Per-rotation_id LRU for the LML `POST /api/v1/lookup` fallback in
 * `resolveRotationPickerSource`. The dj-site picker is opened many times
 * per session against a handful of rotation rows; caching avoids restarting
 * the LML query for each open. Mirrors tubafrenzy's `RotationTracklistCache`
 * concept (process-local map keyed by rotation id), minus the warm-on-startup
 * pass.
 *
 * Two caches — positive (resolved release id) and negative (LML returned
 * nothing). lru-cache v11 constrains value types to non-nullable, so the
 * negative cache stores `true` and uses key presence as the signal. Both
 * TTLs are 24 h: Discogs release tracklists and the negative classification
 * ("no Discogs release for this artist+album") are both stable conditions
 * that don't flip within a day; deploys re-warm both caches via the
 * `rotation-tracks-cache-warm` walker (BS#1231); 24 h is a soft ceiling
 * against drift, not a refresh interval.
 *
 * (Distinct from `proxy.controller.ts`'s artwork/negativeCache pair, which
 * uses a 1 h positive TTL because artwork images can be re-uploaded but the
 * Discogs release ID for a given (artist, album) is effectively immutable.)
 */
const MS_PER_DAY = 24 * 60 * 60 * 1000;
const ROTATION_LML_LOOKUP_CACHE_MAX = 500;
const ROTATION_LML_LOOKUP_TTL_POSITIVE_MS = MS_PER_DAY;
const ROTATION_LML_LOOKUP_TTL_NEGATIVE_MS = MS_PER_DAY;
/**
 * How long a persisted `rotation.tracklist_lookup_attempted_at` stamp
 * suppresses re-asking LML. Negative outcomes here are "this artist+album
 * combo isn't resolvable to a Discogs release" — a stable condition that
 * rarely flips. 7 days lets a music-director typo correction self-heal
 * within a week without being so aggressive that we re-pay the 22 s cascade
 * cost on every deploy.
 */
const ROTATION_TRACKLIST_LOOKUP_NEGATIVE_WINDOW_MS = 7 * MS_PER_DAY;
// BS#1826 PR 2: `ROTATION_LML_LOOKUP_TIMEOUT_MS`, `LIBRARY_INTERACTIVE_LML_
// BUDGET_MS`, and `LIBRARY_SEARCH_LML_BUDGET_MS` retired — all three now
// come from the per-caller policy layer (`@wxyc/lml-client` `policy.ts`):
// `library-rotation-picker` is the BS#992/BS#1186 class-2 override (10s
// timeout / 9000ms budget, preserving the "no aggressive budget cap"
// rationale below), `library-track-search` is class 2 (4000ms budget /
// 5000ms timeout), and `library-enrich-artwork` is the #1828 class-2
// override (`LIBRARY_SEARCH_LML_BUDGET_MS` env name preserved as the
// override's env lever). See `docs/env-vars.md` for the retired-constant
// → class mapping.
//
// Per-call LML timeout for the picker's tier-3 lookup. 10 s matches
// tubafrenzy's `RELEASE_LOOKUP_TIMEOUT` (`LibrarySearchClient.java:64`),
// which is the parity bar we measure picker coverage against. Shorter
// timeouts cut off LML's cascade before the later strategies that find
// obscure college-rotation releases get to run — the source of the
// coverage regression that motivated dropping the BS#1186 budget.
//
// Intentionally no `budgetMs` companion: BS#1186 added a 4 s
// `X-Caller-Budget-Ms` header to short-circuit LML's empty-results
// cascade. That cap was justified by malformed-query examples
// (track-titles-as-album-names) and applied uniformly across callers,
// including this one. For the picker — which always passes real
// `(artist_name, album_title)` pairs from rotation rows — the cascade's
// later strategies are exactly where matches come from, so capping at
// 4 s collapsed picker coverage to ~23 %. The iOS proxy/artwork hot-path
// callers keep their budgets; only this call site opts out.

/**
 * Wire shape returned by `GET /library/rotation/:rotation_id/tracks`. The
 * dj-site rotation entry picker (`useGetRotationTracksQuery`) consumes this
 * directly — keep field names + types in lockstep with the dj-site
 * `RotationTrack` type in `lib/features/rotation/api.ts`. Re-exported from
 * `apps/backend/controllers/library.controller.ts` for the surface that
 * consumers reference today.
 */
export interface RotationTrack {
  position: string;
  title: string;
  duration: string | null;
  artists: string[];
}

/**
 * What `resolveRotationPickerSource` hands back to the picker controller.
 *
 * The controller short-circuits whenever `inlineTracklist !== null` and
 * returns it as the response. That covers both:
 *   - tier 3 Discogs hit with `extended=true` (LML returned the tracklist
 *     in the same response we asked for the release id), and
 *   - tier 3 MusicBrainz rescue (LML synthesized the result; `releaseId`
 *     is `null` because there's no Discogs release behind it — BS#1185).
 *
 * When `inlineTracklist === null` the controller calls `getRelease(releaseId)`
 * and projects its tracklist. That path is taken for tiers 1 and 2 (stored
 * id, no LML round-trip) and for tier-3 responses that LML couldn't extend
 * with a tracklist (e.g. extended-mode payload was suppressed upstream).
 */
export interface RotationPickerSource {
  releaseId: number | null;
  inlineTracklist: RotationTrack[] | null;
}

const rotationLmlPositiveCache = new LRUCache<number, RotationPickerSource>({
  max: ROTATION_LML_LOOKUP_CACHE_MAX,
  ttl: ROTATION_LML_LOOKUP_TTL_POSITIVE_MS,
  ttlAutopurge: true,
});

const rotationLmlNegativeCache = new LRUCache<number, true>({
  max: ROTATION_LML_LOOKUP_CACHE_MAX,
  ttl: ROTATION_LML_LOOKUP_TTL_NEGATIVE_MS,
  ttlAutopurge: true,
});

export function __resetRotationLmlLookupCacheForTests(): void {
  rotationLmlPositiveCache.clear();
  rotationLmlNegativeCache.clear();
}

/**
 * Current sizes of the rotation LML LRUs. Used by the rotation-tracks
 * cache-warm service (BS#998) to classify warm-pass outcomes per row
 * (positive-cache-hit vs negative-cache-hit) without coupling to LRU
 * internals. Underscored so it stays out of the public service surface —
 * production callers should not depend on cache shape.
 */
export function __rotationLmlCacheSizesForWarm(): { positive: number; negative: number } {
  return {
    positive: rotationLmlPositiveCache.size,
    negative: rotationLmlNegativeCache.size,
  };
}

/**
 * Resolve the source the rotation-tracks picker should render against, by
 * `rotation_id`. Returns either a `releaseId` the controller can hand to
 * `getRelease(id)`, an inline tracklist the controller can return as-is, or
 * `null` if every tier missed and the picker should degrade to free-text.
 *
 * Three-tier resolution to match tubafrenzy's `RotationTracklistCache` parity
 * (see BS#986):
 *
 *   1. `rotation.discogs_release_id` (direct) — mirrored from tubafrenzy
 *      `ROTATION_RELEASE.DISCOGS_RELEASE_ID` by `jobs/rotation-etl`. Populated
 *      via the rotation-add form's paste-URL prefill flow.
 *      → `{ releaseId, inlineTracklist: null }`
 *   2. `library_identity.discogs_release_id` via the `album_id` bridge
 *      (fallback) — written by `jobs/library-identity-consumer` (BS#802).
 *      → `{ releaseId, inlineTracklist: null }`
 *   3. LML `POST /api/v1/lookup` on `(rotation.artist_name, rotation.album_title)`
 *      with `extended=true` — the same `(artist, title)` lookup tubafrenzy's
 *      `RotationTracklistCache.fetchAndCache` uses, but extended to carry the
 *      tracklist inline. When LML returns a tracklist (Discogs hit OR
 *      MusicBrainz-rescued synth path on the BS#1185 sentinel + LML#427),
 *      the controller returns it directly; no follow-up `getRelease(id)`
 *      round-trip needed. Per-`rotation_id` LRU caches positive and negative
 *      outcomes.
 *      → `{ releaseId, inlineTracklist }`
 *
 * Returns null when all three tiers miss: rotation row doesn't exist; the
 * row has no `artist_name` or `album_title`; LML returns no results,
 * isn't configured, or fails. The picker degrades to free-text.
 *
 * Used by `/library/rotation/:rotation_id/tracks` (BS#940). Parallel to
 * `getDiscogsReleaseIdByLegacyId` (BS#836) which the catalog-search picker
 * uses via `legacy_release_id`.
 */
export async function resolveRotationPickerSource(rotationId: number): Promise<RotationPickerSource | null> {
  const rows = await db
    .select({
      direct: rotation.discogs_release_id,
      fallback: library_identity.discogs_release_id,
      artist_name: rotation.artist_name,
      album_title: rotation.album_title,
      tracklist_lookup_attempted_at: rotation.tracklist_lookup_attempted_at,
    })
    .from(rotation)
    .leftJoin(library_identity, eq(library_identity.library_id, rotation.album_id))
    .where(eq(rotation.id, rotationId))
    .limit(1);
  if (!rows[0]) return null;

  const stored = rows[0].direct ?? rows[0].fallback ?? null;
  if (stored !== null) return { releaseId: stored, inlineTracklist: null };

  // Persistent negative marker. The in-memory rotationLmlNegativeCache covers
  // within-process repeats; this column covers across-restart so the 28-row
  // "negative" set doesn't re-pay 22 s cascade exhaustion on every deploy.
  const attemptedAt = rows[0].tracklist_lookup_attempted_at;
  if (attemptedAt && Date.now() - attemptedAt.getTime() < ROTATION_TRACKLIST_LOOKUP_NEGATIVE_WINDOW_MS) {
    return null;
  }

  return resolveRotationDiscogsReleaseViaLml(rotationId, rows[0].artist_name, rows[0].album_title);
}

/**
 * Tier-3 of `resolveRotationPickerSource`. Asks LML to identify the
 * Discogs release for a rotation row's `(artist_name, album_title)` when
 * the direct column and `library_identity` fallback both miss. Mirrors
 * tubafrenzy's `RotationTracklistCache.fetchAndCache`, which calls
 * `LibrarySearchClient.searchDiscogsRelease` → `POST /api/v1/lookup`.
 *
 * Caches positive and negative results per `rotation_id`. The negative
 * TTL is shorter so rows that become resolvable (LML catalog improvements,
 * Discogs additions) recover within minutes rather than waiting for a
 * process restart. No DB cache-through here — tubafrenzy's MySQL column
 * isn't a write target on this path either, and a column-mix between
 * paste-URL-prefilled and LML-resolved values would muddy provenance.
 *
 * Bounded at 10 s per call (the `library-rotation-picker` class-2 policy
 * override, BS#1826) — fast-fail for the user-visible picker (BS#992).
 * Caller errors are swallowed so
 * the picker degrades to free-text rather than 500ing; the LML client
 * already wraps the call in a Sentry span carrying `lml.cache.*` and
 * `lml.queue_depth` attributes for trace-explorer drill-down.
 */
/**
 * Detect Various-Artists artist-name variants the picker should omit from
 * the LML lookup. Mirrors tubafrenzy's `LibrarySearchClient.isVariousArtistsName`
 * (`LibrarySearchClient.java:429`): passing "Various Artists" pollutes
 * LML's fuzzy matching and surfaces unrelated compilations instead of the
 * actual release. LML's /lookup orchestrator supports the album-only path.
 *
 * Exported for the unit-test parity matrix; not part of the public service
 * surface.
 */
export function isVariousArtistsName(name: string): boolean {
  const trimmed = name.trim().toLowerCase();
  if (trimmed.length === 0) return false;
  if (/^v[\s./]*a\.?$/.test(trimmed)) return true;
  if (trimmed === 'various') return true;
  if (/^various\s+art/.test(trimmed)) return true;
  if (/^var\.?\s+art/.test(trimmed)) return true;
  return false;
}

async function resolveRotationDiscogsReleaseViaLml(
  rotationId: number,
  artistName: string | null,
  albumTitle: string | null
): Promise<RotationPickerSource | null> {
  if (!artistName || !albumTitle) return null;
  if (!isLmlConfigured()) return null;

  const cachedPositive = rotationLmlPositiveCache.get(rotationId);
  if (cachedPositive !== undefined) return cachedPositive;
  if (rotationLmlNegativeCache.has(rotationId)) return null;

  const lookupArtist = isVariousArtistsName(artistName) ? undefined : artistName;

  let source: RotationPickerSource | null;
  try {
    // BS#1351: non-direct `search_type` values surface candidates for the wrong
    // album (Yenbett → Tzenni). The coordinator enforces the gate via
    // `requireSearchType: 'direct'` and projects `lml.coordinator.trust_reject_reason`
    // on the per-lookup span. LML's `fetch_one` enforces the 80/80 album-title
    // floor for `direct` matches, so this is sufficient — the picker falls
    // through to free-text on rejection.
    const response = await lmlLookupCoordinator.lookup(lookupArtist, albumTitle, undefined, {
      caller: 'library-rotation-picker',
      requireSearchType: 'direct',
    });
    if (response === null) {
      source = null;
    } else {
      const artwork = response.results?.[0]?.artwork ?? null;
      // `release_id: 0` is LML's MusicBrainz-rescued synth sentinel
      // (orchestrator.py emits it when ARTIST_PLUS_ALBUM hits but Discogs
      // carries no artwork). Treat as "no Discogs id" so the controller
      // doesn't follow up with `/discogs/release/0`. The tracklist on the
      // synth result is still valid and is what the picker hands to the DJ.
      const rawReleaseId = artwork?.release_id ?? null;
      const releaseId = rawReleaseId !== null && rawReleaseId > 0 ? rawReleaseId : null;
      const inlineTracklist = projectInlineTracklist(artwork?.tracklist, artistName);
      source = releaseId !== null || inlineTracklist !== null ? { releaseId, inlineTracklist } : null;
    }
  } catch (err) {
    console.warn(
      '[library.service] LML /lookup for rotation_id=%d failed; degrading picker to free-text: %s',
      rotationId,
      (err as Error).message
    );
    return null;
  }

  if (source !== null) {
    rotationLmlPositiveCache.set(rotationId, source);
  } else {
    rotationLmlNegativeCache.set(rotationId, true);
    // Best-effort persistent stamp — the in-memory LRU is enough for the
    // current request; the column survives restarts. Failure logs and is
    // swallowed so the picker response isn't blocked on the write.
    void (async () => {
      try {
        await db
          .update(rotation)
          .set({ tracklist_lookup_attempted_at: sql`NOW()` })
          .where(eq(rotation.id, rotationId));
      } catch (err) {
        console.warn(
          '[library.service] failed to stamp rotation.tracklist_lookup_attempted_at for rotation_id=%d: %s',
          rotationId,
          (err as Error).message
        );
      }
    })();
  }

  return source;
}

/**
 * Project the LML tracklist shape onto the picker's wire shape. Shared
 * between the service's `extended=true` inline path (BS#1185 + LML#427)
 * and the controller's follow-up `getRelease(id)` path so the two surfaces
 * can't drift. Returns `null` (not `[]`) when the tracklist is absent so
 * the caller can distinguish "LML carried tracks" from "fall through to
 * the release fetch". `artistFallback` is rendered against any track whose
 * per-track `artists[]` is empty.
 */
export function projectInlineTracklist(
  tracklist: ReadonlyArray<DiscogsTrackItem> | null | undefined,
  artistFallback: string
): RotationTrack[] | null {
  if (!tracklist || tracklist.length === 0) return null;
  return tracklist.map((t) => ({
    position: t.position,
    title: t.title,
    duration: t.duration ?? null,
    artists: t.artists && t.artists.length > 0 ? Array.from(t.artists) : [artistFallback],
  }));
}

/**
 * Per-`release_id` LRU on the projected `RotationTrack[]` from LML's
 * `GET /api/v1/discogs/release/{id}`. Absorbs the dominant cost on the
 * rotation-tracks picker — the LML release-fetch endpoint takes 2-9 s on
 * Discogs cache miss vs. 78 ms warm.
 *
 * Positive TTL is long (24 h) because Discogs release tracklists are
 * effectively immutable. Negative TTL is short so a release that becomes
 * known to Discogs recovers quickly. In-flight map coalesces concurrent
 * dropdown opens on the same release so a cold-deploy burst pays the
 * cold-path once across DJs, not once per DJ.
 */
const RELEASE_TRACKLIST_CACHE_MAX = 500;
const RELEASE_TRACKLIST_TTL_POSITIVE_MS = MS_PER_DAY;
const RELEASE_TRACKLIST_TTL_NEGATIVE_MS = 10 * 60 * 1000;

const releaseTracklistPositiveCache = new LRUCache<number, RotationTrack[]>({
  max: RELEASE_TRACKLIST_CACHE_MAX,
  ttl: RELEASE_TRACKLIST_TTL_POSITIVE_MS,
  ttlAutopurge: true,
});

const releaseTracklistNegativeCache = new LRUCache<number, true>({
  max: RELEASE_TRACKLIST_CACHE_MAX,
  ttl: RELEASE_TRACKLIST_TTL_NEGATIVE_MS,
  ttlAutopurge: true,
});

const releaseTracklistInflight = new Map<number, Promise<RotationTrack[] | null>>();

export function __resetReleaseTracklistCacheForTests(): void {
  releaseTracklistPositiveCache.clear();
  releaseTracklistNegativeCache.clear();
  releaseTracklistInflight.clear();
}

/**
 * Sizes of the per-release-id tracklist LRUs. Used by the rotation-tracks
 * cache-warm service to classify post-`getRotationTracksFromRelease`
 * outcomes (positive vs negative) without coupling to LRU internals.
 * Parallel to `__rotationLmlCacheSizesForWarm`.
 */
export function __releaseTracklistCacheSizesForWarm(): { positive: number; negative: number } {
  return {
    positive: releaseTracklistPositiveCache.size,
    negative: releaseTracklistNegativeCache.size,
  };
}

/**
 * Fetch a Discogs release tracklist via LML and project it onto the
 * picker's `RotationTrack` wire shape. Cached per `release_id`.
 *
 * Returns:
 *   - `RotationTrack[]` — positive-cached projection.
 *   - `null` — LML returned 404; negative-cached. Controller maps to 200 + `[]`.
 *
 * Other LML errors (5xx, network, parse) bubble so transient upstream
 * failures surface rather than silently degrading the picker.
 */
export async function getRotationTracksFromRelease(releaseId: number): Promise<RotationTrack[] | null> {
  const cachedPositive = releaseTracklistPositiveCache.get(releaseId);
  if (cachedPositive !== undefined) return cachedPositive;
  if (releaseTracklistNegativeCache.has(releaseId)) return null;

  const inflight = releaseTracklistInflight.get(releaseId);
  if (inflight) return inflight;

  const pending = (async () => {
    let release: DiscogsReleaseMetadata;
    try {
      release = await getRelease(releaseId);
    } catch (err) {
      if (err instanceof LmlClientError && err.statusCode === 404) {
        releaseTracklistNegativeCache.set(releaseId, true);
        return null;
      }
      throw err;
    }
    const tracks = projectInlineTracklist(release.tracklist, release.artist) ?? [];
    releaseTracklistPositiveCache.set(releaseId, tracks);
    return tracks;
  })().finally(() => {
    releaseTracklistInflight.delete(releaseId);
  });
  releaseTracklistInflight.set(releaseId, pending);
  return pending;
}

// ============================================================================
// Compilation-track (CTA) write path — BS#1964 / Phase 3.5 `/wxycdb` cutover.
//
// `compilation_track_artist` (CTA) makes V/A per-track artists searchable, but
// today rows arrive only via the insert-only `jobs/library-etl` MySQL mirror.
// When `/wxycdb` goes dark that mirror stops; these functions back the api.yaml
// v1.28.0 CTA write path (WXYC/wxyc-shared#291) so compilations added afterward
// keep per-track artist search. The write is additive-only (the D6 decision —
// the insert-only residue is never reconciled here) and Discogs-agnostic (it
// carries only the durable free-text triple, so it survives the future
// `library_track` rename, BS#801). HTTP surface: `library.controller.ts`.
// ============================================================================

/** A stored CTA row, projected onto the api.yaml `CompilationTrack` shape. */
export interface CompilationTrackRow {
  id: number;
  artist_name: string;
  track_title: string | null;
  track_position: string | null;
}

/** A validated, write-ready CTA row (api.yaml `CompilationTrackInput`). */
export interface CompilationTrackInputRow {
  artist_name: string;
  track_title: string | null;
  track_position: string | null;
}

/** Outcome of an additive CTA write (api.yaml `CompilationTracksWriteResponse`). */
export interface CompilationTracksWriteResult {
  inserted: number;
  skipped: number;
  tracks: CompilationTrackRow[];
}

/**
 * Does a `library` row exist for this serial id? Cheap existence probe for the
 * CTA handlers' 404 gate. The CTA `{id}` path param is the serial `library.id`
 * (like `/library/:id` PATCH/missing/found), not the legacy id.
 */
export async function libraryRowExists(libraryId: number): Promise<boolean> {
  const rows = await db.select({ id: library.id }).from(library).where(eq(library.id, libraryId)).limit(1);
  return rows.length > 0;
}

/**
 * Serial-`library.id` twin of `getDiscogsReleaseIdByLegacyId` (BS#836). The CTA
 * suggestions read keys on the serial id the dj-site edit surface holds (what
 * `addAlbum` returns), so it reads `library_identity` directly by `library_id`
 * rather than bridging through `library.legacy_release_id`. Returns null when
 * the row has no `library_identity` entry or no resolved `discogs_release_id`.
 */
export async function getDiscogsReleaseIdByLibraryId(libraryId: number): Promise<number | null> {
  const rows = await db
    .select({ discogs_release_id: library_identity.discogs_release_id })
    .from(library_identity)
    .where(eq(library_identity.library_id, libraryId))
    .limit(1);
  return rows[0]?.discogs_release_id ?? null;
}

/** List a release's stored CTA rows, oldest first (stable insertion order). */
export async function getCompilationTracks(libraryId: number): Promise<CompilationTrackRow[]> {
  return db
    .select({
      id: compilation_track_artist.id,
      artist_name: compilation_track_artist.artist_name,
      track_title: compilation_track_artist.track_title,
      track_position: compilation_track_artist.track_position,
    })
    .from(compilation_track_artist)
    .where(eq(compilation_track_artist.library_id, libraryId))
    .orderBy(asc(compilation_track_artist.id));
}

/**
 * Additive CTA write. Every input row is inserted with an untargeted
 * `ON CONFLICT DO NOTHING`, which arbiters on *both* CTA unique indexes
 * (`cta_unique_idx` on `(library_id, artist_name, track_title)` and the
 * `cta_unique_null_track_idx` partial covering `track_title IS NULL`). A row
 * that duplicates one already stored — or one earlier in the same batch — is
 * absorbed by the conflict clause and never lands, so `RETURNING` yields
 * exactly the newly-inserted rows. `skipped` is therefore `input − inserted`,
 * and the identity `inserted + skipped == input.length` holds even when the
 * batch carries intra-request duplicates (api.yaml v1.28.0
 * `CompilationTracksWriteResponse` semantics). Existing rows are never mutated
 * — this path cannot replace or delete (the D6 boundary).
 */
export async function writeCompilationTracks(
  libraryId: number,
  inputs: CompilationTrackInputRow[]
): Promise<CompilationTracksWriteResult> {
  const values = inputs.map((t) => ({
    library_id: libraryId,
    artist_name: t.artist_name,
    track_title: t.track_title,
    track_position: t.track_position,
  }));
  const insertedRows = await db
    .insert(compilation_track_artist)
    .values(values)
    .onConflictDoNothing()
    .returning({ id: compilation_track_artist.id });
  const tracks = await getCompilationTracks(libraryId);
  return {
    inserted: insertedRows.length,
    skipped: inputs.length - insertedRows.length,
    tracks,
  };
}

/**
 * Autopopulate source for the CTA edit surface: resolve the Discogs release
 * linked to this library row and return its tracklist as write-ready
 * `CompilationTrackInput` rows — *without writing*. This is the only
 * Discogs-touching call in the CTA surface (a single `getRelease`, not the
 * per-track N-validation fan-out that timed out in BS#1117); the client
 * confirms/edits the rows and POSTs them back.
 *
 * Delegates the release fetch to `getRotationTracksFromRelease`, so the CTA
 * suggestions and rotation-tracks picker share one cached resolver: the
 * per-release LRU + in-flight coalescing means a repeated suggestions read (or
 * one racing a rotation-picker open on the same release) doesn't re-pay LML's
 * 2-9 s cold release fetch, and the single `projectInlineTracklist` projection
 * keeps the two surfaces from drifting. Each per-track artist credit flattens
 * onto CTA's single `artist_name` free-text field (empty per-track `artists[]`
 * falls back to the release-level artist — "Various" on a V/A comp — and
 * multi-artist credits join on `', '`).
 *
 * `discogs_release_id: null` + empty `tracks` encodes "no upstream release
 * resolved → manual entry". A `null` from `getRotationTracksFromRelease` (LML
 * 404 / absent tracklist) degrades the same way with the id echoed.
 */
export async function getCompilationTrackSuggestions(
  libraryId: number
): Promise<{ discogs_release_id: number | null; tracks: CompilationTrackInputRow[] }> {
  const releaseId = await getDiscogsReleaseIdByLibraryId(libraryId);
  if (releaseId === null) {
    return { discogs_release_id: null, tracks: [] };
  }

  const projected = (await getRotationTracksFromRelease(releaseId)) ?? [];
  const tracks: CompilationTrackInputRow[] = projected.map((t) => ({
    // `projectInlineTracklist` guarantees a non-empty `artists[]` (it seeds the
    // release-artist fallback), so the join is always a real credit.
    artist_name: t.artists.join(', '),
    track_title: t.title,
    track_position: t.position,
  }));
  return { discogs_release_id: releaseId, tracks };
}

export const updateOnStreaming = async (id: number, on_streaming: boolean | null) => {
  const response = await db.update(library).set({ on_streaming }).where(eq(library.id, id)).returning();
  return response[0];
};

/**
 * Cache the artwork URL for a library entry, but only when the row's current
 * `artwork_url` is NULL. The narrowing predicate makes this safe to call
 * concurrently with `jobs/library-artwork-url-backfill` (#637) and forecloses
 * a class of last-write-wins inconsistencies if a future LML response shape
 * ever diverges between the runtime and backfill code paths. Today both
 * writers source from the same `discogs-cache.release.artwork_url`, so the
 * clobber was benign — but the symmetry with the backfill's WHERE makes the
 * race contract honest. Returns the updated row when a write happened, or
 * `undefined` when the row was already populated; both callers (search-path
 * `enrichWithArtwork` and post-create cache-through in
 * `library.controller.ts`) ignore the return.
 */
export const updateArtworkUrl = async (id: number, artwork_url: string | null) => {
  const response = await db
    .update(library)
    .set({ artwork_url })
    .where(and(eq(library.id, id), isNull(library.artwork_url)))
    .returning();
  return response[0];
};

/**
 * Confidence heuristics derived from LML's `search_type` per the B-0
 * calibration (see issue #492). LML does not return per-result confidence,
 * so the link-time value stored on `library.canonical_entity_confidence` is
 * a coarse band kept around so future analyses can re-judge weak matches
 * once LML exposes a real signal.
 *
 * BS#1356: these bands are DESCRIPTIVE audit metadata, not a write gate.
 * The only auto-accept authority for a `LookupResponse` is the
 * `isTrustedLmlAlbumMatch` predicate (`@wxyc/lml-client`, `src/trust.ts`) —
 * every live write path (the coordinator's `applyTrustGate`, which every
 * `fireAndForgetCanonicalEntity` call goes through via
 * `requireSearchType: 'direct'`, BS#1355) sits behind that predicate before
 * `mapLookupToCanonicalEntity` below ever runs, so only `search_type ===
 * 'direct'` (band 0.9) reaches this table on any reachable path today. The
 * non-direct bands (0.3 / 0.5) stay for retroactive analysis and for
 * `flowsheet-linkage.service.ts`, which reads this same table but has had
 * **no production caller since PR #894** (the enrichment-worker superseded
 * its inline fire-and-forget wiring) — it is dormant, not load-bearing.
 * Do not treat a non-direct band as license to auto-persist; if
 * flowsheet-linkage is ever revived, route it through
 * `isTrustedLmlAlbumMatch` (or, for track-context callers, the reserved
 * `isTrustedLmlTrackContextMatch`) rather than reading this table directly.
 */
const SEARCH_TYPE_CONFIDENCE: Record<LookupResponse['search_type'], number | null> = {
  direct: 0.9,
  fallback: 0.5,
  alternative: 0.3,
  compilation: 0.3,
  song_as_artist: 0.3,
  none: null,
};

/**
 * Map an LML lookup response to a (canonical_entity_id, confidence) pair, or
 * null if the response carries nothing linkable. The id is namespaced by
 * source (`discogs:release:<id>`) — the column's contract is opaque text, but
 * a namespace keeps the door open for MusicBrainz / other resolvers later.
 */
export const mapLookupToCanonicalEntity = (response: LookupResponse): { id: string; confidence: number } | null => {
  const top = response.results?.[0];
  const releaseId = top?.artwork?.release_id;
  if (!releaseId) return null;
  const confidence = SEARCH_TYPE_CONFIDENCE[response.search_type];
  if (confidence === null || confidence === undefined) return null;
  return { id: `discogs:release:${releaseId}`, confidence };
};

/**
 * Persist a canonical-entity linkage on a library row. Stamps
 * `canonical_entity_resolved_at` with the current time so audits can tell
 * when the link was made and retry policies can age weak matches.
 */
export const updateCanonicalEntity = async (id: number, entityId: string, confidence: number) => {
  const response = await db
    .update(library)
    .set({
      canonical_entity_id: entityId,
      canonical_entity_confidence: confidence,
      canonical_entity_resolved_at: new Date(),
    })
    .where(eq(library.id, id))
    .returning();
  return response[0];
};

/**
 * Enrich search results with artwork URLs from LML.
 *
 * Results that already have artwork cached return as-is. For uncached results,
 * fetches artwork from LML in parallel via Promise.allSettled and writes back
 * to the library table (cache-through). Gracefully degrades if LML is
 * unavailable or times out.
 *
 * BS#1828: the `searchForAlbum` controller calls this fire-and-forget — it is
 * never awaited on the response path — so the mutation of `row.artwork_url`
 * below only benefits *future* searches via the `updateArtworkUrl` write, not
 * the in-flight request.
 */
type ArtworkEnrichable = {
  id: number;
  artist_name: string;
  album_title: string;
  artwork_url: string | null | undefined;
};

export async function enrichWithArtwork<T extends ArtworkEnrichable>(results: T[]): Promise<T[]> {
  if (!isLmlConfigured()) return results;

  const uncached = results.filter((r) => r.artwork_url === null || r.artwork_url === undefined);
  if (uncached.length === 0) return results;

  const settlements = await Promise.allSettled(
    uncached.map(async (row) => {
      const lookupResult = await lmlLookupCoordinator.lookup(row.artist_name, row.album_title, undefined, {
        caller: 'library-enrich-artwork',
        requireSearchType: 'direct',
      });
      if (lookupResult === null) return;
      const artworkUrl = filterSpacerGif(lookupResult.results?.[0]?.artwork?.artwork_url);
      if (!artworkUrl) return;
      row.artwork_url = artworkUrl;
      await updateArtworkUrl(row.id, artworkUrl);
    })
  );

  for (const s of settlements) {
    if (s.status === 'rejected') {
      console.warn('[Library] Artwork enrichment failed:', s.reason);
    }
  }

  return results;
}

/**
 * Projection that mirrors `library_artist_view` so the search functions can
 * read from `library` directly (with explicit joins) and still return the
 * shape consumers expect. Reading from `library` is what lets the planner
 * pick the trigram or tsvector index on the predicated column instead of
 * forcing the 5-way view JOIN to materialize first.
 *
 * The `satisfies` clause is the load-bearing part (BS#2231). Every consumer of
 * this projection ultimately hands `tsc` a `LibraryArtistViewEntry` through an
 * unchecked assertion — Drizzle can't type a raw `db.execute`, and the chained
 * builder's inferred row type is cast too — so nothing else relates the columns
 * actually selected to the fields the return type promises. Constraining the
 * projection to cover every key of that type moves the check to compile time:
 * adding a field to `LibraryArtistViewEntry` without projecting it here is now
 * a build error rather than a column that silently arrives `undefined` behind a
 * non-nullable declaration. `artist_id` (BS#2228) and the three `discogs_*`
 * columns (BS#2231) each reached production as exactly that.
 */
const LIBRARY_VIEW_PROJECTION = {
  id: library.id,
  code_letters: artists.code_letters,
  code_artist_number: genre_artist_crossreference.artist_genre_code,
  code_number: library.code_number,
  artist_name: artists.artist_name,
  alphabetical_name: artists.alphabetical_name,
  album_title: library.album_title,
  format_name: format.format_name,
  genre_name: genres.genre_name,
  rotation_bin: rotation.rotation_bin,
  add_date: library.add_date,
  label: library.label,
  label_id: library.label_id,
  on_streaming: library.on_streaming,
  album_artist: library.album_artist,
  plays: library.plays,
  artwork_url: library.artwork_url,
  discogs_artist_id: artists.discogs_artist_id,
  musicbrainz_artist_id: artists.musicbrainz_artist_id,
  wikidata_qid: artists.wikidata_qid,
  spotify_artist_id: artists.spotify_artist_id,
  apple_music_artist_id: artists.apple_music_artist_id,
  bandcamp_id: artists.bandcamp_id,
  artist_id: library.artist_id,
  // BS#2128: the library row's surrogate key. `library` is INNER JOINed at
  // the top of this projection's join chain, so it's always populated here.
  legacy_release_id: library.legacy_release_id,
  // BS#1895 (Not-on-Discogs epic #1280 sub-issue 5): serialize the MD-set
  // flag onto every catalog read surface. `serializeLibraryArtistViewEntry`
  // renames these to camelCase at the wire boundary, matching the
  // deliberately-camelCase discogs* fields in wxyc-shared api.yaml's Album /
  // UpdateAlbumRequest schemas (BS#1281's write-path convention).
  discogs_unavailable: library.discogs_unavailable,
  discogs_unavailable_note: library.discogs_unavailable_note,
  last_discogs_recheck_at: library.last_discogs_recheck_at,
} as const satisfies Record<keyof LibraryArtistViewEntry, Column>;

/**
 * Raw SQL mirror of `libraryViewQuery(false)`'s join chain. Used when the
 * caller needs a query shape Drizzle's chained builder can't express — the
 * UNION ALL alias path emitted by `buildAliasHitsCte`, and the CTA arm's
 * windowed subquery, which prepends its own `compilation_track_artist` →
 * `library` join and then reuses these. Schema is named once here so a future
 * column change is a single edit.
 */
const LIBRARY_VIEW_JOINS_RAW = sql`
  INNER JOIN ${artists} ON ${artists.id} = ${library.artist_id}
  INNER JOIN ${format} ON ${format.id} = ${library.format_id}
  INNER JOIN ${genres} ON ${genres.id} = ${library.genre_id}
  INNER JOIN ${genre_artist_crossreference}
    ON ${genre_artist_crossreference.artist_id} = ${library.artist_id}
    AND ${genre_artist_crossreference.genre_id} = ${library.genre_id}
  LEFT JOIN ${rotation}
    ON ${rotation.album_id} = ${library.id}
    AND (${rotation.kill_date} > CURRENT_DATE OR ${rotation.kill_date} IS NULL)
`;

/**
 * Raw SQL projection **derived from** `LIBRARY_VIEW_PROJECTION`, for the query
 * shapes Drizzle's chained builder can't express (the UNION ALL alias path, the
 * CTA arm's windowed subquery).
 *
 * Derived rather than hand-mirrored (BS#2231): this used to be a second copy of
 * the column list, kept in sync by hand, which is one more place for a column
 * to go missing than the `satisfies` above can see. Emitting it from the same
 * object means the compile-time completeness check covers the raw paths too.
 *
 * Exported for `tests/unit/services/library-cta-projection.test.ts`, which pins
 * that the CTA arm interpolates this constant instead of hand-rolling a list
 * again — the one link in the chain a future edit could undo without failing
 * the build.
 */
export const LIBRARY_VIEW_PROJECTION_RAW = rawProjection(LIBRARY_VIEW_PROJECTION);

/**
 * Build the `FROM library` query shape with the joins needed to project the
 * `LibraryArtistViewEntry` columns. `withPlays` adds the `album_plays`
 * materialized view as a LEFT JOIN — only the tsvector ranker needs it, so
 * single-column trigram paths skip it.
 */
function libraryViewQuery(withPlays: boolean) {
  const base = db
    .select(LIBRARY_VIEW_PROJECTION)
    .from(library)
    .innerJoin(artists, eq(artists.id, library.artist_id))
    .innerJoin(format, eq(format.id, library.format_id))
    .innerJoin(genres, eq(genres.id, library.genre_id))
    .innerJoin(
      genre_artist_crossreference,
      and(
        eq(genre_artist_crossreference.artist_id, library.artist_id),
        eq(genre_artist_crossreference.genre_id, library.genre_id)
      )
    )
    .leftJoin(
      rotation,
      sql`${rotation.album_id} = ${library.id} AND (${rotation.kill_date} > CURRENT_DATE OR ${rotation.kill_date} IS NULL)`
    );
  return withPlays ? base.leftJoin(album_plays, eq(album_plays.album_id, library.id)) : base;
}

/** A query has at least one alphanumeric character. Pure punctuation skips both search paths. */
function hasAlphanumeric(query: string): boolean {
  return /[\p{L}\p{N}]/u.test(query);
}

/**
 * Tsvector + plays ranker for the dj-site Both-mode default. Reads
 * `library.search_doc` (the STORED generated tsvector from migration 0058)
 * with `websearch_to_tsquery('simple', ...)` so multi-term queries get
 * AND-semantics, then weights ts_rank by `1 + ln(plays + 1)` to nudge
 * canonical answers up.
 *
 * The `(1 + ln(...))` shape is deliberate: `ln(plays + 1)` zeros out the
 * text-rank signal for albums with zero plays (most of the catalog), which
 * erases the ranking entirely for unpopular-but-relevant matches.
 */
async function searchLibraryByTsvector(
  query: string,
  n: number,
  on_streaming?: boolean
): Promise<LibraryArtistViewEntry[]> {
  const tsquery = sql`websearch_to_tsquery('simple', ${query})`;
  const tsvectorPredicate = sql`${library.search_doc} @@ ${tsquery}`;
  const streamingPredicate = on_streaming !== undefined ? eq(library.on_streaming, on_streaming) : undefined;

  return libraryViewQuery(true)
    .where(streamingPredicate ? and(tsvectorPredicate, streamingPredicate) : tsvectorPredicate)
    .orderBy(desc(sql`ts_rank(${library.search_doc}, ${tsquery}) * (1 + ln(coalesce(${album_plays.plays}, 0) + 1))`))
    .limit(n) as unknown as Promise<LibraryArtistViewEntry[]>;
}

/**
 * Trigram fallback for Both-mode: typos and weird casing that
 * `websearch_to_tsquery` won't match. Operates on the denormalized
 * `library.artist_name` (backfilled in A.2) so the predicate is
 * single-table and reachable by the per-column GIN trigram indexes.
 */
async function searchLibraryByTrigramBoth(
  query: string,
  n: number,
  on_streaming?: boolean
): Promise<TaggedLibraryViewEntry[]> {
  const { enabled: aliasEnabled, minSimilarity: aliasMinSimilarity } = getCatalogSearchAliasConfig();

  if (!aliasEnabled) {
    // Byte-identical legacy path. The alias-off branch must stay on the
    // chained builder so the planner reaches the per-column GIN trigram
    // indexes via the same bind shape as today.
    const trigramPredicate = sql`(${library.artist_name} % ${query} OR ${library.album_title} % ${query})`;
    const streamingPredicate = on_streaming !== undefined ? eq(library.on_streaming, on_streaming) : undefined;
    return libraryViewQuery(false)
      .where(streamingPredicate ? and(trigramPredicate, streamingPredicate) : trigramPredicate)
      .orderBy(
        desc(sql`GREATEST(similarity(${library.artist_name}, ${query}), similarity(${library.album_title}, ${query}))`)
      )
      .limit(n) as unknown as Promise<TaggedLibraryViewEntry[]>;
  }

  // Alias-enabled path: ALT1 UNION ALL (BS#1318). The CTE runs the trigram
  // bitmap scan once over `artist_search_alias`; branch (a) is the
  // byte-identical alias-OFF trigram predicate against `library`, branch (b)
  // joins the CTE on `artist_id` and dedupes against branch (a) via NOT-of
  // the same trigram predicate.
  //
  // The trigram OR-predicate is evaluated twice — once positively in (a),
  // once negated in (b) — but each is bitmap-indexable on its own, so the
  // total cost is dominated by the substrate scan + LIMIT pushdown on the
  // outer LAV scan rather than the correlated LATERAL's per-row scan.
  //
  // The UNION ALL is wrapped in a subquery so the outer ORDER BY can
  // reference both the trigram similarity and the CTE-provided
  // `alias_max_sim`. Postgres forbids expression-shaped ORDER BY directly on
  // a UNION result (column names only); the subquery lifts the union's
  // columns into a scope where `similarity(...)` is a legal ORDER BY term.
  //
  // BS#2020: fuzzy alias-only rows are tiered LAST, ahead of the relevance
  // sort. Ranking both branches on one `GREATEST(...)` scale let a single
  // mid-scoring variant displace real matches wholesale — branch (b) INNER
  // JOINs on `artist_id`, so one hit admits an artist's entire discography at
  // that score, and nothing in the sort separated "matched the query text"
  // from "matched a fuzzy variant". `FALSE < TRUE` in Postgres, so ASC puts
  // the non-demoted rows first; `GREATEST` is untouched, so the strongest hit
  // still leads within each tier. Exact variants are exempt from the demotion
  // — see `buildFuzzyAliasTier` for why, and why the guard belongs in the
  // tier rather than in `GREATEST`.
  //
  // `GREATEST` deliberately keeps all three terms rather than collapsing to
  // `alias_max_sim` for branch (b). It is tempting to argue the branch-(b)
  // similarity is sub-threshold by construction (the rows are selected under
  // `NOT (trigramPredicate)`), but that predicate reads `library.artist_name`
  // while the projection below emits `artists.artist_name` — a denormalized
  // pair that BS#1092's drift check exists precisely because it can diverge.
  // `GREATEST` stays correct either way; a hand-collapsed form would not.
  //
  // `buildDirectMatchTieBreak` sits AFTER the score, not before it: at equal
  // relevance a row that matched the query text outranks one that matched a
  // variant. The guard above removed the only signal that distinguished them
  // once both reach 1.0, which would otherwise leave `id ASC` — catalog age —
  // to decide between an artist and a band that lists them as a member.
  //
  // `id ASC` breaks the remaining ties: every row of one artist shares an
  // identical `alias_max_sim`, so without it their order is whatever the plan
  // emits.
  const streamingClause = on_streaming !== undefined ? sql`AND ${library.on_streaming} = ${on_streaming}` : sql``;
  const trigramPredicate = sql`(${library.artist_name} % ${query} OR ${library.album_title} % ${query})`;
  const rows = (await db.execute(sql`
    ${buildAliasHitsCte(query, aliasMinSimilarity)}
    SELECT * FROM (
      (
        SELECT ${LIBRARY_VIEW_PROJECTION_RAW}${ALIAS_HITS_PROJECTION_NULLS}
        FROM ${library}
        ${LIBRARY_VIEW_JOINS_RAW}
        WHERE ${trigramPredicate}
        ${streamingClause}
      )
      UNION ALL
      (
        SELECT ${LIBRARY_VIEW_PROJECTION_RAW}${ALIAS_HITS_PROJECTION}
        FROM ${library}
        ${LIBRARY_VIEW_JOINS_RAW}
        INNER JOIN alias_hits ON alias_hits.artist_id = ${library.artist_id}
        WHERE NOT ${trigramPredicate}
        ${streamingClause}
      )
    ) alias_search
    ORDER BY ${buildFuzzyAliasTier()}, GREATEST(
      similarity(artist_name, ${query}),
      similarity(album_title, ${query}),
      COALESCE(alias_max_sim, 0)
    ) DESC, ${buildDirectMatchTieBreak()}, id ASC
    LIMIT ${n}
  `)) as unknown as (LibraryArtistViewEntry & AliasHitFields)[];

  return rows.map(attachAliasHint);
}

/**
 * Catalog-track-search cascade: CTA (Track 1) → LML `/lookup` (Track 2),
 * each layer gated by its own `CATALOG_TRACK_SEARCH_*` feature flag.
 *
 * Shared by `searchLibraryBothMode` (the `/library/` route) and
 * `library-search.service.ts::runCascade` (the `/library/query` route) so
 * the two callers can't drift on flag gating, layer order, or future
 * per-layer concerns (telemetry, error isolation, cost guards).
 *
 * Returns raw `TaggedLibraryViewEntry[]`; callers handle their own
 * post-cascade projection (the catalog read-path applies
 * `serializeLibraryArtistViewEntry`; the query endpoint projects to
 * `AlbumSearchResultRow` and re-applies enum filters in-memory).
 */
export async function runCatalogTrackSearchCascade(
  query: string,
  limit: number,
  on_streaming?: boolean
): Promise<TaggedLibraryViewEntry[]> {
  const flags = getCatalogTrackSearchConfig();
  if (!flags.ctaEnabled && !flags.discogsEnabled) return [];

  if (flags.ctaEnabled) {
    const ctaResults = await searchLibraryByCTARaw(query, limit, on_streaming);
    if (ctaResults.length > 0) return ctaResults;
  }
  if (flags.discogsEnabled) {
    const trackResults = await searchLibraryByTrackRaw(query, limit);
    // BS#1885: `searchLibraryByTrackRaw` (unlike `searchLibraryByCTARaw`) does
    // not honor `on_streaming`, so scope its rows here — at the shared cascade
    // boundary — rather than only in the `/library/query` caller. Both-mode
    // (`GET /library/?on_streaming=…`) has no in-memory re-filter of its own,
    // so without this a streaming-scoped request could receive a Track 2 row
    // of the wrong streaming status. `on_streaming === undefined` (no filter)
    // and `null` rows under an active filter mirror the `/library/query`
    // predicate in `library-search.service.ts::runCascade`.
    const scoped =
      on_streaming === undefined ? trackResults : trackResults.filter((row) => row.on_streaming === on_streaming);
    if (scoped.length > 0) return scoped;
  }
  return [];
}

/**
 * Run the Both-mode search cascade: tsvector → trigram → CTA → LML `/lookup`.
 *
 * Stages 1-2 (tsvector, trigram) read `library` directly via the per-column
 * GIN indexes. Stages 3-4 (CTA, LML) are the catalog-track-search cascade,
 * shared with `library-search.service.ts::runCascade` via
 * {@link runCatalogTrackSearchCascade}.
 *
 * Tsvector / trigram return plain `LibraryArtistViewEntry` rows; CTA / LML
 * return the same shape with a `matched_via` field tagging the fallback
 * source. The catalog read-path serializes the union via
 * `serializeLibraryArtistViewEntry`, so `matched_via` rides through to the
 * wire unchanged.
 *
 * Both feature flags default off, so for any deployment that hasn't opted in,
 * behavior is byte-identical to the pre-#972 baseline (tsvector → trigram → []).
 */
async function searchLibraryBothMode(
  query: string,
  n: number,
  on_streaming?: boolean
): Promise<TaggedLibraryViewEntry[]> {
  const trimmed = query.trim();
  if (trimmed.length === 0 || !hasAlphanumeric(trimmed)) return [];

  const tsvectorResults = await searchLibraryByTsvector(trimmed, n, on_streaming);
  if (tsvectorResults.length > 0) return tsvectorResults;

  if (trimmed.length >= 2) {
    const trigramResults = await searchLibraryByTrigramBoth(trimmed, n, on_streaming);
    // BS#1885: an alias-only trigram hit must not suppress the cascade —
    // same root cause as the /library/query surface (library-search.service.ts).
    // A genuine (non-alias) trigram row is still a strong enough signal to
    // short-circuit as before.
    if (trigramResults.some((r) => !r.matched_via_alias)) return trigramResults;
    if (trigramResults.length > 0) {
      const cascade = await runCatalogTrackSearchCascade(trimmed, n, on_streaming);
      if (cascade.length === 0) return trigramResults;
      // Cascade-first: this path has no `sort` param (bounded request-line
      // list, default n=5), and a resolved track match outranks a fuzzy
      // alias hit. On an id collision, carry the alias row's
      // `matched_via_alias` onto the cascade row (mirrors the `/library/query`
      // merge in `library-search.service.ts`) so the two surfaces agree on the
      // wire shape rather than one silently dropping the alias hint.
      const trigramById = new Map(trigramResults.map((r) => [r.id, r]));
      const enrichedCascade = cascade.map((r) => {
        const dup = trigramById.get(r.id);
        return dup?.matched_via_alias ? { ...r, matched_via_alias: dup.matched_via_alias } : r;
      });
      const cascadeIds = new Set(cascade.map((r) => r.id));
      return [...enrichedCascade, ...trigramResults.filter((r) => !cascadeIds.has(r.id))].slice(0, n);
    }
  }

  return runCatalogTrackSearchCascade(trimmed, n, on_streaming);
}

export const fuzzySearchLibrary = async (
  artist_name?: string,
  album_title?: string,
  n = 5,
  on_streaming?: boolean
): Promise<TaggedLibraryViewEntry[]> => {
  // Skip only the trigram-OR branches; the both-same tsvector path handles
  // V/A queries cheaply via the search_doc GIN index.
  if (artist_name !== album_title && isCompilationArtist(artist_name)) {
    return [];
  }

  await checkLibraryArtistNameHealth();

  // Both-mode default (dj-site sends the same string as artist and title).
  // Route through tsvector → trigram → CTA → LML cascade so catalog clients
  // see `matched_via` for fallback-sourced hits (BS#972, plan §4.1 / §5.1).
  if (artist_name && album_title && artist_name === album_title) {
    return searchLibraryBothMode(artist_name, n, on_streaming);
  }

  const streamingPredicate = on_streaming !== undefined ? eq(library.on_streaming, on_streaming) : undefined;

  // Both fields set but different — keep the existing OR semantics, but
  // run on `library` directly so each side of the OR can use its trigram
  // index via BitmapOr instead of materializing the full view first.
  if (artist_name && album_title) {
    const trigramPredicate = sql`(${library.artist_name} % ${artist_name} OR ${library.album_title} % ${album_title})`;
    return libraryViewQuery(false)
      .where(streamingPredicate ? and(trigramPredicate, streamingPredicate) : trigramPredicate)
      .orderBy(asc(sql`${library.artist_name} <-> ${artist_name}`), asc(sql`${library.album_title} <-> ${album_title}`))
      .limit(n) as unknown as LibraryArtistViewEntry[];
  }

  // Single-column trigram path (Artists or Albums mode).
  const column = artist_name ? library.artist_name : library.album_title;
  const value = artist_name ?? album_title ?? null;
  const trigramPredicate = sql`${column} % ${value}`;
  return libraryViewQuery(false)
    .where(streamingPredicate ? and(trigramPredicate, streamingPredicate) : trigramPredicate)
    .orderBy(asc(sql`${column} <-> ${value}`))
    .limit(n) as unknown as LibraryArtistViewEntry[];
};

/**
 * Public wire-format for a library_artist_view row: the six flat external-ID
 * columns are stripped and replaced with a nested `reconciled_identity`.
 * `matched_via` rides through when the row came from the catalog-track-search
 * cascade (CTA / LML `/lookup` fallback), otherwise absent.
 */
export type LibraryArtistViewResponse = Omit<
  LibraryArtistViewEntry,
  ReconciledIdentityKey | keyof DiscogsUnavailableSource
> & {
  reconciled_identity: ReconciledIdentity | null;
  matched_via?: TrackMatchHint[];
  matched_via_alias?: ArtistMatchHint[];
  discogsUnavailable: boolean;
  discogsUnavailableNote: string | null;
  lastDiscogsRecheckAt: Date | null;
};

/**
 * Serialize a library_artist_view row for the wire (or any iterable of them).
 * Used at the read-endpoint boundary so the four `/library*` endpoints all
 * return the same nested-identity shape, regardless of whether they read the
 * view or join `artists` directly. Tagged rows (carrying `matched_via`)
 * preserve the tag through serialization. BS#1895: also renames the three
 * discogs-unavailable columns to their camelCase wire form.
 */
export function serializeLibraryArtistViewEntry(row: TaggedLibraryViewEntry): LibraryArtistViewResponse {
  return withDiscogsUnavailableCamelCase(serializeReconciledIdentity(row)) as LibraryArtistViewResponse;
}

/**
 * Look up the canonical `artist_name` for an `artists.id`. Used by addAlbum
 * (A.3) to denormalize the canonical name onto the library row so client-
 * supplied casing variants ("jessica pratt") never get persisted to library
 * out of sync with the `artists` row.
 */
export const getArtistNameById = async (artist_id: number): Promise<string | null> => {
  const response = await db
    .select({ artist_name: artists.artist_name })
    .from(artists)
    .where(eq(artists.id, artist_id))
    .limit(1);
  return response[0]?.artist_name ?? null;
};

export type ArtistInGenreSearchRow = {
  id: number;
  artist_name: string;
  code_letters: string;
  code_number: number;
};

/**
 * Prefix search for artists in a genre (catalog add-entry autocomplete).
 * `code_number` is the artist's number within that genre (`artist_genre_code`).
 */
export const searchArtistsInGenre = async (
  genre_id: number,
  q: string,
  limit: number
): Promise<ArtistInGenreSearchRow[]> => {
  const prefix = q.trim();
  if (prefix.length < 2) {
    return [];
  }

  const cappedLimit = Math.min(20, Math.max(1, limit));

  // Escape %/_ so e.g. q='%a' can't short the prefix-search contract into a
  // contains-anything scan (review issue 14).
  return db
    .select({
      id: artists.id,
      artist_name: artists.artist_name,
      code_letters: artists.code_letters,
      code_number: genre_artist_crossreference.artist_genre_code,
    })
    .from(artists)
    .innerJoin(genre_artist_crossreference, eq(genre_artist_crossreference.artist_id, artists.id))
    .where(and(eq(genre_artist_crossreference.genre_id, genre_id), ilikeEscaped(artists.artist_name, prefix, 'prefix')))
    .orderBy(asc(artists.artist_name))
    .limit(cappedLimit);
};

export const artistIdFromName = async (artist_name: string, genre_id: number): Promise<number> => {
  const response = await db
    .select({ id: artists.id })
    .from(artists)
    .innerJoin(genre_artist_crossreference, eq(genre_artist_crossreference.artist_id, artists.id))
    .where(
      and(
        // Unicode-form + diacritic + case insensitive match (BS#1897). The
        // former `lower(artist_name) = lower($name)` is collation-aware but NOT
        // Unicode-form aware: `Nilüfer Yanya` in NFC (`ü` = U+00FC) vs NFD (`u`
        // + U+0308) is byte-distinct and misses, so the caller falls through to
        // insertArtist and creates a duplicate `artists` row. `fold_artist_name`
        // (migration 0134) folds NFC/NFD/ASCII-fold/case onto one key on BOTH
        // sides — an app-side `.normalize('NFC')` on the input alone can't match
        // an NFD-stored row. Backed by `artists_fold_name_idx`. The genre
        // scoping below is preserved unchanged.
        sql`${FOLD_ARTIST_NAME_FN}(${artists.artist_name}) = ${FOLD_ARTIST_NAME_FN}(${artist_name})`,
        eq(genre_artist_crossreference.genre_id, genre_id)
      )
    )
    .limit(1);

  if (!response.length) {
    return 0;
  } else {
    return response[0].id;
  }
};

export const insertArtist = async (new_artist: NewArtist) => {
  // Store names NFC-canonical (BS#1897). The matcher folds NFC/NFD/ASCII-fold
  // together for *lookup*, but the *stored* form must be a single canonical
  // shape or later exact-equality consumers (e.g. the artist-identity ETL
  // match, BS#521) see spurious NFC/NFD splits. NFC preserves the diacritics
  // themselves, so the display string (bound by the librarian V/A invariant)
  // is unchanged — only the composition form is canonicalized. `code_letters`
  // and `alphabetical_name` can carry diacritics from the source, so they get
  // the same treatment for consistency with `artist_name`.
  const normalized: NewArtist = {
    ...new_artist,
    artist_name: new_artist.artist_name.normalize('NFC'),
    alphabetical_name: new_artist.alphabetical_name.normalize('NFC'),
    code_letters: new_artist.code_letters.normalize('NFC'),
  };
  const response = await db.insert(artists).values(normalized).returning();
  return response[0];
};

export const insertArtistGenreCrossreference = async (
  artist_id: number,
  genre_id: number,
  artist_genre_code: number
) => {
  const response = await db
    .insert(genre_artist_crossreference)
    .values({ artist_id, genre_id, artist_genre_code })
    .returning();
  return response[0];
};

/**
 * Boolean-grade "is this code triple taken" probe backing `addArtist`'s
 * code-conflict pre-check. The triple is NOT unique (see `getArtistsByCode`
 * below), so the row this returns for a contested code is arbitrary — which is
 * fine here, because the caller only needs *an* owner to name in its 409. A
 * route whose contract is "who owns this code" must use the plural instead.
 */
/**
 * The `{ artist_id, artist_name, code_letters }` shape every code-owner lookup
 * answers in: `getArtistByCode`'s 409 conflict payload, `getArtistsByCode`'s
 * full owner list, and `getArtistById`. Named so the three cannot drift apart
 * silently — it is now the wire shape of a public endpoint, not just an
 * internal conflict payload.
 */
export type ArtistCodeOwner = {
  artist_id: number;
  artist_name: string;
  code_letters: string;
};

/**
 * The shared body of the two code-owner lookups. They differ only in the tail
 * (`.limit(1)` for the conflict probe, `.orderBy(...)` for the full list), so
 * the projection and the three-clause join predicate live here — a change to
 * either (filtering soft-deleted artists, say) can no longer land on one and
 * miss the other, leaving the 409 pre-check and the lookup disagreeing about
 * who owns a code.
 */
const artistCodeOwnerQuery = (code_letters: string, genre_id: number, artist_genre_code: number) =>
  db
    .select({
      artist_id: genre_artist_crossreference.artist_id,
      artist_name: artists.artist_name,
      code_letters: artists.code_letters,
    })
    .from(genre_artist_crossreference)
    .innerJoin(artists, eq(genre_artist_crossreference.artist_id, artists.id))
    .where(
      and(
        eq(artists.code_letters, code_letters),
        eq(genre_artist_crossreference.genre_id, genre_id),
        eq(genre_artist_crossreference.artist_genre_code, artist_genre_code)
      )
    );

export const getArtistByCode = async (
  code_letters: string,
  genre_id: number,
  artist_genre_code: number
): Promise<ArtistCodeOwner | null> => {
  const response = await artistCodeOwnerQuery(code_letters, genre_id, artist_genre_code).limit(1);

  // return null if no artist found
  return response[0] ?? null;
};

/**
 * BS#2149: EVERY artist that owns `(code_letters, genre_id, artist_genre_code)`,
 * in a deterministic order.
 *
 * The triple is not unique and nothing in the schema makes it so: the only
 * unique index on `genre_artist_crossreference` is `artist_genre_key
 * (artist_id, genre_id)`, and `code_letters` lives on `artists`, one join away.
 * The production clone holds 13 collisions. The two largest are Various-Artists
 * filings — `V/A`/12/0 with 27 owners (`Soundtracks - <LETTER>`) and `V/A`/11/0
 * with 26 (`Various Artists - Rock - <LETTER>`) — and those are distinct shelf
 * buckets a librarian relies on staying separately reachable, so collapsing to
 * one row would be stably wrong for the other 26.
 *
 * But this is NOT a V/A-only phenomenon, and a V/A-only special case would not
 * cover it: the remaining **11 of 13** are ordinary artist codes with 2–3 owners
 * (`KU`/11/7 with 3; `WI`/7/31, `BL`/9/16, `PO`/15/22, `JE`/9/2, `AP`/11/24,
 * `OR`/11/39, `WH`/11/75, `SA`/4/4, `NO`/8/3, `SI`/15/20 with 2 each). Any code
 * can be contested, so every code gets the list treatment.
 *
 * Ordered `artist_name` then `id`: name first because the collision case is a
 * lettered V/A run whose alphabetical order IS its shelf order, and `id` as a
 * tiebreaker so the order is total (two artists can share a name) and repeated
 * calls agree.
 *
 * Deliberately a sibling of the singular `getArtistByCode` rather than a
 * widening of it: that one is `addArtist`'s conflict pre-check, where an
 * unordered LIMIT 1 is correct and cheaper, and re-pointing it would change the
 * `artist` payload of an existing 409.
 */
export const getArtistsByCode = async (
  code_letters: string,
  genre_id: number,
  artist_genre_code: number
): Promise<ArtistCodeOwner[]> => {
  return artistCodeOwnerQuery(code_letters, genre_id, artist_genre_code).orderBy(
    asc(artists.artist_name),
    asc(artists.id)
  );
};

/**
 * Look up an artist by id in the same `{ artist_id, artist_name, code_letters }`
 * shape `getArtistByCode` returns, so a 409 conflict payload can carry either
 * lookup's result through one consistent wire shape.
 */
export const getArtistById = async (artist_id: number): Promise<ArtistCodeOwner | null> => {
  const response = await db
    .select({
      artist_id: artists.id,
      artist_name: artists.artist_name,
      code_letters: artists.code_letters,
    })
    .from(artists)
    .where(eq(artists.id, artist_id))
    .limit(1);

  return response[0] ?? null;
};

export type ArtistCardRow = {
  artist_id: number;
  artist_name: string;
  alphabetical_name: string;
  genre_id: number;
  code_letters: string;
  code_artist_number: number;
};

/**
 * BS#2156 artist-card lookup: the full editable field set `/wxycdb`'s
 * `artistCardModify.jsp` displays for `GET /library/artists/:id`. Inner-joined
 * to `genre_artist_crossreference` for `genre_id` / `code_artist_number`, same
 * as `getArtistByCode`'s join shape. Returns null on an unknown `artist_id`.
 *
 * `artist_genre_key` is unique on `(artist_id, genre_id)`, not on `artist_id`
 * alone -- a legacy-imported artist filed under more than one genre has more
 * than one crossreference row, and this picks the lowest `genre_id`
 * deterministically rather than whichever the planner returns first. Every
 * artist created via `addArtist` only ever gets one row (there is no
 * multi-genre write path today), so this is dormant for new data, but it
 * cannot be assumed true of the legacy-imported catalog.
 */
export const getArtistCardById = async (artist_id: number): Promise<ArtistCardRow | null> => {
  const response = await db
    .select({
      artist_id: artists.id,
      artist_name: artists.artist_name,
      alphabetical_name: artists.alphabetical_name,
      genre_id: genre_artist_crossreference.genre_id,
      code_letters: artists.code_letters,
      code_artist_number: genre_artist_crossreference.artist_genre_code,
    })
    .from(artists)
    .innerJoin(genre_artist_crossreference, eq(genre_artist_crossreference.artist_id, artists.id))
    .where(eq(artists.id, artist_id))
    .orderBy(asc(genre_artist_crossreference.genre_id))
    .limit(1);

  return response[0] ?? null;
};

/** Partial-update payload for PATCH /library/artists/:id -- the two `modifyArtist` form fields. */
export type UpdateArtistRow = {
  artist_name?: string;
  alphabetical_name?: string;
};

/**
 * Applies the `modifyArtist` form's edit to `artists`. Normalizes both fields
 * to NFC on write, matching `insertArtist` (BS#1897) -- the stored form must
 * stay a single canonical composition or the `fold_artist_name` matcher's
 * exact-equality consumers see spurious NFC/NFD splits.
 */
export const updateArtistInDB = async (
  artist_id: number,
  updates: UpdateArtistRow
): Promise<{ id: number; artist_name: string; alphabetical_name: string } | undefined> => {
  // Column-checked (unlike a `Record<string, unknown>` accumulator) since
  // there are only ever these two optional columns to SET.
  const set = {
    last_modified: sql`NOW()`,
    ...(updates.artist_name !== undefined ? { artist_name: updates.artist_name.normalize('NFC') } : {}),
    ...(updates.alphabetical_name !== undefined
      ? { alphabetical_name: updates.alphabetical_name.normalize('NFC') }
      : {}),
  };

  const response = await db
    .update(artists)
    .set(set)
    .where(eq(artists.id, artist_id))
    .returning({ id: artists.id, artist_name: artists.artist_name, alphabetical_name: artists.alphabetical_name });
  return response[0];
};

export type ArtistReleaseRow = {
  id: number;
  last_modified: Date;
  format_name: string;
  genre_id: number;
  code_letters: string;
  code_artist_number: number;
  code_number: number;
  code_volume_letters: string | null;
  album_title: string;
  alternate_artist_name: string | null;
};

/**
 * Join chain for one artist's release table (BS#2156). Shared verbatim by the
 * page query and its `total` count so the two can never disagree about which
 * rows are in scope.
 *
 * The `genre_artist_crossreference` join keys on BOTH `artist_id` AND
 * `library.genre_id`, matching `library_artist_view` (schema.ts),
 * `LIBRARY_VIEW_PROJECTION` above, and `getBinFromDB` (djs.service.ts). That
 * pair is not decoration: `artist_genre_code` (the `code_artist_number` half of
 * the call number) is GENRE-SCOPED, so an artist filed under several genres has
 * a different one per genre. Dropping the genre dimension makes the projected
 * call number incomplete and its rows mutually indistinguishable — artist 1087
 * ('Various Artists') spans 14 genres across 3,107 library rows, 2,961 of which
 * share a `code_number` with a sibling. `getArtistCardById` cannot supply the
 * missing piece either: it deliberately collapses to the lowest-`genre_id`
 * crossreference row.
 */
const artistReleasesQuery = (artist_id: number) =>
  db
    .select({
      id: library.id,
      last_modified: library.last_modified,
      format_name: format.format_name,
      genre_id: library.genre_id,
      code_letters: artists.code_letters,
      code_artist_number: genre_artist_crossreference.artist_genre_code,
      code_number: library.code_number,
      code_volume_letters: library.code_volume_letters,
      album_title: library.album_title,
      alternate_artist_name: library.alternate_artist_name,
    })
    .from(library)
    .innerJoin(artists, eq(artists.id, library.artist_id))
    .innerJoin(format, eq(format.id, library.format_id))
    .innerJoin(
      genre_artist_crossreference,
      and(
        eq(genre_artist_crossreference.artist_id, library.artist_id),
        eq(genre_artist_crossreference.genre_id, library.genre_id)
      )
    )
    .where(eq(library.artist_id, artist_id));

/**
 * BS#2156: the release table on `/wxycdb`'s artist card
 * (`LibraryReleaseAccessor.getLibraryReleasesForArtist`) -- last-modified,
 * format, the full call number (`code_letters` off `artists`,
 * `code_artist_number` off the genre crossreference, `code_number` +
 * `code_volume_letters` off `library`), title, and alternate artist name.
 * Not sourced from `library_artist_view`: that view omits `last_modified` and
 * `alternate_artist_name`, so this joins the same underlying tables directly,
 * scoped to one artist instead of one album.
 *
 * Ordered by shelf order -- the physical filing order of the card catalog.
 * `code_number` ALONE is not that order and is not even deterministic: 4,179 of
 * 64,193 library rows share a `code_number` with a sibling under the same
 * artist, so the tiebreak carries `code_volume_letters` (the other half of the
 * physical call number, already projected here) and finally `id` as a total
 * order.
 *
 * `code_volume_letters` sorts `ASC NULLS FIRST` explicitly. Postgres's `ASC`
 * default is NULLS LAST, but the legacy query this mirrors
 * (`LibraryCatalogServlet.java:130-133`, `ORDER BY LR.CALL_NUMBERS ASC,
 * LR.CALL_LETTERS ASC`) runs on MySQL, where `ASC` is NULLS FIRST -- a bare
 * `asc()` here would put a lettered volume (`R 7A`, `R 7B`) ahead of its own
 * unlettered `R 7` within the same `code_number`, the reverse of the shelf.
 *
 * Offset-paginated, matching `GET /library/query`'s `page`/`limit` convention:
 * an unbounded projection hands any `catalog:read` DJ ~3,107 rows (~0.5-1 MB
 * of JSON) for artist 1087 on a freely repeatable request.
 */
export const getReleasesForArtist = async (
  artist_id: number,
  page: number,
  limit: number
): Promise<ArtistReleaseRow[]> => {
  return artistReleasesQuery(artist_id)
    .orderBy(asc(library.code_number), sql`${library.code_volume_letters} ASC NULLS FIRST`, asc(library.id))
    .limit(limit)
    .offset(page * limit);
};

/** Total release count for `getReleasesForArtist`'s page envelope (same join scope). */
export const countReleasesForArtist = async (artist_id: number): Promise<number> => {
  const response = await db
    .select({ count: sql<number>`count(*)::int` })
    .from(artistReleasesQuery(artist_id).as('artist_releases'));

  return Number(response[0]?.count ?? 0);
};

export const generateAlbumCodeNumber = async (artist_id: number): Promise<number> => {
  const response = await db
    .select({ code_number: library.code_number })
    .from(library)
    .where(eq(library.artist_id, artist_id))
    .orderBy(desc(library.code_number))
    .limit(1);
  //in case this is the first album
  let code_number = 1;
  if (response.length) {
    code_number = response[0].code_number + 1; //otherwise we increment on the last value
  }
  return code_number;
};

export const generateArtistNumber = async (code_letters: string, genre_id: number): Promise<number> => {
  const response = await db
    .select({ artist_genre_code: genre_artist_crossreference.artist_genre_code })
    .from(genre_artist_crossreference)
    .innerJoin(artists, eq(genre_artist_crossreference.artist_id, artists.id))
    .where(and(eq(artists.code_letters, code_letters), eq(genre_artist_crossreference.genre_id, genre_id)))
    .orderBy(desc(genre_artist_crossreference.artist_genre_code))
    .limit(1);

  // default to being first artist in the genre
  let artist_genre_code = 1;
  if (response.length) {
    artist_genre_code = response[0].artist_genre_code + 1; //otherwise we increment on the last value
  }
  return artist_genre_code;
};

/**
 * Partial-update payload for PATCH /library/:id. Every field is optional —
 * `updateAlbumInDB` only SETs keys that are present, so omitted fields are
 * never overwritten (PR #1154 review: a title-typo fix must not reset
 * disc_quantity to 1 or wipe alternate_artist_name / label_id).
 */
export type UpdateAlbumRow = {
  album_title?: string;
  label?: string | null;
  label_id?: number | null;
  genre_id?: number;
  format_id?: number;
  artist_id?: number;
  artist_name?: string;
  alternate_artist_name?: string | null;
  disc_quantity?: number;
  code_number?: number;
  // BS#1281 (Not-on-Discogs 1a). `discogs_unavailable_note` accepts an
  // explicit null (clearing the note when the flag drops); the SET loop below
  // preserves null because `null !== undefined`.
  discogs_unavailable?: boolean;
  discogs_unavailable_note?: string | null;
};

export const updateAlbumInDB = async (album_id: number, updates: UpdateAlbumRow) => {
  const set: Record<string, unknown> = { last_modified: sql`NOW()` };
  for (const key of [
    'album_title',
    'label',
    'label_id',
    'genre_id',
    'format_id',
    'artist_id',
    'artist_name',
    'alternate_artist_name',
    'disc_quantity',
    'code_number',
    'discogs_unavailable',
    'discogs_unavailable_note',
  ] as const) {
    if (updates[key] !== undefined) set[key] = updates[key];
  }
  // Deliberately NOT nulling the LML-derived columns (on_streaming /
  // artwork_url / canonical_entity_*) here. The old reset-then-maybe-refill
  // shape permanently wiped enrichment whenever the post-write re-lookup was
  // skipped (LML unconfigured) or found no match (transient outage, or a
  // freeform-radio artist with no Discogs "direct" match) — and no recurring
  // job repairs those columns (BS#1549). The controller now re-fires
  // enrichment and overwrites each column only on a successful lookup
  // (refill-then-swap), so a failed/empty lookup leaves the prior values
  // intact instead of stranding the row blank.
  const result = await db.update(library).set(set).where(eq(library.id, album_id)).returning({ id: library.id });
  return result[0];
};

/** Raw library row used by PATCH /library/:id to diff incoming fields. */
export const getLibraryRowById = async (album_id: number) => {
  const rows = await db
    .select({
      id: library.id,
      artist_id: library.artist_id,
      genre_id: library.genre_id,
      format_id: library.format_id,
      album_title: library.album_title,
      label: library.label,
      label_id: library.label_id,
      alternate_artist_name: library.alternate_artist_name,
      disc_quantity: library.disc_quantity,
      code_number: library.code_number,
      artist_name: library.artist_name,
      // BS#1281: the PATCH handler reads the live flag to judge a note-only
      // edit against the `flag ⟺ note` invariant.
      discogs_unavailable: library.discogs_unavailable,
      discogs_unavailable_note: library.discogs_unavailable_note,
    })
    .from(library)
    .where(eq(library.id, album_id))
    .limit(1);
  return rows[0];
};

/**
 * Outcome of a manual `POST /library/:id/discogs-recheck` (BS#1283 / epic
 * #1280 sub-issue 3). Mirrors the outcome taxonomy of the daily
 * `jobs/library-discogs-unavailable-recheck` cron's per-row path (that
 * standalone job package can't import from `apps/backend`, so the logic
 * below is intentionally duplicated — same pattern as
 * `jobs/rotation-release-id-backfill/lml-fetch.ts`'s BS#1516 trust gate
 * "mirrors the coordinator... which this job can't use because it imports
 * lml-client directly").
 */
export type DiscogsRecheckOutcome =
  | { outcome: 'matched'; discogsReleaseId: number; confidence: number }
  | { outcome: 'low_confidence_match'; confidence: number }
  | { outcome: 'no_match' };

/** Same floor as the daily recheck cron's `CONFIDENCE_FLOOR` — see `jobs/library-discogs-unavailable-recheck/orchestrate.ts`'s module doc for the rationale (stricter than the runtime lookup path's confidence bands, closing the "Natanya adversarial loop"). */
const DISCOGS_RECHECK_CONFIDENCE_FLOOR = 0.95;

const stampDiscogsRecheckTimestamp = async (album_id: number): Promise<void> => {
  await db
    .update(library)
    .set({ last_discogs_recheck_at: sql`now()` })
    .where(eq(library.id, album_id));
};

/**
 * Force-asks LML for a fresh Discogs match on a `discogs_unavailable`-
 * flaggable release, bypassing the runtime BS#1293 gate via
 * `forceLookup: true`. Applies the same 0.95 confidence floor, transactional
 * high-confidence writer (NO `IS NULL` guard on the rotation UPDATE — the
 * sticky-false-match fix, see `jobs/library-discogs-unavailable-recheck/
 * writer.ts`'s module doc), and low-confidence Sentry counter as the daily
 * cron. Used by the manual `POST /library/:id/discogs-recheck` admin
 * endpoint so an MD can close the "embargo just lifted, want it now" gap
 * without waiting for the next cron tick.
 */
export const recheckDiscogsAvailability = async (
  album_id: number,
  artist_name: string,
  album_title: string
): Promise<DiscogsRecheckOutcome> => {
  const response = await lookupMetadata(artist_name, album_title, undefined, {
    forceLookup: true,
    caller: 'library-discogs-unavailable-recheck',
  });

  // Distinguish a transient LML timeout body (`{timeout:true, results:[]}`,
  // e.g. LML#370 cascade-exhaustion) from a definitive no-match — same guard
  // as the daily cron's `jobs/library-discogs-unavailable-recheck/lml-fetch
  // .ts`. Throw instead of stamping `last_discogs_recheck_at` / returning
  // `no_match`: a timeout body is not evidence of "no Discogs match", and
  // stamping it here would wrongly exclude the row from the cron's 7-day
  // recheck window for a full week over a purely transient LML failure. The
  // thrown error surfaces as a 5xx on the admin endpoint, which is retryable
  // immediately (unlike the week-long deferral a wrong stamp would cause).
  if (response.timeout) {
    throw new Error('LML lookup returned a timeout body; treating as transient so the row stays retryable');
  }

  const top = response.results?.[0];
  const releaseId = top?.artwork?.release_id;
  // `release_id: 0` is the BS#1185 streaming-only sentinel — not a linkable
  // Discogs release; treat as no_match, same as the cron's lml-fetch.ts.
  if (typeof releaseId !== 'number' || releaseId <= 0) {
    await stampDiscogsRecheckTimestamp(album_id);
    return { outcome: 'no_match' };
  }

  const rawConfidence = top?.artwork?.confidence;
  const confidence = typeof rawConfidence === 'number' ? rawConfidence : 0;

  if (confidence < DISCOGS_RECHECK_CONFIDENCE_FLOOR) {
    try {
      Sentry.metrics.count('lml.lookup.recheck.match_found_on_flagged', 1, {
        attributes: { confidence, artist_name, album_title, library_id: album_id },
      });
    } catch {
      // Observability must never break the request path; swallow.
    }
    await stampDiscogsRecheckTimestamp(album_id);
    return { outcome: 'low_confidence_match', confidence };
  }

  const written = await db.transaction(async (tx) => {
    // No IS-NULL guard — BY DESIGN. See jobs/library-discogs-unavailable-
    // recheck/writer.ts's module doc for the sticky-false-match rationale.
    // rotation.album_id is not unique (re-bins/re-adds), so this updates
    // EVERY rotation row for the album, not just one.
    await tx
      .update(rotation)
      .set({
        discogs_release_id: releaseId,
        discogs_release_id_source: 'recheck_after_unavailable',
      })
      .where(eq(rotation.album_id, album_id));

    const libraryUpdated = await tx
      .update(library)
      .set({
        discogs_unavailable: false,
        discogs_unavailable_note: null,
        last_discogs_recheck_at: sql`now()`,
      })
      .where(eq(library.id, album_id))
      .returning({ id: library.id });

    return libraryUpdated.length === 1;
  });

  if (!written) {
    throw new WxycError('Album not found', 404);
  }

  return { outcome: 'matched', discogsReleaseId: releaseId, confidence };
};

export type DeleteAlbumOutcome =
  | { outcome: 'deleted' }
  | { outcome: 'not_found' }
  | { outcome: 'lock_unavailable' }
  | {
      outcome: 'has_flowsheet_plays';
      /** Total distinct plays the delete would damage — the sum of the three below. */
      playCount: number;
      /** Plays linked to the release itself (`flowsheet.album_id`). */
      directPlayCount: number;
      /** Plays linked only to the release's rotation entry (`flowsheet.rotation_id`). */
      rotationLinkedPlayCount: number;
      /** Plays linked only by `flowsheet.legacy_release_id`, awaiting `jobs/legacy-linkage-resolve`. */
      legacyLinkedPlayCount: number;
    };

/**
 * The authenticated subject that issued a delete, recorded on the denylist
 * row. Every field is optional: `AUTH_BYPASS` and malformed-but-accepted
 * tokens produce a partial (or empty) actor, and a missing attribution must
 * never be a reason to refuse the delete.
 */
export type DeleteAlbumActor = {
  userId?: string | null;
  email?: string | null;
  role?: string | null;
};

/**
 * Bounds how long the delete will wait for the row locks it takes. Chosen
 * BELOW Postgres's default `deadlock_timeout` (1 s) on purpose — see the
 * lock-order discussion in `deleteAlbumFromDB`'s docstring. A librarian's
 * delete is a rare, retryable administrative action; a live DJ's play insert
 * is not, so when the two contend this side is the one that gives up.
 */
export const DELETE_ALBUM_LOCK_TIMEOUT_MS = 750;

/** Postgres SQLSTATEs the delete converts into `lock_unavailable` rather than a 500. */
const LOCK_CONTENTION_SQLSTATES = new Set([
  '55P03', // lock_not_available — our own lock_timeout fired
  '40P01', // deadlock_detected — we were chosen as the victim
]);

const isLockContentionError = (error: unknown): boolean => {
  const code = (error as { code?: unknown } | null)?.code;
  return typeof code === 'string' && LOCK_CONTENTION_SQLSTATES.has(code);
};

/**
 * Hard-deletes a library release (BS#2112, D10 policy). Refuses when the
 * release carries `flowsheet` references: `flowsheet.album_id` is
 * `onDelete: 'set null'`, so an unguarded delete would silently blank
 * historical plays — the exact hazard the WXYC/Backend-Service#2108 orphan
 * audit exists to prevent.
 *
 * **The refusal counts TWO paths to a play, not one.** `rotation.album_id` is
 * `onDelete: 'cascade'` and `flowsheet.rotation_id` is `onDelete: 'set null'`,
 * so deleting a release also blanks `rotation_id` on every play that reached
 * it through the rotation entry. That is not an edge case: the tubafrenzy
 * webhook resolves `album_id` and `rotation_id` independently
 * (`internal.route.ts:318-322`), so a play routinely carries a `rotation_id`
 * with a NULL `album_id` — invisible to a direct-FK-only count, and its
 * provenance destroyed just as silently. The SET NULL is an UPDATE on
 * `flowsheet`, so it would also fire `bump_flowsheet_updated_at` and
 * `touch_flowsheet_watermark`, republishing untouched history to every
 * polling client.
 *
 * **A third path is counted but cannot be locked.** `flowsheet` also carries
 * a bare `legacy_release_id` (no FK, `flowsheet_legacy_release_id_idx` only):
 * the tubafrenzy webhook writes it on every entry, and `album_id` is resolved
 * from it later, on a half-hourly cron, by `jobs/legacy-linkage-resolve`. A
 * play sitting in that window has a NULL `album_id` and no `rotation_id`, so
 * the two counts above see zero — and deleting the release makes the state
 * permanent, because the denylist guarantees no future `library` row will
 * ever carry that `legacy_release_id` for the resolver to join to. Those
 * plays are counted too. They cannot be *locked*, though: with no FK there is
 * no RI check to conflict with, so a webhook INSERT landing between this
 * count and the DELETE is invisible. The residual window is one statement
 * wide and one-sided (it can only mean a refusal that should have fired
 * didn't), and closing it would require a lock on a column no writer takes
 * one on. The resolver's own UPDATE *is* covered: setting `album_id` fires
 * the FK check, which takes `FOR KEY SHARE` on the library row this
 * transaction holds `FOR UPDATE`.
 *
 * **Concurrency.** `db.transaction()` runs at READ COMMITTED, so a bare
 * existence check followed by a count is check-then-act: a writer attaching
 * `flowsheet.album_id` (`flowsheet.service.ts:848`, `internal.route.ts:502`,
 * `jobs/legacy-linkage-resolve/job.ts:271`) between the count and the DELETE
 * would get its play blanked by the RI action — exactly what the 409 exists
 * to prevent. Both lock-taking SELECTs below use `FOR UPDATE`, not
 * `FOR NO KEY UPDATE`: only `FOR UPDATE` conflicts with the `FOR KEY SHARE`
 * an inserting writer's FK check takes on the parent row. Locking the
 * `library` row closes the `album_id` path; locking the release's `rotation`
 * rows closes the `rotation_id` path, whose writers never touch the library
 * row at all.
 *
 * **Lock order, and why it is bounded rather than reasoned about.** This
 * transaction takes library-then-rotation. A single `flowsheet` INSERT
 * carrying BOTH `album_id` and `rotation_id` (`internal.route.ts:502`,
 * `flowsheet.service.ts:846`) takes the same two locks via its two RI checks,
 * in Postgres's trigger firing order — which is by trigger name, and RI
 * triggers are named `RI_ConstraintTrigger_c_<oid>`, so the order is really
 * constraint-creation order. Today that favours us: `flowsheet.album_id`'s FK
 * predates `flowsheet.rotation_id`'s (migration 0097), so the writer also
 * goes library-then-rotation and the two orders agree. But that is an
 * accident of OIDs, not an invariant — migration 0147 in this very PR drops
 * and re-adds a constraint, which is exactly the operation that reorders
 * them, and OIDs can wrap. If the order ever inverts, one side deadlocks, and
 * the side that loses might be a DJ's play insert mid-show.
 *
 * So the transaction does not rely on the order at all. It sets
 * `lock_timeout` to {@link DELETE_ALBUM_LOCK_TIMEOUT_MS}, deliberately BELOW
 * the default 1 s `deadlock_timeout`, which makes this transaction give up
 * before the deadlock detector even runs — the librarian gets a clean,
 * retryable `lock_unavailable` (503) instead of the DJ getting an aborted
 * insert or a 35 s hang against the server timeout. `40P01` is mapped the
 * same way for the case where a non-default `deadlock_timeout` gets there
 * first. `SET LOCAL` only scopes inside an explicit transaction under the
 * postgres-js driver (see `shared/database/src/freetext-enumerate.ts`), which
 * is where this runs.
 *
 * **Durability.** The delete records the release's `legacy_release_id` in
 * `library_delete_denylist` in the same transaction. Without that,
 * `jobs/library-etl` — still cron-registered every 30 minutes — re-inserts
 * the release under a NEW `library.id`, stripped of every cascade-destroyed
 * dependent, the next time anything re-selects the still-present upstream
 * row. That is NOT on a 30-minute timer: the ETL's delta filter is
 * `TIME_LAST_MODIFIED > <last run>` and this delete never touches tubafrenzy,
 * so the trigger is a librarian editing the release upstream or an operator
 * forcing a full re-sync — open-ended rather than imminent. See the table's
 * docstring in `schema.ts` for the full mechanism and the un-delete recipe.
 *
 * **Attribution.** `actor` is recorded on the denylist row. It is optional at
 * every field: a delete under `AUTH_BYPASS` records what it has. Losing the
 * audit trail is bad; refusing the librarian's delete because the token was
 * thin would be worse.
 *
 * Four FKs are resolved explicitly inside the same transaction rather than
 * left to the schema, because each would otherwise fail the DELETE below
 * with a raw FK-violation error: `bins.album_id` (NOT NULL, no `onDelete`),
 * `library_identity` / `library_identity_source` (`library_id`, no
 * `onDelete`), and `artist_library_crossreference.library_id` — schema.ts
 * declares this last one `onDelete: 'cascade'`, but the live constraint
 * (migration 0022) was created `ON DELETE no action` and never migrated to
 * match; verified directly against `pg_constraint.confdeltype` on the dev
 * DB (BS#2112 review). Migration 0147 repairs the constraint; the explicit
 * delete stays so the endpoint is correct on any environment that has not
 * applied it yet. `album_popularity.representative_library_id` is nulled
 * explicitly too — it names a library row but carries no FK at all, so
 * nothing would otherwise stop it dangling. Every other dependent
 * (`rotation`, `album_metadata`, `album_critic_reviews`, `reviews`,
 * `compilation_track_artist`: real `onDelete: 'cascade'`;
 * `album_review_submissions`: `onDelete: 'set null'`) is left to its own FK.
 * `library_watermark` advances via the `touch_library_watermark` trigger
 * (migration 0104/0142, unqualified on DELETE) — no app-level bump needed.
 *
 * `library_identity_history` is the one reference deliberately LEFT dangling.
 * It is the other FK-less pointer at `library.id` (`schema.ts`,
 * `integer().notNull()` with no `.references()`), and it is a supersedure
 * audit log: the whole reason it carries no FK is that a history row has to
 * outlive the row it describes, so cascading or nulling it here would destroy
 * exactly the record an auditor came for. After a delete its `library_id`
 * resolves to nothing; a reader should treat that as "hard-deleted" — the
 * matching `library_delete_denylist` row (with the same id in `library_id`,
 * plus who and when) is the corroborating evidence — not as corruption, and
 * an orphan scan over `library.id` must exclude it. Same reasoning is written
 * up on the table itself in `schema.ts` and in
 * `jobs/library-call-number-dedup/README.md`'s reference-site table, whose
 * `FK_TARGETS` repoints (rather than orphans) the column on a merge.
 */
export const deleteAlbumFromDB = async (
  album_id: number,
  actor: DeleteAlbumActor = {}
): Promise<DeleteAlbumOutcome> => {
  try {
    return await runDeleteAlbumTransaction(album_id, actor);
  } catch (error) {
    if (isLockContentionError(error)) {
      // Not an error condition worth a Sentry issue: it means a live writer
      // held the row and this transaction stood down on purpose. Breadcrumb
      // only, so it shows up as context if something else fails later.
      Sentry.addBreadcrumb({
        category: 'library.delete',
        level: 'warning',
        message: 'DELETE /library/:id stood down on lock contention',
        data: { album_id, code: (error as { code?: string }).code },
      });
      return { outcome: 'lock_unavailable' };
    }
    throw error;
  }
};

const runDeleteAlbumTransaction = async (album_id: number, actor: DeleteAlbumActor): Promise<DeleteAlbumOutcome> => {
  return db.transaction(async (tx) => {
    // Bound every lock wait below. Deliberately under the default 1s
    // `deadlock_timeout` so this transaction is always the one that gives
    // up — see the lock-order paragraph in the docstring. `SET LOCAL` scopes
    // to this transaction only.
    await tx.execute(sql.raw(`SET LOCAL lock_timeout = '${DELETE_ALBUM_LOCK_TIMEOUT_MS}ms'`));

    // FOR UPDATE, not FOR NO KEY UPDATE — see the docstring. This is the lock
    // that makes the play-count guard below an atomic check-and-act rather
    // than a check-then-act race.
    const existing = await tx
      .select({ id: library.id, legacy_release_id: library.legacy_release_id })
      .from(library)
      .where(eq(library.id, album_id))
      .limit(1)
      .for('update');
    if (existing.length === 0) {
      return { outcome: 'not_found' };
    }
    const { legacy_release_id } = existing[0];

    // Lock the release's rotation rows for the same reason: a writer setting
    // `flowsheet.rotation_id` takes FOR KEY SHARE on the ROTATION row, never
    // on the library row, so the lock above does not cover the transitive
    // path. Doubles as the id list the transitive count needs.
    const rotationRows = await tx
      .select({ id: rotation.id })
      .from(rotation)
      .where(eq(rotation.album_id, album_id))
      .for('update');
    const rotationIds = rotationRows.map((row) => row.id);

    const directRows = await tx
      .select({ count: sql<number>`count(*)::int` })
      .from(flowsheet)
      .where(eq(flowsheet.album_id, album_id));
    const directPlayCount = Number(directRows[0]?.count ?? 0);

    // Transitive plays, de-duplicated against the direct count: a play that
    // carries BOTH this album_id and one of its rotation ids is one damaged
    // play, not two. `IS DISTINCT FROM` rather than `<>` because the shape
    // this arm exists to catch is precisely `album_id IS NULL` (the webhook
    // resolves the two columns independently), and `<>` would drop every one
    // of those rows to NULL.
    let rotationLinkedPlayCount = 0;
    if (rotationIds.length > 0) {
      const transitiveRows = await tx
        .select({ count: sql<number>`count(*)::int` })
        .from(flowsheet)
        .where(
          and(inArray(flowsheet.rotation_id, rotationIds), sql`${flowsheet.album_id} IS DISTINCT FROM ${album_id}::int`)
        );
      rotationLinkedPlayCount = Number(transitiveRows[0]?.count ?? 0);
    }

    // Plays that name the release ONLY by its tubafrenzy id, waiting for
    // `jobs/legacy-linkage-resolve` to turn that into an `album_id`. Disjoint
    // from both counts above by construction, so the three sum to a true
    // total: `album_id IS DISTINCT FROM` excludes the direct arm (and, as
    // there, `IS DISTINCT FROM` rather than `<>` because the shape being
    // caught is precisely a NULL `album_id`), and the rotation clause
    // excludes the transitive arm. Deleting while any of these exist strands
    // them forever — the denylist means no future `library` row will carry
    // this `legacy_release_id` for the resolver to join to.
    const legacyLinkedRows = await tx
      .select({ count: sql<number>`count(*)::int` })
      .from(flowsheet)
      .where(
        and(
          eq(flowsheet.legacy_release_id, legacy_release_id),
          sql`${flowsheet.album_id} IS DISTINCT FROM ${album_id}::int`,
          // `NOT IN` alone would drop every NULL `rotation_id` row to NULL and
          // silently exclude the exact population this arm exists to count.
          rotationIds.length > 0
            ? or(isNull(flowsheet.rotation_id), notInArray(flowsheet.rotation_id, rotationIds))
            : undefined
        )
      );
    const legacyLinkedPlayCount = Number(legacyLinkedRows[0]?.count ?? 0);

    const playCount = directPlayCount + rotationLinkedPlayCount + legacyLinkedPlayCount;
    if (playCount > 0) {
      return {
        outcome: 'has_flowsheet_plays',
        playCount,
        directPlayCount,
        rotationLinkedPlayCount,
        legacyLinkedPlayCount,
      };
    }

    // Tombstone BEFORE the delete, so the denylist row and the delete commit
    // or roll back together. Unconditional: `library.legacy_release_id` is
    // total and NOT NULL since migration 0137 (BS#1963 mints one from a
    // sequence for Backend-authored adds), so there is no id-less release to
    // branch on. `onConflictDoUpdate` rather than a bare insert because the
    // delete must never fail on a stale tombstone — a release deleted, then
    // un-deleted by clearing its denylist row and re-imported, then deleted
    // again would otherwise collide on the primary key.
    const attribution = {
      deleted_by_user_id: actor.userId ?? null,
      deleted_by_email: actor.email ?? null,
      deleted_by_role: actor.role ?? null,
    };
    await tx
      .insert(library_delete_denylist)
      .values({ legacy_release_id, library_id: album_id, ...attribution })
      .onConflictDoUpdate({
        target: library_delete_denylist.legacy_release_id,
        // A re-delete overwrites the attribution rather than keeping the
        // first one: the row describes the deletion currently in force, and
        // the librarian who re-deleted is the one accountable for it.
        set: { library_id: album_id, deleted_at: sql`now()`, ...attribution },
      });

    await tx.delete(bins).where(eq(bins.album_id, album_id));
    await tx.delete(library_identity_source).where(eq(library_identity_source.library_id, album_id));
    await tx.delete(library_identity).where(eq(library_identity.library_id, album_id));
    await tx.delete(artist_library_crossreference).where(eq(artist_library_crossreference.library_id, album_id));
    // No FK backs this column, so nothing else would stop it dangling at a
    // deleted id. At most one row per delete (`logical_album_key` is the PK
    // and a release is representative for at most one key), so no ANALYZE.
    await tx
      .update(album_popularity)
      .set({ representative_library_id: null })
      .where(eq(album_popularity.representative_library_id, album_id));
    await tx.delete(library).where(eq(library.id, album_id));

    // Second, independent record of the same fact. The denylist row is the
    // durable one, but it is a side table nobody is watching; this line puts
    // the deletion in the request log, where an incident responder looking at
    // a time window rather than at a release id will actually meet it. Emitted
    // inside the transaction, so a rollback can leave a log line with no
    // deletion behind it — the wrong way round for an audit trail to fail.
    console.warn(
      '[Library] hard delete',
      JSON.stringify({
        album_id,
        legacy_release_id,
        actor_user_id: attribution.deleted_by_user_id,
        actor_email: attribution.deleted_by_email,
        actor_role: attribution.deleted_by_role,
      })
    );
    Sentry.addBreadcrumb({
      category: 'library.delete',
      level: 'warning',
      message: 'DELETE /library/:id hard-deleted a release',
      data: { album_id, legacy_release_id, actor_user_id: attribution.deleted_by_user_id },
    });

    return { outcome: 'deleted' };
  });
};

/** True when `artist_id` already owns an album with this `code_number` (excluding `exclude_album_id`). */
export const albumCodeNumberTaken = async (
  artist_id: number,
  code_number: number,
  exclude_album_id: number
): Promise<boolean> => {
  const rows = await db
    .select({ id: library.id })
    .from(library)
    .where(
      and(eq(library.artist_id, artist_id), eq(library.code_number, code_number), ne(library.id, exclude_album_id))
    )
    .limit(1);
  return rows.length > 0;
};

export const artistExistsInGenre = async (artist_id: number, genre_id: number): Promise<boolean> => {
  const rows = await db
    .select({ artist_id: genre_artist_crossreference.artist_id })
    .from(genre_artist_crossreference)
    .where(
      and(eq(genre_artist_crossreference.artist_id, artist_id), eq(genre_artist_crossreference.genre_id, genre_id))
    )
    .limit(1);
  return rows.length > 0;
};

export const getAlbumFromDB = async (album_id: number) => {
  const album = await db
    .select({
      id: library.id,
      artist_id: library.artist_id,
      genre_id: library.genre_id,
      format_id: library.format_id,
      code_letters: artists.code_letters,
      code_artist_number: genre_artist_crossreference.artist_genre_code,
      code_number: library.code_number,
      artist_name: artists.artist_name,
      alphabetical_name: artists.alphabetical_name,
      album_title: library.album_title,
      label: library.label,
      record_label: library.label,
      label_id: library.label_id,
      alternate_artist_name: library.alternate_artist_name,
      disc_quantity: library.disc_quantity,
      album_artist: library.album_artist,
      plays: library.plays,
      add_date: library.add_date,
      last_modified: library.last_modified,
      format_name: format.format_name,
      genre_name: genres.genre_name,
      date_lost: library.date_lost,
      date_found: library.date_found,
      on_streaming: library.on_streaming,
      discogs_artist_id: artists.discogs_artist_id,
      musicbrainz_artist_id: artists.musicbrainz_artist_id,
      wikidata_qid: artists.wikidata_qid,
      spotify_artist_id: artists.spotify_artist_id,
      apple_music_artist_id: artists.apple_music_artist_id,
      bandcamp_id: artists.bandcamp_id,
      // BS#2128: `library` is inner-joined below and this reads by
      // `library.id` directly, so the row (and its legacy id) always exists.
      legacy_release_id: library.legacy_release_id,
      // BS#1895: album-detail read surface (GET /library/info?album_id= —
      // the "GET /library/:id" surface in the issue's terms).
      discogs_unavailable: library.discogs_unavailable,
      discogs_unavailable_note: library.discogs_unavailable_note,
      last_discogs_recheck_at: library.last_discogs_recheck_at,
    })
    .from(library)
    .innerJoin(artists, eq(artists.id, library.artist_id))
    .innerJoin(format, eq(format.id, library.format_id))
    .innerJoin(genres, eq(genres.id, library.genre_id))
    .innerJoin(
      genre_artist_crossreference,
      and(
        eq(genre_artist_crossreference.artist_id, library.artist_id),
        eq(genre_artist_crossreference.genre_id, library.genre_id)
      )
    )
    .where(eq(library.id, album_id))
    .limit(1);

  if (!album[0]) return undefined;
  return withDiscogsUnavailableCamelCase(serializeReconciledIdentity(album[0]));
};

/**
 * Resolve a Backend-Service catalog `library.id` (the serial PK) from a
 * tubafrenzy `LIBRARY_RELEASE.ID`, which BS stores in the separate
 * `library.legacy_release_id` column. Returns null for a 0/falsy legacy id or
 * when no catalog row carries it.
 *
 * The two id spaces are distinct: external callers (LML `library.db.id`,
 * `wxyc.info/libraryRelease?id=`, the request line) speak the legacy id, while
 * every BS catalog read is keyed on the serial. This is the single home for the
 * bridge — `routes/internal.route.ts` delegates here (BS#1880), matching the
 * `libraryId === legacy_release_id` convention documented on the `/proxy/library`
 * routes (`controllers/proxy.controller.ts`).
 */
export const getAlbumIdByLegacyId = async (legacyReleaseId: number): Promise<number | null> => {
  if (!legacyReleaseId) return null;
  const [row] = await db
    .select({ id: library.id })
    .from(library)
    .where(eq(library.legacy_release_id, legacyReleaseId))
    .limit(1);
  return row?.id ?? null;
};

/**
 * Fetch a catalog album by its tubafrenzy `legacy_release_id`, returning the
 * same shape as {@link getAlbumFromDB}. Returns undefined when the legacy id
 * resolves to no catalog row — e.g. a release present in the daily-rebuilt
 * `library.db` but not yet synced into BS Postgres.
 */
export const getAlbumByLegacyId = async (legacyReleaseId: number) => {
  const albumId = await getAlbumIdByLegacyId(legacyReleaseId);
  if (albumId === null) return undefined;
  return getAlbumFromDB(albumId);
};

/** Wire-shape of {@link getDiscogsUnavailableFlagsById}'s result. */
export type DiscogsUnavailableFlags = {
  discogsUnavailable: boolean;
  discogsUnavailableNote: string | null;
  lastDiscogsRecheckAt: Date | null;
};

/**
 * Fetch just the three BS#1281 discogs-unavailable columns for a
 * `library.id`, camelCased for the wire. BS#1895: the proxy iOS surface
 * (`GET /proxy/metadata/album`, `proxy.controller.ts#getAlbumMetadata`)
 * resolves an `album_id` against `flowsheet`/`album_metadata`, neither of
 * which carries this MD-set flag — it lives only on `library`. This is the
 * dedicated single-column lookup for that call site, deliberately narrower
 * than {@link getAlbumFromDB} (no joins to `artists`/`format`/`genres`) since
 * the proxy handler only needs the flag trio, not the full catalog row.
 * Returns `undefined` when `album_id` doesn't resolve to a library row.
 */
export const getDiscogsUnavailableFlagsById = async (
  album_id: number
): Promise<DiscogsUnavailableFlags | undefined> => {
  const rows = await db
    .select({
      discogs_unavailable: library.discogs_unavailable,
      discogs_unavailable_note: library.discogs_unavailable_note,
      last_discogs_recheck_at: library.last_discogs_recheck_at,
    })
    .from(library)
    .where(eq(library.id, album_id))
    .limit(1);
  const row = rows[0];
  if (!row) return undefined;
  return {
    discogsUnavailable: row.discogs_unavailable,
    discogsUnavailableNote: row.discogs_unavailable_note,
    lastDiscogsRecheckAt: row.last_discogs_recheck_at,
  };
};

export const markAlbumMissing = async (album_id: number) => {
  const result = await db
    .update(library)
    .set({ date_lost: sql`NOW()`, date_found: null, last_modified: sql`NOW()` })
    .where(eq(library.id, album_id))
    .returning({ id: library.id });
  return result[0];
};

export const markAlbumFound = async (album_id: number) => {
  const result = await db
    .update(library)
    .set({ date_found: sql`NOW()`, last_modified: sql`NOW()` })
    .where(eq(library.id, album_id))
    .returning({ id: library.id });
  return result[0];
};

export const getGenresFromDB = async () => {
  const genreCollection = await db.select().from(genres);
  return genreCollection;
};

export const genreExists = async (genre_id: number): Promise<boolean> => {
  const rows = await db.select({ id: genres.id }).from(genres).where(eq(genres.id, genre_id)).limit(1);
  return rows.length > 0;
};

export const insertGenre = async (genre: NewGenre) => {
  const response = await db.insert(genres).values(genre).returning();
  return response[0];
};

/**
 * `YYYY-MM-DD` guard for the `rotation.add_date` / `rotation.kill_date`
 * write surfaces (`PATCH /library/rotation/:id`, `PATCH /library/rotation`).
 *
 * Shape AND calendar validity. The shape-only predecessor let `2026-09-31`
 * and `2026-13-01` through the 400 gate; Postgres then raised 22008
 * ("date/time field value out of range") and the caller got a 500 plus a
 * Sentry event for what is plainly a client mistake. The round-trip below
 * is the same one `parseIsoDay` in `bmi-performance.service.ts` uses: parse
 * as UTC midnight, then require the re-serialized ISO day to equal the
 * input, which rejects both NaN parses and silent rollovers.
 */
/**
 * `0001-01-01T00:00:00.000Z` as epoch ms — the earliest instant PostgreSQL's
 * `date` type can represent. Anything below it is a year-0 (or negative-year)
 * value that JS is happy to parse and PG rejects with SQLSTATE 22008.
 */
const MIN_PG_DATE_MS = -62135596800000;

export const isISODate = (date: string): boolean => {
  if (typeof date !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(date)) return false;
  const ms = Date.parse(`${date}T00:00:00.000Z`);
  if (Number.isNaN(ms)) return false;
  // JS has a year 0; PostgreSQL does not (1 BC is followed directly by 1 AD),
  // so every `0000-*` date raises 22008 "date/time field value out of range" —
  // the same 500 this round-trip exists to keep out. `Date.parse` accepts them
  // and `toISOString()` round-trips them cleanly, so the round-trip alone
  // cannot see it. Written as a literal rather than `Date.UTC(1, 0, 1)`, which
  // is 1901: `Date.UTC` maps years 0-99 onto 1900-1999.
  if (ms < MIN_PG_DATE_MS) return false;
  return new Date(ms).toISOString().slice(0, 10) === date;
};

// =============================================================================
// Request Line Enhanced Search Functions
// =============================================================================

/**
 * Convert a library_artist_view row to LibraryResult.
 */
function viewRowToLibraryResult(row: LibraryArtistViewEntry): LibraryResult {
  return {
    id: row.id,
    title: row.album_title,
    artist: row.artist_name,
    alphabeticalName: row.alphabetical_name,
    codeLetters: row.code_letters,
    codeArtistNumber: row.code_artist_number,
    codeNumber: row.code_number,
    genre: row.genre_name,
    format: row.format_name,
    onStreaming: row.on_streaming,
    reconciledIdentity: toReconciledIdentity(row),
  };
}

/**
 * Search the library catalog with flexible query options.
 *
 * Routes per the A.5 design:
 * - Free-text `query`: tsvector + plays ranking on `library.search_doc`,
 *   with a trigram fallback when tsvector returns 0 rows. The fallback is
 *   gated so pure-punctuation / single-char queries don't hit the DB twice.
 * - Single-column `artist` or `title`: existing trigram path on the
 *   matching column, but reading from `library` directly so the planner
 *   uses the per-column GIN index instead of forcing the 5-way view JOIN.
 *
 * @param query - Free text search query (artist and/or album)
 * @param artist - Artist name filter
 * @param title - Album/title filter
 * @param limit - Maximum results to return
 * @returns Array of enriched library results
 */
export async function searchLibrary(
  query?: string,
  artist?: string,
  title?: string,
  limit = 5,
  on_streaming?: boolean
): Promise<EnrichedLibraryResult[]> {
  await checkLibraryArtistNameHealth();

  // searchLibraryBothMode now owns the full cascade (tsvector → trigram → CTA
  // → LML); BS#972 unified the cascade location so the catalog read-path at
  // GET /library/ can reach it via fuzzySearchLibrary. Map view rows to
  // EnrichedLibraryResult and carry `matched_via` through.
  const rows = query
    ? await searchLibraryBothMode(query, limit, on_streaming)
    : artist || title
      ? await fuzzySearchLibrary(artist, title, limit, on_streaming)
      : [];

  return rows.map((row) => {
    const enriched = enrichLibraryResult(viewRowToLibraryResult(row));
    if (row.matched_via) enriched.matched_via = row.matched_via;
    if (row.matched_via_alias) enriched.matched_via_alias = row.matched_via_alias;
    return enriched;
  });
}

/**
 * Find a similar artist name in the library using fuzzy matching.
 *
 * Useful for correcting typos or spelling variants (e.g., "Color" vs "Colour").
 *
 * @param artistName - Artist name to match
 * @param threshold - Minimum similarity score (0.0 to 1.0) to accept
 * @returns Corrected artist name if a good match is found, null otherwise
 */
export async function findSimilarArtist(artistName: string, threshold = 0.85): Promise<string | null> {
  await checkLibraryArtistNameHealth();

  // Use pg_trgm similarity function to find close matches. Reads from
  // `library` directly so the planner uses the GIN trigram index on
  // `library.artist_name` (added in 0058) without materializing the view.
  const query = sql`
    SELECT DISTINCT ${library.artist_name} AS artist_name,
      similarity(${library.artist_name}, ${artistName}) as sim
    FROM ${library}
    WHERE similarity(${library.artist_name}, ${artistName}) > ${threshold}
    ORDER BY sim DESC
    LIMIT 1
  `;

  const response = await db.execute(query);
  const rows = response as unknown as Array<{ artist_name: string; sim: number }>;

  if (rows.length > 0) {
    const match = rows[0];
    // Only return if it's actually different (i.e., a correction)
    if (match.artist_name.toLowerCase() !== artistName.toLowerCase()) {
      console.log(
        `[Library] Corrected artist '${artistName}' to '${match.artist_name}' (similarity: ${match.sim.toFixed(2)})`
      );
      return match.artist_name;
    }
  }

  return null;
}

/**
 * Search for albums by title with fuzzy matching.
 *
 * Useful for cross-referencing Discogs album titles with the library.
 *
 * @param albumTitle - Album title to search for
 * @param limit - Maximum results to return
 * @returns Array of enriched library results
 */
export async function searchAlbumsByTitle(albumTitle: string, limit = 5): Promise<EnrichedLibraryResult[]> {
  await checkLibraryArtistNameHealth();

  const rows = (await libraryViewQuery(false)
    .where(sql`${library.album_title} % ${albumTitle}`)
    .orderBy(desc(sql`similarity(${library.album_title}, ${albumTitle})`))
    .limit(limit)) as unknown as LibraryArtistViewEntry[];

  return rows.map((row) => enrichLibraryResult(viewRowToLibraryResult(row)));
}

/**
 * Search the library for releases that contain a track matching `query`.
 *
 * Thin BS-side proxy for LML's `/api/v1/lookup` `SONG_AS_TRACK` strategy
 * (LML#301, catalog-track-search plan §4.2). LML cross-references the title
 * against Discogs, validates the track-on-release server-side, and ranks the
 * results; BS only:
 *
 *   1. Bridges each LML `library_item.id` (which equals BS
 *      `library.legacy_release_id` — 99.88% populated) to a BS `library.id`
 *      via the unique index `library_legacy_release_id_idx`.
 *   2. Excludes library rows already covered by `compilation_track_artist`
 *      for the same query — Track 1 (BS#817) surfaces those; this is the
 *      fallback strategy and should not double-count.
 *   3. Preserves LML's ordering. BS does not re-rank.
 *
 * LML HTTP errors propagate; the wrapper translates them to an empty result
 * for callers, but the throw lets the wrapper skip cache-poisoning. Catalog
 * search is the only consumer today and treats Track 2 as best-effort.
 *
 * Results are memoized by the wrapper in a process-local LRU (size 1000, TTL
 * 10 minutes, keyed by lowercased+trimmed query plus a hash of the
 * catalog-track-search flag state); see {@link searchLibraryByTrack}.
 *
 * Always materializes the full LML-bounded result; the caller's `limit` is
 * applied by the wrapper post-cache so a `limit=10` miss can serve a smaller
 * `limit=5` hit without a second LML round-trip.
 *
 * @param query - Track-title query
 * @returns Array of enriched library results with `matched_via` populated
 * @throws Whatever `lookupBySong` throws — the wrapper handles the boundary.
 */
async function searchLibraryByTrackUncachedOrThrow(query: string): Promise<TaggedLibraryViewEntry[]> {
  const lookupStart = performance.now();
  const response: LookupResponse = await lookupBySong(query, {
    caller: 'library-track-search',
  });
  try {
    Sentry.getActiveSpan()?.setAttributes({
      'track_search.master_lookup_ms': performance.now() - lookupStart,
    });
  } catch (err) {
    console.warn('[Library] searchLibraryByTrack: failed to project master_lookup_ms onto span', err);
  }

  const items = response.results ?? [];
  if (items.length === 0) return [];

  // LML's library_item.id is the legacy MySQL surrogate; BS stores it as
  // library.legacy_release_id. Bridge that to BS library.id so callers get
  // the row id their controllers and dj-site links expect.
  const legacyIds = items.map((item) => item.library_item?.id).filter((id): id is number => typeof id === 'number');
  if (legacyIds.length === 0) return [];

  // Read the view shape, which carries legacy_release_id (BS#2128), so we
  // can re-order BS rows in LML's response order below.
  const rows = (await db
    .select(LIBRARY_VIEW_PROJECTION)
    .from(library)
    .innerJoin(artists, eq(artists.id, library.artist_id))
    .innerJoin(format, eq(format.id, library.format_id))
    .innerJoin(genres, eq(genres.id, library.genre_id))
    .innerJoin(
      genre_artist_crossreference,
      and(
        eq(genre_artist_crossreference.artist_id, library.artist_id),
        eq(genre_artist_crossreference.genre_id, library.genre_id)
      )
    )
    .leftJoin(
      rotation,
      sql`${rotation.album_id} = ${library.id} AND (${rotation.kill_date} > CURRENT_DATE OR ${rotation.kill_date} IS NULL)`
    )
    .where(inArray(library.legacy_release_id, legacyIds))
    // Bound by the LML response size (already capped server-side). The
    // wrapper trims to caller's `limit` post-cache so the cached entry can
    // serve any smaller caller-`limit` from a single LML + JOIN round-trip.
    .limit(legacyIds.length)) as unknown as Array<LibraryArtistViewEntry & { legacy_release_id: number }>;

  // CTA-covered library rows are Track 1's responsibility; filter them out so
  // the read layer doesn't double-surface compilations alongside curated CTA
  // hits.
  const ctaRows =
    rows.length === 0
      ? []
      : ((await db
          .select({ library_id: compilation_track_artist.library_id })
          .from(compilation_track_artist)
          .where(
            and(
              inArray(
                compilation_track_artist.library_id,
                rows.map((r) => r.id)
              ),
              ilikeEscaped(compilation_track_artist.track_title, query, 'contains')
            )
          )) as Array<{ library_id: number }>);
  const ctaCovered = new Set(ctaRows.map((r) => r.library_id));

  // Index BS rows by legacy_release_id so we can emit them in LML's order.
  const rowsByLegacyId = new Map<number, LibraryArtistViewEntry & { legacy_release_id: number }>();
  for (const row of rows) {
    if (row.legacy_release_id != null) {
      rowsByLegacyId.set(row.legacy_release_id, row);
    }
  }

  const results: TaggedLibraryViewEntry[] = [];
  for (const item of items) {
    const legacyId = item.library_item?.id;
    if (legacyId == null) continue;
    const row = rowsByLegacyId.get(legacyId);
    if (!row) continue;
    if (ctaCovered.has(row.id)) continue;
    const tagged: TaggedLibraryViewEntry = { ...row };
    if (item.matched_via && item.matched_via.length > 0) {
      tagged.matched_via = item.matched_via;
    }
    results.push(tagged);
  }
  return results;
}

// --- Track 2 result cache ---
//
// LML's /lookup is the slowest hop in the cascade (HTTP + 3-tier cache), and
// the BS-side bridge query is a 5-way join. Memoizing the final mapped
// EnrichedLibraryResult[] lets repeat searches skip both. Key includes a hash
// of the catalog-track-search feature flags so a flag flip invalidates the
// cache implicitly (the next call generates a new key prefix).
//
// `limit` is intentionally NOT part of the cache key. `searchLibraryByTrack`
// stores the full LML-bounded result set (LML already caps server-side; the
// BS JOIN binds to `legacyIds.length`) and slices to the caller's `limit` at
// read time. This lets a `limit=10` miss serve a subsequent `limit=5` hit
// without a second LML round-trip.
//
// Mirrors the LRUCache shape used in artworkCache (apps/backend/controllers/
// proxy.controller.ts). Plan reference:
// https://github.com/WXYC/wiki/blob/main/plans/catalog-track-search.md#103-latency--cache-budget

const trackSearchCache = new LRUCache<string, TaggedLibraryViewEntry[]>({
  max: 1000,
  ttl: 1000 * 60 * 10, // 10 minutes
  // BS#989: count capacity-driven displacements for the periodic eviction
  // emit. `reason === 'evict'` excludes TTL expiry / explicit delete / set
  // replacement — see cache-stats.ts's module doc.
  dispose: (_value, _key, reason) => {
    if (reason === 'evict') recordCacheEviction('track_search');
  },
});

/**
 * Registered for the once-per-minute cache-stats periodic emit (BS#989) —
 * see `startPeriodicEmit` wiring in `apps/backend/app.ts`.
 */
export function libraryServiceCachesForPeriodicEmit(): RegisteredCache[] {
  return [{ name: 'track_search', cache: trackSearchCache }];
}

function getFlagStateHash(): string {
  const c = getCatalogTrackSearchConfig();
  return `${c.ctaEnabled ? '1' : '0'}${c.discogsEnabled ? '1' : '0'}`;
}

function trackSearchCacheKey(query: string): string {
  return `${query.toLowerCase().trim()}:${getFlagStateHash()}`;
}

/**
 * Test-only hook for clearing the Track 2 LRU between cases. Production code
 * relies on TTL expiry + flag-state-hash invalidation; tests need a way to
 * reset state between `beforeEach` runs.
 *
 * NOTE: this cache is module-scoped, so any test file that exercises the
 * Track 2 cascade (directly or transitively) must call this in its own
 * `beforeEach` — otherwise cache state leaks across files within the same
 * Jest worker. The global unit setup (tests/setup/unit.setup.ts) deliberately
 * stays free of service imports; per-file discipline is the contract.
 */
export function __resetTrackSearchCacheForTests(): void {
  trackSearchCache.clear();
}

/**
 * Memoized wrapper around {@link searchLibraryByTrackUncachedOrThrow}. Cache hits
 * return the mapped `EnrichedLibraryResult[]` (BS rows, `matched_via`, LML
 * ordering) without touching LML or the BS PG JOIN.
 *
 * **Telemetry (BS#828, BS#989).** Wraps the call in a `catalog.track_search`
 * Sentry span and projects onto it: the unified BS#989 cache stats via
 * `recordCacheLookup('track_search', ...)` — `cache_hit` (true on hit, false
 * on miss) plus `cache_name` / `cache_size` / `cache_capacity`, replacing the
 * former `track_search.cache_hit`-only attribute; `track_search.master_lookup_ms`
 * (LML hop only — 0 on cache hit, set by the inner via the active span on
 * miss); and `track_search.latency_ms` (total). Pattern: wrap-at-chokepoint +
 * project-onto-span (sibling: LML#213 / BS#646 for LML cache_stats).
 * Callers up the cascade in `searchLibrary` must not add their own
 * instrumentation.
 *
 * LML failures are NOT cached: if `lookupBySong` rejects, the wrapper returns
 * `[]` straight through without polluting the cache. A genuine empty LML
 * response (no matching releases) IS cached — both because that's the
 * expected steady-state for nonsense queries and because re-running the
 * round-trip every time would defeat the cache's purpose.
 *
 * The returned array is a shallow copy of the cached entry, so callers can
 * sort or mutate without bleeding into subsequent hits.
 *
 * @param query - Track-title query
 * @param limit - Maximum results to return
 * @returns Array of enriched library results with `matched_via` populated
 */
export async function searchLibraryByTrackRaw(query: string, limit: number): Promise<TaggedLibraryViewEntry[]> {
  return Sentry.startSpan({ name: 'searchLibraryByTrack', op: 'catalog.track_search' }, async (span) => {
    const start = performance.now();
    // master_lookup_ms is set by searchLibraryByTrackUncachedOrThrow on the
    // miss path (via the active span). Default to 0 so cache hits and
    // pre-LML failures still emit a numeric value — p95 dashboards then
    // see one row per call without coalesce.
    let lmlSucceeded = true;
    let results: TaggedLibraryViewEntry[];

    const key = trackSearchCacheKey(query);
    const cached = trackSearchCache.get(key);
    const cacheHit = cached !== undefined;
    if (cacheHit) {
      results = cached.slice(0, limit);
    } else {
      // Fetch the full LML-bounded result; the cache stores the un-sliced array.
      try {
        results = await searchLibraryByTrackUncachedOrThrow(query);
      } catch {
        lmlSucceeded = false;
        results = [];
      }
      if (lmlSucceeded) {
        trackSearchCache.set(key, results);
      }
      results = results.slice(0, limit);
    }
    // BS#989: chokepoint cache-stats projection (cache_hit/cache_name/
    // cache_size/cache_capacity) — placed after the possible `.set()` above
    // so `cache_size` reflects the post-touch occupancy. Replaces the old
    // `track_search.cache_hit`-only `span.setAttribute` call; `span` here
    // IS the active span (we're inside this method's own `Sentry.startSpan`
    // callback), so `recordCacheLookup`'s `Sentry.getActiveSpan()` resolves
    // to the same span this function already owns.
    recordCacheLookup('track_search', cacheHit, trackSearchCache);

    // Observability must never break the request path. If the Sentry SDK
    // (or a custom transport hook) throws, swallow the error and continue.
    try {
      span.setAttributes({ 'track_search.latency_ms': performance.now() - start });
    } catch (err) {
      console.warn('[Library] searchLibraryByTrack: failed to project latency onto span', err);
    }
    return results;
  });
}

/**
 * Enriched-shape wrapper around {@link searchLibraryByTrackRaw}. Returns
 * `EnrichedLibraryResult[]` for request-line callers; catalog callers use the
 * raw form via `searchLibraryBothMode`.
 */
export async function searchLibraryByTrack(query: string, limit: number): Promise<EnrichedLibraryResult[]> {
  const rows = await searchLibraryByTrackRaw(query, limit);
  return rows.map((row) => {
    const enriched = enrichLibraryResult(viewRowToLibraryResult(row));
    if (row.matched_via) enriched.matched_via = row.matched_via;
    return enriched;
  });
}

/**
 * Search the library for releases by a specific artist.
 *
 * @param artistName - Artist name to search for
 * @param limit - Maximum results to return
 * @returns Array of enriched library results
 */
export async function searchByArtist(artistName: string, limit = 5): Promise<EnrichedLibraryResult[]> {
  await checkLibraryArtistNameHealth();

  const { enabled: aliasEnabled, minSimilarity: aliasMinSimilarity } = getCatalogSearchAliasConfig();

  if (!aliasEnabled) {
    const rows = (await libraryViewQuery(false)
      .where(sql`${library.artist_name} % ${artistName}`)
      .orderBy(desc(sql`similarity(${library.artist_name}, ${artistName})`))
      .limit(limit)) as unknown as LibraryArtistViewEntry[];

    return rows.map((row) => enrichLibraryResult(viewRowToLibraryResult(row)));
  }

  // Alias-enabled: ALT1 UNION ALL (BS#1318). Single-column trigram on
  // `library.artist_name` as branch (a); branch (b) joins the CTE on
  // `artist_id` and excludes rows already matched by (a). GREATEST collapses
  // to MAX of two terms since there's no album_title predicate here.
  //
  // Wrap the UNION ALL in a subquery so the outer ORDER BY can use
  // expression-shaped terms (`similarity(...)`); Postgres forbids
  // expression ORDER BY directly on a UNION result.
  //
  // BS#2020: same fuzzy-alias-last tier as `searchLibraryByTrigramBoth`, and
  // it bites harder here — this path has no `album_title` term to rank on and
  // its default `limit` is 5, so one artist's alias fan-out can exceed the
  // whole response. That cuts both ways, which is why the tier exempts exact
  // variants: with no OFFSET on this path, demoting one deletes it. See that
  // function and `buildFuzzyAliasTier` for the full rationale.
  const trigramPredicate = sql`${library.artist_name} % ${artistName}`;
  const rows = (await db.execute(sql`
    ${buildAliasHitsCte(artistName, aliasMinSimilarity)}
    SELECT * FROM (
      (
        SELECT ${LIBRARY_VIEW_PROJECTION_RAW}${ALIAS_HITS_PROJECTION_NULLS}
        FROM ${library}
        ${LIBRARY_VIEW_JOINS_RAW}
        WHERE ${trigramPredicate}
      )
      UNION ALL
      (
        SELECT ${LIBRARY_VIEW_PROJECTION_RAW}${ALIAS_HITS_PROJECTION}
        FROM ${library}
        ${LIBRARY_VIEW_JOINS_RAW}
        INNER JOIN alias_hits ON alias_hits.artist_id = ${library.artist_id}
        WHERE NOT ${trigramPredicate}
      )
    ) alias_search
    ORDER BY ${buildFuzzyAliasTier()}, GREATEST(
      similarity(artist_name, ${artistName}),
      COALESCE(alias_max_sim, 0)
    ) DESC, ${buildDirectMatchTieBreak()}, id ASC
    LIMIT ${limit}
  `)) as unknown as (LibraryArtistViewEntry & AliasHitFields)[];

  return rows.map((row) => {
    const tagged = attachAliasHint(row);
    const enriched = enrichLibraryResult(viewRowToLibraryResult(tagged));
    if (tagged.matched_via_alias) enriched.matched_via_alias = tagged.matched_via_alias;
    return enriched;
  });
}

/**
 * Row shape returned by `searchLibraryByCTA`: the standard `LibraryArtistViewEntry`
 * projection plus the matched track_title and artist_name from
 * `compilation_track_artist`. One row per matched CTA entry; grouped to one
 * EnrichedLibraryResult per library_id in TS.
 */
type CTASearchRow = LibraryArtistViewEntry & {
  cta_track_title: string | null;
  cta_artist_name: string;
  /**
   * The `DENSE_RANK()` window the outer `SELECT *` hands back with the rest of
   * the row. Declared so the grouping pass's destructure has to name it to
   * strip it — see the strip site at the end of `searchLibraryByCTARaw`.
   */
  library_rank: number;
};

/**
 * Search the library for compilation tracks whose `track_title` or
 * `artist_name` matches `query` via ILIKE. Returns raw library_artist_view
 * rows (one per matched release) with `matched_via` attached. Used by
 * `searchLibraryBothMode` as the Track 1 (CTA) cascade layer; the enriched
 * wrapper {@link searchLibraryByCTA} maps these to `EnrichedLibraryResult[]`
 * for request-line callers.
 *
 * Returning tagged view rows (rather than enriched results) lets catalog
 * read-paths reuse the wire-shape serializer (`serializeLibraryArtistViewEntry`)
 * without losing `add_date`, `label`, `artwork_url`, etc. (BS#972).
 *
 * @param query - Free text query matched against `track_title` and `artist_name`
 * @param limit - Maximum results to return (counts library rows, not CTA rows)
 * @param on_streaming - Optional filter on `library.on_streaming`
 * @returns Array of tagged view rows with `matched_via` populated
 */
export async function searchLibraryByCTARaw(
  query: string,
  limit: number,
  on_streaming?: boolean
): Promise<TaggedLibraryViewEntry[]> {
  const trimmed = query.trim();
  // Mirror searchLibraryBothMode's guard: pure-punctuation queries (`!!!`,
  // `---`) would otherwise run an unanchored ILIKE scan over every CTA row.
  if (trimmed.length === 0 || !hasAlphanumeric(trimmed)) return [];

  await checkLibraryArtistNameHealth();

  const matchPredicate = sql`(${ilikeEscaped(compilation_track_artist.track_title, trimmed, 'contains')} OR ${ilikeEscaped(compilation_track_artist.artist_name, trimmed, 'contains')})`;
  const streamingPredicate = on_streaming !== undefined ? sql` AND ${library.on_streaming} = ${on_streaming}` : sql``;

  // Raw SQL because we need both the library_artist_view projection and the
  // matched-track columns from `compilation_track_artist` in a single row,
  // which the chained `libraryViewQuery` shape can't express. `limit` is
  // applied per-library-row (via the `DENSE_RANK` window) so that callers
  // get N releases even when a single release contributes multiple hints.
  const queryStmt = sql`
    SELECT * FROM (
      SELECT
        ${LIBRARY_VIEW_PROJECTION_RAW},
        ${compilation_track_artist.track_title} AS cta_track_title,
        ${compilation_track_artist.artist_name} AS cta_artist_name,
        DENSE_RANK() OVER (ORDER BY ${library.id}) AS library_rank
      FROM ${compilation_track_artist}
      INNER JOIN ${library} ON ${library.id} = ${compilation_track_artist.library_id}
      ${LIBRARY_VIEW_JOINS_RAW}
      WHERE ${matchPredicate}${streamingPredicate}
    ) ranked
    WHERE library_rank <= ${limit}
    ORDER BY library_rank, cta_track_title
  `;

  const rows = (await db.execute(queryStmt)) as unknown as CTASearchRow[];
  if (rows.length === 0) return [];

  // Group CTA rows by library_id: one EnrichedLibraryResult per release with
  // a `matched_via` hint per CTA row. Preserves the first-seen ordering so
  // callers see the same DB sort.
  const byLibraryId = new Map<number, { row: CTASearchRow; hints: TrackMatchHint[] }>();
  for (const row of rows) {
    const existing = byLibraryId.get(row.id);
    const hint: TrackMatchHint = {
      title: row.cta_track_title ?? '',
      artist_credit: row.cta_artist_name,
      source: 'cta',
      confidence: 1.0,
    };
    if (existing) {
      existing.hints.push(hint);
    } else {
      byLibraryId.set(row.id, { row, hints: [hint] });
    }
  }

  return Array.from(byLibraryId.values()).map(({ row, hints }) => {
    // Strip the query-only columns so the returned row conforms to
    // `LibraryArtistViewEntry`: the two CTA join columns, and `library_rank`,
    // which the outer `SELECT *` returns alongside them. The wire-shape
    // serializer spreads whatever it is handed, so anything left here reaches
    // the `GET /library/` response next to `matched_via`.
    //
    // Deliberately unasserted (BS#2231): the rest object satisfies
    // `TaggedLibraryViewEntry` structurally, so a field that `CTASearchRow`
    // stops carrying is a compile error here. The `as TaggedLibraryViewEntry`
    // this used to end with suppressed exactly that check. Two things it still
    // can't check, both because a raw `db.execute` result is cast rather than
    // inferred: whether the SQL populated the declared fields (what pinning
    // the shared projection above is for), and whether it returned fields
    // `CTASearchRow` doesn't declare — which is why `library_rank` is declared
    // there rather than left to the cast to hide.
    const { cta_track_title: _t, cta_artist_name: _a, library_rank: _rank, ...viewRow } = row;
    return { ...viewRow, matched_via: hints };
  });
}

/**
 * Enriched-shape wrapper around {@link searchLibraryByCTARaw}. Returns
 * `EnrichedLibraryResult[]` for request-line callers that compose with the
 * other search strategies (`searchAlbumsByTitle`, `searchByArtist`).
 */
export async function searchLibraryByCTA(
  query: string,
  limit: number,
  on_streaming?: boolean
): Promise<EnrichedLibraryResult[]> {
  const rows = await searchLibraryByCTARaw(query, limit, on_streaming);
  return rows.map((row) => {
    const enriched = enrichLibraryResult(viewRowToLibraryResult(row));
    if (row.matched_via) enriched.matched_via = row.matched_via;
    return enriched;
  });
}

/**
 * Filter library results to only include those matching the artist.
 *
 * Requires the searched artist name to appear at the START of the result's
 * artist field (case-insensitive). This prevents false positives like
 * "Toy" matching "Chew Toy" while still allowing "Various" to match
 * "Various Artists - Rock - D".
 *
 * @param results - List of library items from search
 * @param artist - Artist name to filter by
 * @returns Filtered list containing only items where artist matches
 */
export function filterResultsByArtist(
  results: EnrichedLibraryResult[],
  artist: string | null | undefined
): EnrichedLibraryResult[] {
  if (!artist) {
    return results;
  }

  const artistLower = artist.toLowerCase();
  const filtered = results.filter((item) => {
    const itemArtist = (item.artist || '').toLowerCase();
    // Check if result's artist starts with searched artist
    return itemArtist.startsWith(artistLower);
  });

  if (filtered.length < results.length) {
    console.log(`[Library] Filtered ${results.length} results to ${filtered.length} matching artist '${artist}'`);
  }

  return filtered;
}
