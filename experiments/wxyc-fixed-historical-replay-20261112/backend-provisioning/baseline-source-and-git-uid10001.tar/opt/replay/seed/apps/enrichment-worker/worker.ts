/**
 * Enrichment worker entrypoint (BS#892 / Epic C C2).
 *
 * Long-running daemon that subscribes to BS's CDC stream and enriches every
 * new flowsheet track row by calling LML. The N×N idempotent-claim pattern
 * means every worker instance receives every event; the first to win the
 * atomic claim does the work, the losers skip cleanly.
 *
 * Deployment shape (Option A from #892 body): runs as its own Docker
 * container alongside `backend` on the same EC2. Independent restart
 * cycle; doesn't compete with HTTP traffic for the event loop.
 *
 * @see docs/cdc.md
 */

import * as Sentry from '@sentry/node';
import {
  closeDatabaseConnection,
  enableLivenessProbe,
  onCdcConnectionStateChange,
  onCdcErrorEvent,
  onCdcEvent,
  onCdcOversizedEvent,
  startCdcListener,
  stopCdcListener,
} from '@wxyc/database';
import { envInt } from '@wxyc/lml-client';
import { drainInFlightCandidates, makeEnrichmentHandler } from './handler.js';
import { startHealthcheckServer, type HealthState } from './healthcheck.js';
import { sweepStrandedClaims } from './sweep.js';
import { reaskUnresolvedStreaming } from './streaming-reask.js';

/**
 * Stranded-claim sweep cadence (BS#1225). The C6 contract is "recover any
 * `enriching` row past the stranded-claim TTL"; the worker runs the sweep
 * at 60s so worst-case recovery latency is ~one TTL plus one sweep
 * interval. Override via env for shorter-cycle integration runs. `envInt`
 * rejects empty-string / NaN / non-positive values and falls back so a
 * deploy-config typo can't produce a tight-loop `setInterval(fn, 0)`.
 */
const SWEEP_INTERVAL_MS = envInt('ENRICHMENT_SWEEP_INTERVAL_MS', 60_000);

/**
 * Streaming self-heal sweep cadence (BS#1915). Hourly is the backoff
 * spacing the design specifies — no per-row `next_retry_at` column, no
 * exponential schedule; an unresolved streaming field is re-asked at most
 * once per tick, bounded overall by `STREAMING_REASK_ATTEMPT_CAP`
 * (`enrich.ts`). Override via env for shorter-cycle integration runs.
 */
const STREAMING_REASK_SWEEP_INTERVAL_MS = envInt('ENRICHMENT_STREAMING_REASK_SWEEP_INTERVAL_MS', 3_600_000);

/**
 * Per-tick cap on how many albums one streaming-reask sweep re-asks. Bounds
 * the worst-case LML call burst from a single tick (a large unresolved
 * backlog drains over several hourly ticks rather than one large burst);
 * `enrichmentBulkLookup`'s burst coalescing plus the shared client's
 * Semaphore(5)/TokenBucket chokepoint further smooth the actual dispatch.
 */
const STREAMING_REASK_SWEEP_BATCH_SIZE = envInt('ENRICHMENT_STREAMING_REASK_SWEEP_BATCH_SIZE', 200);

/**
 * Per-step bound for the shutdown path so SIGTERM never hangs if PG (or
 * the CDC LISTEN socket, or the healthcheck server) is unresponsive.
 * Each step is best-effort: a throw is captured to Sentry and the next
 * step still runs; a hang trips the bound and the next step still runs.
 * `process.exit(0)` fires unconditionally in the outer finally.
 */
const SHUTDOWN_STEP_BOUND_MS = 5_000;

/**
 * Hard ceiling on the in-flight candidate drain budget. The worker runs in
 * a Docker container stopped with `docker stop $TARGET_APP` (no `-t` flag —
 * see `.github/actions/deploy-service/action.yml`), so SIGTERM-to-SIGKILL
 * is the Docker default of 10s. The drain step runs after `stop_cdc` and
 * `drain_sweep` (each bounded by SHUTDOWN_STEP_BOUND_MS=5s), so by the
 * time control reaches the drain Docker has at most ~10s left in absolute
 * terms — any deadline above ~5s is dead budget. Clamp the env override at
 * SHUTDOWN_STEP_BOUND_MS so a deploy-config typo can't push the deadline
 * past Docker's kill window.
 */
const WORKER_DRAIN_DEADLINE_CEILING_MS = SHUTDOWN_STEP_BOUND_MS;

/**
 * In-flight candidate drain budget (BS#1108). Matches the backend's
 * ENRICHMENT_DRAIN_DEADLINE_MS=2_000 (apps/backend/app.ts) — tuned to the
 * same 10s docker-stop grace window. A hung LML call is bounded by this
 * ceiling so it can't block deploy past Docker's SIGKILL. Override via env
 * for tighter integration runs; the override is clamped at
 * WORKER_DRAIN_DEADLINE_CEILING_MS so an over-eager deploy variable can't
 * blow past the grace window.
 *
 * Note: this is the deadline for `drainInFlightCandidates` *itself*, NOT a
 * `runShutdownStep` bound — drain owns its own internal timeout (the
 * `Promise.race` inside `drainInFlightCandidates`), and the per-step bound
 * would cap it lower than the drain deadline. The drain step is invoked
 * without `runShutdownStep` so the full WORKER_DRAIN_DEADLINE_MS budget is
 * available; its rejection-safe contract removes the need for outer
 * try/catch.
 */
const WORKER_DRAIN_DEADLINE_MS = Math.min(
  envInt('ENRICHMENT_WORKER_DRAIN_DEADLINE_MS', 2_000),
  WORKER_DRAIN_DEADLINE_CEILING_MS
);

/**
 * Run a shutdown step with a per-step bound and a swallow-and-capture
 * handler. Returns when the work resolves, when the bound trips, or when
 * the work rejects (with the rejection sent to Sentry). Never throws.
 *
 * The bound timer is cleared as soon as the work resolves so successful
 * fast steps don't hold libuv ref'd for the full bound window.
 */
async function runShutdownStep(label: string, work: Promise<unknown> | (() => Promise<unknown>)): Promise<void> {
  let timeoutHandle: NodeJS.Timeout | undefined;
  const promise = typeof work === 'function' ? Promise.resolve().then(work) : work;
  try {
    await Promise.race([
      promise.finally(() => {
        if (timeoutHandle !== undefined) clearTimeout(timeoutHandle);
      }),
      new Promise<void>((resolve) => {
        timeoutHandle = setTimeout(() => {
          console.warn(`[enrichment-worker] shutdown step ${label} timed out after ${SHUTDOWN_STEP_BOUND_MS}ms`);
          resolve();
        }, SHUTDOWN_STEP_BOUND_MS);
      }),
    ]);
  } catch (err) {
    const message = err instanceof Error ? err.message : String(err);
    Sentry.captureException(err, {
      tags: { component: 'enrichment-worker', step: `shutdown_${label}` },
    });
    console.error(`[enrichment-worker] shutdown step ${label} failed`, { error: message });
  }
}

const main = async (): Promise<void> => {
  console.log('[enrichment-worker] starting');

  // Healthcheck starts BEFORE the CDC listener so the deploy probe can hit
  // `/healthcheck` immediately (returns 503 until cdcConnected flips true).
  // A delayed start would leave the deploy seeing no listener and timing
  // out on `--health-start-period`.
  const healthState: HealthState = { cdcConnected: false };
  const healthServer = startHealthcheckServer(healthState);

  // Shutdown latch + in-flight sweep tracker, both declared up-front so
  // the SIGTERM/SIGINT handlers can be registered BEFORE any awaited
  // startup work. A signal arriving during the initial sweep below would
  // otherwise hit Node's default SIGTERM handler (immediate exit) and
  // tear the in-flight UPDATE's connection.
  let shuttingDown = false;
  let activeSweep: Promise<void> | null = null;
  // BS#1915: the streaming-reask sweep gets its own overlap latch + timer
  // ref, mirroring the stranded-claim sweep above but independent of it —
  // an hourly tick running long must not block (or be blocked by) the 60s
  // stranded-claim tick.
  let activeStreamingReaskSweep: Promise<void> | null = null;
  // Mutable holder so the shutdown closure (declared next) can clear the
  // timer that's only assigned later, after the initial sweep. Holding via
  // a ref keeps the binding `const` and survives `prefer-const`.
  const sweepTimerRef: { current: NodeJS.Timeout | undefined } = { current: undefined };
  const streamingReaskSweepTimerRef: { current: NodeJS.Timeout | undefined } = { current: undefined };

  const shutdown = async (signal: NodeJS.Signals): Promise<void> => {
    if (shuttingDown) return;
    shuttingDown = true;
    healthState.cdcConnected = false;
    console.log(`[enrichment-worker] received ${signal}; shutting down`);
    try {
      if (sweepTimerRef.current !== undefined) clearInterval(sweepTimerRef.current);
      if (streamingReaskSweepTimerRef.current !== undefined) clearInterval(streamingReaskSweepTimerRef.current);
      // Each step is bounded + best-effort via runShutdownStep so a hang
      // or throw in one (e.g. a wedged CDC LISTEN socket — BS#1014 lists
      // the exact failure modes) doesn't skip the cleanup steps that
      // follow. The ordering still matters:
      //   1. Stop CDC dispatches first so new `handleCandidate` calls
      //      don't fire fresh DB writes during the sweep wait.
      //   2. Drain any in-flight sweep (both the stranded-claim sweep and
      //      the BS#1915 streaming-reask sweep) so closeDatabaseConnection
      //      doesn't tear an in-flight UPDATE.
      //   3. Drain in-flight `handleCandidate` invocations (BS#1108) so
      //      pending LML lookups can finalize their `metadata_status`
      //      write before the pool closes. Bounded by
      //      WORKER_DRAIN_DEADLINE_MS internally — bypasses
      //      runShutdownStep so the full deadline is available (the
      //      per-step bound would cap it lower).
      //   4. Close the pool, then the healthcheck server.
      //   5. Flush Sentry LAST so captures from earlier steps also land.
      await runShutdownStep('stop_cdc', stopCdcListener);
      if (activeSweep !== null) {
        await runShutdownStep('drain_sweep', activeSweep);
      }
      if (activeStreamingReaskSweep !== null) {
        await runShutdownStep('drain_streaming_reask_sweep', activeStreamingReaskSweep);
      }
      // BS#1108: signal-driven count of candidates that didn't finish in
      // time. Mirrors the backend's `metric: 'in_flight_dropped'` tag
      // shape so a single Sentry alert can fan over both surfaces.
      try {
        const remaining = await drainInFlightCandidates(WORKER_DRAIN_DEADLINE_MS);
        if (remaining > 0) {
          Sentry.captureMessage(`enrichment-worker exiting with ${remaining} in-flight candidate(s)`, {
            level: 'warning',
            tags: {
              component: 'enrichment-worker',
              subsystem: 'metadata',
              metric: 'in_flight_dropped',
            },
            extra: { remaining, signal, deadline_ms: WORKER_DRAIN_DEADLINE_MS },
          });
          console.warn(`[enrichment-worker] drained shutdown with ${remaining} in-flight candidate(s)`);
        }
      } catch (err) {
        // Defensive: drainInFlightCandidates is contractually
        // non-throwing, but if a future change reintroduces a throw we'd
        // rather capture it than skip the close_db step below.
        Sentry.captureException(err, {
          tags: { component: 'enrichment-worker', step: 'shutdown_drain_in_flight' },
        });
      }
      await runShutdownStep('close_db', closeDatabaseConnection);
      await runShutdownStep(
        'close_health_server',
        () => new Promise<void>((resolve) => healthServer.close(() => resolve()))
      );
      // Sentry.close has its own bound; mirror the pattern in every
      // `jobs/*/logger.ts` shutdown path.
      await Sentry.close(2000);
    } finally {
      process.exit(0);
    }
  };

  // Register signal handlers FIRST so they cover the initial sweep below.
  // `clearInterval(undefined)` is a Node-tolerated no-op, and `activeSweep`
  // / `sweepTimerRef.current` are guarded with explicit null/undefined checks.
  process.on('SIGTERM', () => void shutdown('SIGTERM'));
  process.on('SIGINT', () => void shutdown('SIGINT'));

  // BS#1014: dispatched true on initial LISTEN + every postgres-js reconnect,
  // dispatched false when the liveness probe observes a wedged LISTEN socket.
  onCdcConnectionStateChange((connected) => {
    healthState.cdcConnected = connected;
    console.log(`[enrichment-worker] cdcConnected=${connected}`);
  });

  onCdcEvent(makeEnrichmentHandler());

  // BS#1120: wire the migration-0094 fallback channels to Sentry so a dropped
  // primary `cdc` payload (oversized row) or an unexpected trigger exception
  // produces a metric the alert can fire on. Both the worker and the
  // backend's CDC dispatcher subscribe; they're independent LISTEN
  // connections, so each process needs its own sink.
  onCdcOversizedEvent((event) => {
    Sentry.captureMessage('cdc.oversized_payload', {
      level: 'warning',
      tags: {
        subsystem: 'cdc',
        consumer: 'enrichment-worker',
        table: event.table,
        action: event.action,
        reason: event.reason,
      },
      extra: {
        schema: event.schema,
        primary_key: event.primary_key,
        payload_bytes: event.payload_bytes,
        timestamp: event.timestamp,
      },
      fingerprint: ['cdc-oversized-payload'],
    });
  });
  onCdcErrorEvent((event) => {
    Sentry.captureMessage('cdc.trigger_exception', {
      level: 'error',
      tags: {
        subsystem: 'cdc',
        consumer: 'enrichment-worker',
        table: event.table,
        action: event.action,
        reason: event.reason,
        sqlstate: event.sqlstate,
      },
      extra: {
        schema: event.schema,
        sqlerrm: event.sqlerrm,
        timestamp: event.timestamp,
      },
      fingerprint: ['cdc-trigger-exception'],
    });
  });

  await startCdcListener();
  // Belt-and-suspenders: the onlisten hook should have already flipped this
  // to true; re-assert in case a future cdc-listener change skips dispatch.
  healthState.cdcConnected = true;

  // BS#1014: probe the LISTEN socket via a sibling NOTIFY/echo loop so a
  // silent disconnect (PG restart without RST, NAT idle, idle-transport
  // death) flips cdcConnected=false within ~one probe cycle.
  await enableLivenessProbe();

  console.log('[enrichment-worker] subscribed to CDC; awaiting events');

  // BS#1225: stranded-claim recovery. Fire one tick immediately so any
  // rows left in `enriching` by a previous instance's death are recovered
  // before they sit through a full SWEEP_INTERVAL_MS, then re-run every
  // interval. Lives in-process (not as a sibling cron container) because:
  //   - The worker owns the claim lifecycle; coupling the recovery to the
  //     worker's process keeps the failure model coherent.
  //   - At a 60s cadence the container-startup cost of a separate cron job
  //     dwarfs the actual UPDATE.
  //   - Reuses the worker's existing PG connection pool.
  // The "worker is permanently dead with strands to clear" failure mode is
  // already covered by the `cdcConnected=false` healthcheck — and no new
  // strands are produced in that state anyway.
  await scheduleSweep();
  sweepTimerRef.current = setInterval(() => {
    void scheduleSweep();
  }, SWEEP_INTERVAL_MS);

  // BS#1915: bounded self-heal of unresolved streaming links. Unlike the
  // stranded-claim sweep above, this does NOT fire an immediate first tick
  // on startup — an unresolved streaming field isn't "stranded" the way a
  // half-claimed row is, it's just waiting its next hourly turn, and firing
  // on every deploy would correlate a burst of re-ask LML calls with
  // deploy frequency. The first tick fires after one full
  // STREAMING_REASK_SWEEP_INTERVAL_MS.
  streamingReaskSweepTimerRef.current = setInterval(() => {
    void scheduleStreamingReaskSweep();
  }, STREAMING_REASK_SWEEP_INTERVAL_MS);

  /**
   * Schedule a sweep tick with overlap and shutdown guards. The
   * `activeSweep` latch causes a tick to skip cleanly if the previous one
   * is still running (slow DB, large backlog) — without this, every tick
   * during a slow sweep would spawn another concurrent UPDATE,
   * compounding load on the partial index. The shutdown latch ensures a
   * timer callback that fires after `clearInterval` has been queued but
   * before libuv cancels it can't write to a pool that's about to close.
   */
  async function scheduleSweep(): Promise<void> {
    if (shuttingDown) return;
    if (activeSweep !== null) return;
    activeSweep = runSweep().finally(() => {
      activeSweep = null;
    });
    await activeSweep;
  }

  /**
   * Schedule a streaming-reask sweep tick (BS#1915), with the same
   * overlap + shutdown guards as `scheduleSweep` above, on its own
   * independent latch so a long-running hourly tick can't starve (or be
   * starved by) the 60s stranded-claim tick.
   */
  async function scheduleStreamingReaskSweep(): Promise<void> {
    if (shuttingDown) return;
    if (activeStreamingReaskSweep !== null) return;
    activeStreamingReaskSweep = runStreamingReaskSweep().finally(() => {
      activeStreamingReaskSweep = null;
    });
    await activeStreamingReaskSweep;
  }
};

/**
 * Wrap one sweep tick. The sweep itself opens a Sentry span and projects
 * the recovered count onto a child span (see `sweep.ts`); this wrapper
 * exists to catch DB errors so an unhealthy sweep can't unhandled-reject
 * and tear down the worker via setInterval's fire-and-forget callback.
 */
async function runSweep(): Promise<void> {
  try {
    const recovered = await sweepStrandedClaims();
    if (recovered > 0) {
      console.log(`[enrichment-worker] sweep recovered ${recovered} stranded claim(s)`);
    }
  } catch (err) {
    const message = err instanceof Error ? err.message : String(err);
    Sentry.captureException(err, {
      tags: { component: 'enrichment-worker', step: 'stranded_claim_sweep' },
    });
    console.error('[enrichment-worker] sweep failed', { error: message });
  }
}

/**
 * Wrap one streaming-reask sweep tick (BS#1915). Same defensive shape as
 * `runSweep` above: catch DB/LML errors here so an unhealthy tick can't
 * unhandled-reject and tear down the worker via setInterval's fire-and-forget
 * callback. `reaskUnresolvedStreaming` itself already isolates per-candidate
 * failures (`Promise.allSettled`); this catch is for a failure in the
 * candidate-selection query itself.
 */
async function runStreamingReaskSweep(): Promise<void> {
  try {
    const result = await reaskUnresolvedStreaming(STREAMING_REASK_SWEEP_BATCH_SIZE);
    if (result.candidates > 0) {
      console.log(
        `[enrichment-worker] streaming-reask sweep processed ${result.candidates} candidate(s): ` +
          `${result.succeeded} succeeded, ${result.failed} failed (stay eligible for the next tick)`
      );
    }
  } catch (err) {
    const message = err instanceof Error ? err.message : String(err);
    Sentry.captureException(err, {
      tags: { component: 'enrichment-worker', step: 'streaming_reask_sweep' },
    });
    console.error('[enrichment-worker] streaming-reask sweep failed', { error: message });
  }
}

void main().catch((err) => {
  console.error('[enrichment-worker] fatal startup error:', err);
  process.exit(1);
});
