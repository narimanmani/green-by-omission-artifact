import { requirePermissions } from '@wxyc/authentication';
import { Router } from 'express';
import * as scheduleController from '../controllers/schedule.controller.js';

export const schedule_route = Router();

schedule_route.get('/', scheduleController.getSchedule);

schedule_route.post('/', requirePermissions({ flowsheet: ['write'] }), scheduleController.addToSchedule);

/*
schedule_route.delete('/', scheduleController.removeFromSchedule);

schedule_route.patch('/', scheduleController.updateSchedule);
*/
