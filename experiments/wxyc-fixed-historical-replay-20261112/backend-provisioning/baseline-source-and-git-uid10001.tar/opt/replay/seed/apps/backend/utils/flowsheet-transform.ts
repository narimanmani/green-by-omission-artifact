/**
 * Flowsheet entry type mapping and text utilities for the webhook receiver.
 *
 * Copied from jobs/flowsheet-etl/transform.ts — keep synchronized if
 * entry type codes or truncation rules change.
 */

import { epochMsToDate } from '@wxyc/database';

export type BackendEntryType =
  'track' | 'show_start' | 'show_end' | 'breakpoint' | 'talkset' | 'dj_join' | 'dj_leave' | 'message';

/**
 * FLOWSHEET_ENTRY_TYPE_CODE_ID codes (production FLOWSHEET_ENTRY_PROD table):
 *   0 = OTHER (non-rotation track)
 *   1-4 = HEAVY/MEDIUM/LIGHT/SINGLES (rotation tracks)
 *   5 = NEW (new vinyl, not yet in rotation)
 *   6 = LIBRARY (existing library release)
 *   7 = TALKSET
 *   8 = HOURLY_BREAK
 *   9 = START_OF_SHOW
 *   10 = END_OF_SHOW
 */
const PROD_ENTRY_TYPE_MAP: Record<number, BackendEntryType> = {
  0: 'track',
  1: 'track',
  2: 'track',
  3: 'track',
  4: 'track',
  5: 'track',
  6: 'track',
  7: 'talkset',
  8: 'breakpoint',
  9: 'show_start',
  10: 'show_end',
};

export const mapProdEntryType = (typeCode: number): BackendEntryType => {
  return PROD_ENTRY_TYPE_MAP[typeCode] ?? 'message';
};

/** Entry types whose legacy ARTIST_NAME text is display content, not a real artist. */
export const isMessageEntryType = (entryType: string): boolean =>
  entryType === 'breakpoint' || entryType === 'talkset' || entryType === 'message';

/**
 * Resolve the breakpoint top-of-hour for a flowsheet entry (BS#1449).
 *
 * tubafrenzy's RADIO_HOUR (epoch ms) is the authoritative top-of-hour a
 * breakpoint marks, distinct from the ~1-min-early add_time. Only breakpoint
 * rows carry it; every other type stores null. Routing through epochMsToDate
 * (rather than a bare `new Date`) maps 0/absent/non-finite/Invalid → null, so a
 * missing OR malformed RADIO_HOUR yields null instead of an Invalid Date.
 * Mirrors resolveRadioHour in jobs/flowsheet-etl/transform.ts.
 */
export const resolveRadioHour = (entryType: BackendEntryType, radioHourMs: number | null): Date | null =>
  entryType === 'breakpoint' ? epochMsToDate(radioHourMs) : null;
