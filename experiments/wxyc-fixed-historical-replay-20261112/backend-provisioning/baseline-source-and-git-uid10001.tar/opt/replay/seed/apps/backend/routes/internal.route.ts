import { Router } from 'express';
import * as Sentry from '@sentry/node';
import { and, eq, inArray, isNull, sql } from 'drizzle-orm';
import {
  db,
  flowsheet,
  shows,
  rotation,
  library,
  truncate,
  user,
  epochMsToDate,
  isBeyondFutureTolerance,
  parseRotationBin,
  ROTATION_BINS,
} from '@wxyc/database';
import { getAlbumIdByLegacyId } from '../services/library.service.js';
import { serverEventsMgr, Topics, FsEvents } from '../utils/serverEvents.js';
import {
  mapProdEntryType,
  isMessageEntryType,
  resolveRadioHour,
  type BackendEntryType,
} from '../utils/flowsheet-transform.js';
import { __resetUpcomingShowsMapsCacheForTests } from '../services/concerts.service.js';

const ETL_NOTIFY_KEY = process.env.ETL_NOTIFY_KEY ?? '';

// Marker entry types that surface `dj_name` on the v2 wire (and so must be
// resolved on the webhook insert path — BS#1371). Track + message-typed rows
// follow other rules and are intentionally excluded.
//
// `dj_join` / `dj_leave` are kept defensively even though `mapProdEntryType`
// currently doesn't emit them (the tubafrenzy PROD code map covers 0-10 only,
// none of which resolve to join/leave). If tubafrenzy ever extends the PROD
// table with join/leave codes, the gate is ready and the attribution caveat
// below applies. Typed as `Set<BackendEntryType>` so a typo'd literal would
// fail to compile rather than silently match no entry at runtime.
const MARKER_ENTRY_TYPES: ReadonlySet<BackendEntryType> = new Set<BackendEntryType>([
  'show_start',
  'show_end',
  'dj_join',
  'dj_leave',
]);

// Materialized once for `inArray(...)` in the sibling-marker heal below — avoids
// re-spreading the Set into an array on every webhook delivery.
const MARKER_ENTRY_TYPE_LIST: BackendEntryType[] = [...MARKER_ENTRY_TYPES];

// Stable Sentry grouping key for the BS#2143 future-`startTime` clamp below.
// One issue for the whole class of event, not one per legacy_entry_id or per
// delivery — a persistently-fast tubafrenzy clock would otherwise fire this
// on every webhook delivery and, without a shared fingerprint, mint a fresh
// issue (or at least a noisy one) per entry. Mirrors the CDC dispatcher's
// `OVERSIZED_FINGERPRINT`/`ERROR_FINGERPRINT` convention
// (apps/backend/services/cdc/dispatcher.ts): the per-occurrence detail
// (legacy_entry_id, rejected value, how far ahead) still goes out on every
// event via `tags`/`extra`, so nothing is lost — only the issue count is
// capped, which is what keeps an alert threshold meaningful under sustained
// skew instead of paging on issue-count churn.
const FUTURE_START_TIME_FINGERPRINT = ['webhook-future-add-time'];

// Sibling grouping key for the "startTime present but unparseable" arm below.
// Separate from the clamp's fingerprint because the two are different upstream
// defects with different fixes — a fast clock vs. a payload/serializer change —
// and collapsing them into one issue would let a serializer regression hide
// inside an ongoing clock-skew issue.
const UNPARSEABLE_START_TIME_FINGERPRINT = ['webhook-unparseable-start-time'];

export const internal_route = Router();

/**
 * Authenticate internal requests via a shared secret in the X-Internal-Key header.
 * Used by the ETL and tubafrenzy webhook.
 */
function authenticateInternal(key: string | undefined): boolean {
  return !!ETL_NOTIFY_KEY && key === ETL_NOTIFY_KEY;
}

/**
 * POST /internal/test/reset-upcoming-shows-cache — dev/test-only.
 *
 * The `upcoming_show` map cache (BS#1616) lives in THIS server process, so the
 * out-of-process integration spec (which talks to the backend over HTTP) can't
 * clear it with an in-process helper. It resets through this endpoint instead,
 * to get a genuine cold read for the anti-N+1 batching + cache-hit assertions.
 *
 * Registered ONLY when NODE_ENV is development/test — the route does not exist in
 * production. Mirrors the `isDevOrTest` gate in internal-bans.route.ts and the
 * auth server's `/auth/test/*` surface. No auth key: it only clears an ephemeral
 * in-memory cache (no data at risk) and the route is absent in prod anyway.
 */
const isDevOrTest = process.env.NODE_ENV === 'development' || process.env.NODE_ENV === 'test';

if (isDevOrTest) {
  internal_route.post('/test/reset-upcoming-shows-cache', (_req, res) => {
    __resetUpcomingShowsMapsCacheForTests();
    res.sendStatus(204);
  });
}

/**
 * POST /internal/flowsheet-sync-notify
 *
 * Called by the flowsheet ETL after importing new or updated entries from
 * tubafrenzy. Broadcasts a refetch event to all SSE clients subscribed to
 * the liveFs topic so dj-site UIs stay in sync.
 */
internal_route.post('/flowsheet-sync-notify', (req, res) => {
  if (!authenticateInternal(req.get('X-Internal-Key'))) {
    res.status(401).json({ error: 'Unauthorized' });
    return;
  }

  serverEventsMgr.broadcast(Topics.liveFs, {
    type: FsEvents.refetch,
    payload: { source: 'etl' },
  });

  res.json({ ok: true });
});

interface ResolvedShow {
  id: number;
  /**
   * COALESCE(auth_user.dj_name, shows.legacy_dj_name) — matches the
   * ETL / dj-name-backfill SQL. The `resolveDjDisplayName` helper
   * (services/flowsheet.service.ts) can't be reused here because its
   * signature is `(djName) => string | null` — it has no
   * `legacy_dj_name` parameter. Picking the same 2-column COALESCE the
   * ETL (jobs/flowsheet-etl/job.ts:97) and backfill
   * (jobs/flowsheet-dj-name-backfill/job.ts:66) use means a row later
   * re-resolved by either job lands the identical value — no writer
   * drift. The known consequence — neither writer filters the literal
   * 'Anonymous' the live path strips — is shared with both jobs by
   * design (BS#1371 spec).
   *
   * `auth_user.name` is intentionally NOT in the chain — dj-site
   * provisioning writes the user's real name into that column
   * (`name: realName || username` in the roster UI), and surfacing real
   * names on the public v2 wire would be PII exposure. The live path's
   * asymmetric-fallback policy already handles null gracefully
   * (degraded `Start of show: ${time}` instead of leaking a real name).
   *
   * Null when the show has no resolvable name from either source
   * (stub shows created before the payload carried `djHandle` (BS#1723) —
   * once ETL-fillable, now permanent until a later handle-bearing delivery
   * heals them, since WXYC/wiki#88 Phase 3 unscheduled the ETL; legacy rows
   * with no primary_dj_id and no legacy_dj_name).
   */
  dj_name: string | null;
}

/**
 * Look up a show by legacy_show_id, creating a stub if it doesn't exist.
 * Uses an insert-or-fill upsert + re-select for concurrent-insert safety:
 * DO NOTHING when no handle is carried, otherwise ON CONFLICT DO UPDATE
 * fills `legacy_dj_name` so a lost concurrent-insert race can't drop it.
 *
 * Also resolves the show's display dj_name via a LEFT JOIN to auth_user on
 * `shows.primary_dj_id` — same query path, no extra round-trip. The webhook
 * INSERT writes this onto marker rows so the v2 wire honours the
 * FLOWSHEET_DJ_NAME_NON_NULL contract (BS#1371).
 *
 * `legacyDjHandle` is the optional `entry.djHandle` from sign-on/sign-off
 * marker payloads (tubafrenzy#607, always DJ_HANDLE — never the real name).
 * When present it names the stub at creation, and heals an existing show
 * whose name resolves to null — the sign-on race where the BREAKPOINT
 * delivery creates the stub before the START_OF_SHOW delivery carries the
 * handle. Without it, `on_air` reports null (= confirmed automation,
 * "AUTO DJ" on iOS) — a live human DJ rendered as "AUTO DJ" (BS#1723).
 *
 * That used to be bounded by the flowsheet ETL's next half-hourly tick. Since
 * Phase 3 of the tubafrenzy decommission (WXYC/wiki#88) unscheduled that job,
 * nothing else backfills `shows.legacy_dj_name`, so this handle is the ONLY
 * thing standing between a classic-UI show and a permanent "AUTO DJ"
 * misrender. Treat it as load-bearing, not as an optimization ahead of a
 * repair that is coming anyway.
 *
 * Still normalized with `truncate(_, 128)` — the retained one-shot ETL applies
 * the same truncation, so if it is ever run in the Phase 6a window its
 * `IS DISTINCT FROM` pass sees an identical byte sequence. A non-null resolved
 * name always wins — the heal never overwrites (BS#1371/#1449 convention), and
 * `legacy_dj_name IS NULL` in the WHERE guards the probe/UPDATE gap against
 * any concurrent writer.
 */
async function resolveShow(legacyShowId: number, legacyDjHandle: string | null): Promise<ResolvedShow | null> {
  if (!legacyShowId) return null;
  const handle = truncate(legacyDjHandle, 128);

  const selectShow = () =>
    db
      .select({
        id: shows.id,
        dj_name: sql<string | null>`COALESCE(${user.djName}, ${shows.legacy_dj_name})`,
      })
      .from(shows)
      .leftJoin(user, eq(user.id, shows.primary_dj_id))
      .where(eq(shows.legacy_show_id, legacyShowId))
      .limit(1);

  const existing = await selectShow();
  if (existing.length > 0) {
    if (existing[0].dj_name === null && handle !== null) {
      await db
        .update(shows)
        .set({ legacy_dj_name: handle })
        .where(and(eq(shows.id, existing[0].id), isNull(shows.legacy_dj_name)));
      const [reread] = await selectShow();
      return reread ? { id: reread.id, dj_name: reread.dj_name } : { id: existing[0].id, dj_name: existing[0].dj_name };
    }
    return { id: existing[0].id, dj_name: existing[0].dj_name };
  }

  // Create a stub show.
  //
  // `start_time` is NOW() — the webhook-delivery instant, not the show's real
  // start — and `show_name` / `end_time` are left NULL. The half-hourly ETL
  // used to overwrite all three from tubafrenzy's authoritative copy on its
  // next tick (BS#1084). Phase 3 of the tubafrenzy decommission (WXYC/wiki#88)
  // unscheduled that job, so these placeholder values now PERSIST until Phase
  // 6a retires this webhook. The `shows` docblock in schema.ts records the
  // resulting shape; don't reintroduce a "the ETL will fix it" assumption.
  //
  // Conflict arm: the two sign-on deliveries can interleave so tightly that
  // BOTH probes above see no row; if the handle-bearing delivery then loses
  // the INSERT race to the nameless one, a bare DO NOTHING would discard the
  // handle and re-open the BS#1723 window permanently. When we
  // carry a handle, fill legacy_dj_name atomically instead — same
  // never-overwrite `IS NULL` guard as the heal above, same
  // onConflictDoUpdate-on-legacy_show_id shape as the flowsheet ETL's shows
  // upsert. With no handle there is nothing to fill; keep DO NOTHING.
  const stubValues = {
    legacy_show_id: legacyShowId,
    start_time: new Date(),
    ...(handle !== null && { legacy_dj_name: handle }),
  };
  if (handle !== null) {
    await db
      .insert(shows)
      .values(stubValues)
      .onConflictDoUpdate({
        target: shows.legacy_show_id,
        set: { legacy_dj_name: handle },
        setWhere: isNull(shows.legacy_dj_name),
      });
  } else {
    await db.insert(shows).values(stubValues).onConflictDoNothing();
  }

  const [row] = await selectShow();
  return row ? { id: row.id, dj_name: row.dj_name } : null;
}

/**
 * Trim a COALESCE-resolved dj_name and coerce blank/whitespace to null so
 * the v2 wire never serves a string of spaces. Mirrors the live writer's
 * `resolveDjDisplayName` shape — same input, same null normalization —
 * minus the 'Anonymous' literal filter (kept consistent with the ETL +
 * backfill convention; see ResolvedShow.dj_name docstring).
 */
function normalizeMarkerName(raw: string | null | undefined): string | null {
  const trimmed = raw?.trim();
  return trimmed ? trimmed : null;
}

const VALID_ACTIONS = new Set(['create', 'update', 'delete']);

/**
 * POST /internal/flowsheet-webhook
 *
 * Receives flowsheet entry events from tubafrenzy. Called by tubafrenzy's
 * WebhookFlowsheetEntryListener when entries are created, updated, or deleted.
 *
 * Payload:
 *   { action: "create"|"update", entry: { id, radioShowId, flowsheetEntryType, ... } }
 *   { action: "delete", entryId: number }
 */
internal_route.post('/flowsheet-webhook', async (req, res) => {
  if (!authenticateInternal(req.get('X-Internal-Key'))) {
    res.status(401).json({ error: 'Unauthorized' });
    return;
  }

  const { action, entry, entryId } = req.body ?? {};

  if (!action || !VALID_ACTIONS.has(action)) {
    res.status(400).json({ error: 'Missing or invalid action. Expected: create, update, or delete.' });
    return;
  }

  try {
    if (action === 'delete') {
      if (typeof entryId !== 'number') {
        res.status(400).json({ error: 'Missing entryId for delete action.' });
        return;
      }
      await db.delete(flowsheet).where(eq(flowsheet.legacy_entry_id, entryId));
    } else {
      // create or update — both use upsert
      if (!entry || typeof entry.id !== 'number') {
        res.status(400).json({ error: 'Missing entry.id for create/update action.' });
        return;
      }

      const entryType = mapProdEntryType(entry.flowsheetEntryType ?? 0);
      const isMsgType = isMessageEntryType(entryType);
      const artistName = isMsgType ? null : truncate(entry.artistName, 128);
      const albumTitle = truncate(entry.releaseTitle, 128);
      const trackTitle = truncate(entry.songTitle, 128);

      // Resolve linkage at INSERT so the CDC consumer worker sees
      // `album_id` already set and takes the linked enrichment branch;
      // without this, the worker takes the unlinked branch and writes
      // inline metadata that never reaches album_metadata (#1028). Post-#894
      // inline enrichment no longer fires from this route — CDC drives the
      // consumer.
      const rawLibraryId = entry.libraryReleaseId ?? 0;
      const rawRotationId = entry.rotationReleaseId ?? 0;
      const [show, albumId, rotationId] = await Promise.all([
        resolveShow(entry.radioShowId, typeof entry.djHandle === 'string' ? entry.djHandle : null),
        resolveAlbumId(rawLibraryId),
        resolveRotationId(rawRotationId),
      ]);
      const showId = show?.id ?? null;
      // For show_start / show_end / dj_join / dj_leave the v2 wire surfaces
      // dj_name (FLOWSHEET_DJ_NAME_NON_NULL contract). Other entry types
      // either denormalize dj_name differently (track) or don't surface it
      // (talkset, breakpoint, message), so we leave them null and let the
      // existing population paths handle them.
      //
      // Trim whitespace and treat blank as null so the wire doesn't surface
      // a string of spaces (the live writer's `resolveDjDisplayName` does
      // the same — without it, a `shows.legacy_dj_name='   '` from a
      // tubafrenzy edit would persist into flowsheet.dj_name and the v2
      // wire would emit whitespace, defeating the BS#1371 fix via a
      // different path).
      //
      // dj_join / dj_leave caveat (BS#1371): when those codes do enter via
      // the webhook path (currently they don't — see MARKER_ENTRY_TYPES
      // above), the payload has no per-event DJ id, only radioShowId — so
      // guest-join markers would attribute to shows.primary_dj_id, not the
      // joining guest. Same known limitation as flowsheet-dj-name-backfill;
      // the live createJoinNotification path is the only one that gets
      // guest attribution right today.
      const resolvedShowName = normalizeMarkerName(show?.dj_name);
      const markerDjName = MARKER_ENTRY_TYPES.has(entryType) ? resolvedShowName : null;

      // tubafrenzy's authoritative top-of-hour for a breakpoint (BS#1449).
      // `radioHour` (epoch ms) is present on breakpoint payloads only once
      // tubafrenzy#593 ships; resolveRadioHour (shared with the ETL) tolerates
      // its absence (null) and any malformed value (→ null via epochMsToDate),
      // so deploy ordering is safe and a garbage payload can't write an Invalid
      // Date. Computed once and shared by the INSERT and the ON-CONFLICT heal.
      const breakpointRadioHour = resolveRadioHour(entryType, entry.radioHour ?? null);

      // Shared by the row's `add_time` and, for `show_end` markers, the
      // `shows.end_time` fast-path below (and, transitively, by
      // `closeShowFromTerminalShowEndMarker` in flowsheet.service.ts, which
      // re-reads THIS row's own `add_time` later) — one clock reading per
      // delivery so all of those never drift apart by the few ms between two
      // separate `new Date()` calls. `now` is read exactly once, below,
      // whether or not it ends up being used.
      //
      // BS#2143: two defects fixed in the same expression that used to be
      // `entry.startTime ? new Date(entry.startTime) : new Date()`.
      //
      // (a) No finite/NaN guard. The webhook body is untyped
      //     (`req.body ?? {}`, validated only on `action`/`entry.id`), so a
      //     non-numeric truthy `entry.startTime` (a string, an object) made
      //     `new Date(...)` an Invalid Date and the Drizzle insert below
      //     threw, 500-ing the whole delivery. `resolveRadioHour` six lines
      //     up already routes through `epochMsToDate` "so a garbage payload
      //     can't write an Invalid Date" — `markerTimestamp` was the one
      //     timestamp in this handler that never got that treatment. Fixed
      //     by routing `entry.startTime` through the same `epochMsToDate`
      //     (null/0/NaN/non-finite → null; 0 is tubafrenzy's "not set"
      //     sentinel, which the old bare-falsy check already depended on).
      //
      // (b) No upper bound. A tubafrenzy host with a fast clock (or a bad
      //     manual entry) could pin `add_time` in the future. Before #2132
      //     that was self-healing — `fetchRecentRows` sorted `ORDER BY id
      //     DESC` and the row aged out after ~200 more inserts. Since #2132
      //     switched to `ORDER BY add_time DESC, id DESC`
      //     (playlist-proxy.service.ts `fetchRecentRows`), a future row
      //     sorts first and NEVER ages out — it permanently pins the head of
      //     `/playlists/recentEntries` (the whole legacy iOS/Android fleet)
      //     and permanently freezes `X-Last-Modified`
      //     (`lastModifiedFromTimestamps` is `Math.max(...add_time)`,
      //     playlist.controller.ts). It also permanently pins the ONE-row
      //     `GET /flowsheet/latest` read (`getEntriesByPage(0, 1)`,
      //     flowsheet.service.ts / flowsheet.controller.ts), which sorts the
      //     same way — not named in BS#2143's issue body, but the same root
      //     cause and in scope for this fix.
      //
      //     Decision, made explicitly per the BS#2143 acceptance criterion:
      //     CLAMP a beyond-tolerance `startTime` to the delivery clock,
      //     don't reject it. This is a live flowsheet; dropping or 500-ing a
      //     DJ's entry over a clock-skew problem on tubafrenzy's end is worse
      //     than storing a slightly-wrong `add_time`. Contrast with
      //     `resolveEntryTimestamp` (jobs/flowsheet-etl/transform.ts), the
      //     ETL twin that reads the same upstream fields: that job
      //     back-fills HISTORICAL rows, so clamping there would stamp a
      //     months-old row with the import's wall clock and pin it exactly
      //     where this fix exists to prevent pinning — it falls through to
      //     the next candidate timestamp instead. Same bound
      //     (`FUTURE_TIMESTAMP_TOLERANCE_MS`), deliberately different
      //     handling per site; see that function's doc comment for the
      //     reverse cross-reference.
      //
      //     Deliberately NOT a read-side `add_time <= now()` predicate on
      //     `fetchRecentRows`/`getEntriesByPage` — that would make a
      //     legitimately-live entry invisible for as long as an upstream
      //     clock runs fast, and a live flowsheet silently lagging the DJ is
      //     a worse failure than the one being fixed (BS#2143 acceptance
      //     criterion).
      //
      //     No env var for the tolerance — see `FUTURE_TIMESTAMP_TOLERANCE_MS`'s
      //     doc comment in `shared/database/src/legacy/etl-utils.ts` for why.
      //
      //     A clamp is surfaced to Sentry (grouped under one stable
      //     fingerprint — see `FUTURE_START_TIME_FINGERPRINT` above) so a
      //     genuinely misconfigured tubafrenzy clock gets diagnosed instead
      //     of silently absorbed.
      //
      // The `null` arm splits in two, because (a)'s fix would otherwise trade
      // a loud failure for a silent one. `epochMsToDate` returns null for BOTH
      // "absent" (`null`/`undefined`/`0` — the overwhelmingly common case,
      // every ordinary track row) and "present but unparseable" (a string, an
      // object, a non-finite number — always an upstream defect). Before this
      // change the second class produced an Invalid Date and a 500: wrong, but
      // impossible to miss. Collapsing both into a silent fall-back to `now`
      // would mean that if tubafrenzy ever changed its JSON serializer to ship
      // `startTime` as a string (Jackson's long-as-string is a common config),
      // EVERY `show_start`/`show_end` marker would quietly lose its event
      // timestamp — and `shows.end_time`, which nothing downstream corrects
      // (both writers gate on `WHERE end_time IS NULL`), would silently become
      // the delivery time with zero telemetry. So: "absent" stays silent,
      // "present but unparseable" alerts. The truthiness test is deliberately
      // the same one the pre-BS#2143 expression used to define "absent", so
      // the set of values that stay silent is unchanged.
      const parsedStartTime = epochMsToDate(entry.startTime ?? null);
      const now = new Date();
      let markerTimestamp: Date;
      if (parsedStartTime === null) {
        if (entry.startTime) {
          Sentry.captureMessage('[webhook] flowsheet entry startTime present but unparseable — using delivery clock', {
            level: 'warning',
            tags: { subsystem: 'flowsheet-webhook' },
            extra: {
              legacy_entry_id: entry.id,
              unparseable_start_time_raw: entry.startTime,
              unparseable_start_time_type: typeof entry.startTime,
            },
            fingerprint: UNPARSEABLE_START_TIME_FINGERPRINT,
          });
        }
        markerTimestamp = now;
      } else if (isBeyondFutureTolerance(parsedStartTime, now)) {
        Sentry.captureMessage(
          '[webhook] flowsheet entry startTime beyond future tolerance — clamped to delivery clock',
          {
            level: 'warning',
            tags: { subsystem: 'flowsheet-webhook' },
            extra: {
              legacy_entry_id: entry.id,
              rejected_start_time_raw: entry.startTime,
              rejected_start_time_iso: parsedStartTime.toISOString(),
              ahead_ms: parsedStartTime.getTime() - now.getTime(),
            },
            fingerprint: FUTURE_START_TIME_FINGERPRINT,
          }
        );
        markerTimestamp = now;
      } else {
        markerTimestamp = parsedStartTime;
      }

      // INSERT ... ON CONFLICT DO NOTHING RETURNING { id }: either we win
      // the insert and PG hands back exactly one row, or a concurrent
      // INSERT / prior webhook delivery already claimed the
      // `legacy_entry_id` and RETURNING is empty. The empty-RETURNING
      // signal replaces the previous `(xmax = 0)` system-column trick
      // (BS#909): same correctness, no MVCC-internal dependency, race-
      // safe under concurrent webhook delivery (acceptance criterion (c)
      // — exactly one fresh-INSERT row per legacy_entry_id, so the CDC
      // consumer worker sees exactly one INSERT event per logical row).
      //
      // `rotation_id` (BS#1268) is set on INSERT only — like `album_id`,
      // linkage is anchored to the first delivery and not refreshed on
      // ON CONFLICT updates. Tubafrenzy is the source of truth for the
      // linkage; if the operator re-binds a flowsheet entry to a different
      // rotation row, that's a new legacy_entry_id, not an UPDATE.
      //
      // `album_id` anchoring has one failure mode this route cannot fix: the
      // `library` row may not exist yet at first delivery (library-etl lag, or
      // the librarian filing after the MD bins the release), and the anchor
      // then pins NULL forever. `jobs/legacy-linkage-resolve/` re-runs that
      // join on a schedule and is the only thing that repairs it — it was a
      // tail pass inside flowsheet-etl until WXYC/wiki#88 Phase 3 unscheduled
      // that job. Don't "fix" this by refreshing album_id on conflict; the
      // anchoring is deliberate.
      const inserted = await db
        .insert(flowsheet)
        .values({
          legacy_entry_id: entry.id,
          legacy_release_id: rawLibraryId || null,
          album_id: albumId,
          rotation_id: rotationId,
          show_id: showId,
          entry_type: entryType,
          artist_name: artistName,
          album_title: albumTitle,
          track_title: trackTitle,
          record_label: truncate(entry.labelName, 128),
          message: isMsgType ? truncate(entry.artistName, 250) : null,
          dj_name: markerDjName,
          request_flag: !!entry.requestFlag,
          segue: false,
          play_order: entry.sequenceWithinShow ?? 0,
          add_time: markerTimestamp,
          radio_hour: breakpointRadioHour,
        })
        .onConflictDoNothing()
        .returning({ id: flowsheet.id });

      const created = !!inserted[0];

      if (!created) {
        // Conflict path: refresh the mutable subset of fields on the row
        // tubafrenzy is updating. Matches the original ON CONFLICT DO
        // UPDATE set-list — show_id / play_order / segue / add_time stay
        // anchored to the first INSERT's values, mutable metadata-ish
        // fields move with the latest webhook payload.
        //
        // `request_flag` (BS#1857 / BS#1623) is deliberately EXCLUDED here
        // too, joining `segue`: for a live show, BS's DJ-facing
        // PATCH /flowsheet is the authoritative writer for both flags.
        // Refreshing `request_flag` from tubafrenzy's copy on every
        // conflict-refresh could revert a DJ's toggle if tubafrenzy's
        // mirror ever lags or diverges from BS's live state. The fresh-
        // INSERT branch above still writes it from the payload — this only
        // scopes the never-overwrite rule to the re-sync UPDATE path.
        //
        // `dj_name` is conditionally refreshed only when the resolver
        // produced a non-null value (defense-in-depth for the stub-then-
        // fill race: webhook may have inserted with dj_name=NULL when the
        // stub `shows` row had no resolvable name yet; a later redelivery
        // that carries the handle heals the row via `resolveShow`. This used
        // to say "after the ETL fills shows.legacy_dj_name" — since Phase 3
        // (WXYC/wiki#88) unscheduled that job, the handle-bearing delivery is
        // the only filler).
        // We never overwrite a non-NULL stored value with NULL — that
        // would regress a row the live path or a prior delivery already
        // resolved.
        //
        // BS#2143: `add_time` is confirmed absent from this refresh set (see
        // the anchoring note above) — the conflict-UPDATE path never rewrites
        // it, so it can't inherit a bad `markerTimestamp` from a redelivery
        // either. Nothing to bound here.
        const refresh: Record<string, unknown> = {
          artist_name: artistName,
          album_title: albumTitle,
          track_title: trackTitle,
          record_label: truncate(entry.labelName, 128),
          message: isMsgType ? truncate(entry.artistName, 250) : null,
          entry_type: entryType,
        };
        if (markerDjName !== null) {
          refresh.dj_name = markerDjName;
        }
        // Heal breakpoint rows inserted before radio_hour existed (BS#1449).
        // Like dj_name, only set when present — never overwrite with NULL.
        if (breakpointRadioHour) {
          refresh.radio_hour = breakpointRadioHour;
        }
        await db.update(flowsheet).set(refresh).where(eq(flowsheet.legacy_entry_id, entry.id));
      }

      // show_end → shows.end_time fast-path (BS#1861, option (a)).
      //
      // The stub-show flow above ("Create a stub show" in resolveShow) leaves a
      // webhook-created show's `end_time` NULL. That's fine for a show that's
      // still being DJed, but a `show_end` marker means tubafrenzy just signed
      // the show off — while `shows.end_time` stays NULL the show reads as
      // still open. `POST /flowsheet/join`'s start-vs-join decision keys on
      // exactly that column (see BS#1861 (b) for the second, independent
      // guard), so a DJ going live would be silently guest-joined into the
      // just-ended show instead of starting a new one.
      //
      // Fix: set `shows.end_time` here too, from the same timestamp the
      // marker row itself gets.
      //
      // This was originally a fast-path in front of the flowsheet ETL's shows
      // UPSERT, which unconditionally overwrote `end_time` from tubafrenzy's
      // own value on its next tick (value-aware `setWhere`, BS#1059/#1956) —
      // so a discrepancy between this webhook guess and tubafrenzy's real
      // sign-off timestamp self-healed within one ETL cycle. Phase 3 of the
      // tubafrenzy decommission (WXYC/wiki#88) unscheduled that job, so this
      // write is now the ONLY thing that ever closes a webhook-originated
      // show. Two consequences worth keeping in mind before touching it:
      //   - The guess is load-bearing, not provisional. Nothing refines it.
      //   - If this `show_end` delivery is dropped (tubafrenzy restart, 500,
      //     network), `end_time` stays NULL indefinitely rather than for at
      //     most one ETL cycle. BS#1861 (b)'s independent guard is what keeps
      //     that from silently mis-joining the next DJ.
      //
      // BS#2065 closes the loop on that second consequence without weakening
      // anything here. A dropped delivery is now (1) detected — the daily
      // stale-open-show report in `jobs/legacy-mirror-reconcile` lists shows
      // held open past a plausible duration; (2) opportunistically closed on
      // the next go-live, by `closeShowFromTerminalShowEndMarker` under the
      // (b) guard, from the marker row's own `add_time` so the value matches
      // what this fast-path would have written; and (3) repaired in bulk from
      // the final tubafrenzy `mysqldump` under #1543 item 3. None of those is
      // a scheduled job re-deriving the value from tubafrenzy — there is no
      // such job any more, and there will not be one before Phase 6a.
      //
      // `WHERE end_time IS NULL` is the data-safety guard (mirrors #1371's
      // dj_name-at-write-time precedent on these same marker rows): never
      // rewrite a value an earlier delivery of this same `show_end` — or a
      // deliberate one-shot ETL run — already repaired.
      //
      // BS#2143: `markerTimestamp` is bounded (see its computation above)
      // before it ever reaches here, so this fast-path's `end_time` inherits
      // the same future-timestamp clamp as `add_time` for free — a future
      // `shows.end_time` would otherwise be a SECOND permanently-poisoned
      // column, since both this write and `closeShowFromTerminalShowEndMarker`
      // (flowsheet.service.ts) only ever fire under `WHERE end_time IS NULL`,
      // so nothing downstream ever corrects a bad value once it lands.
      if (entryType === 'show_end' && showId !== null) {
        await db
          .update(shows)
          .set({ end_time: markerTimestamp })
          .where(and(eq(shows.id, showId), isNull(shows.end_time)));
      }

      // Sibling-marker heal (BS#1444 — residual of BS#1371).
      //
      // The conflict path above only heals the SAME `legacy_entry_id`, but a
      // `show_start` is the FIRST entry of a show, so when it arrives
      // `resolveShow` has only just created the stub `shows` row — no
      // `legacy_dj_name` yet — and the marker lands with dj_name=NULL (see the
      // `ResolvedShow.dj_name` docstring). Tubafrenzy never re-delivers that
      // create event, the flowsheet ETL's resolveDjNames only re-resolves ids
      // it bulk-fetched (and since WXYC/wiki#88 Phase 3 it is not scheduled at
      // all), and `flowsheet-dj-name-backfill` is one-shot — so nothing ever
      // fills the show_start once `shows.legacy_dj_name` lands.
      // Net effect: every new tubafrenzy show renders a nameless "signed on"
      // on the v2 wire until sign-off.
      //
      // Fix: whenever a delivery for the show resolves a non-null name, backfill
      // the show's still-NULL marker rows. A live show's show_start heals at the
      // next entry for the show — track add, edit, or sign-off — once the name
      // lands. Healing on ANY delivery (not just fresh inserts) matters for the
      // short-show case: a show whose start AND end both land before the name
      // does would otherwise never heal, since the ETL's resolveDjNames skips
      // webhook-inserted rows (they arrive as updates, not inserts) and no
      // longer runs on a schedule anyway — a later edit is then the only
      // delivery that can fill them. Scoped to
      // `MARKER_ENTRY_TYPES` + `dj_name IS NULL`, so track rows (own population
      // path) and already-resolved markers are never touched.
      //
      // Probe-before-write — a bare UPDATE that matches zero rows still fires the
      // STATEMENT-level `flowsheet_watermark` trigger (migration 0084),
      // ratcheting the conditional-GET watermark +1s and thrashing iOS/dj-site
      // pollers (the very churn BS#902/Epic F's watermark exists to prevent). A
      // SELECT fires no trigger, so we read first and issue the watermark-
      // touching UPDATE only when a marker is actually unhealed — at most once
      // per show, after which every later delivery pays only the read. Both
      // queries are index-backed by `flowsheet_show_id_idx`. (Two deliveries
      // for the same show can still race between probe and UPDATE and fire one
      // bounded spurious bump before the marker is healed; correctness is
      // unaffected — the UPDATE re-checks `dj_name IS NULL`.)
      if (resolvedShowName !== null && showId !== null) {
        const unhealedMarkerWhere = and(
          eq(flowsheet.show_id, showId),
          isNull(flowsheet.dj_name),
          inArray(flowsheet.entry_type, MARKER_ENTRY_TYPE_LIST)
        );
        const [unhealedMarker] = await db
          .select({ id: flowsheet.id })
          .from(flowsheet)
          .where(unhealedMarkerWhere)
          .limit(1);
        if (unhealedMarker) {
          await db.update(flowsheet).set({ dj_name: resolvedShowName }).where(unhealedMarkerWhere);
        }
      }
    }

    serverEventsMgr.broadcast(Topics.liveFs, {
      type: FsEvents.refetch,
      payload: { source: 'webhook' },
    });

    res.json({ ok: true });
  } catch (e) {
    console.error('[webhook] Flowsheet webhook error:', e);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// ---- Rotation Endpoints ----

/**
 * POST /internal/rotation-sync-notify
 *
 * Called by the rotation ETL after importing new or updated rotation releases
 * from tubafrenzy. Broadcasts a refetch event so dj-site UIs stay in sync.
 */
internal_route.post('/rotation-sync-notify', (req, res) => {
  if (!authenticateInternal(req.get('X-Internal-Key'))) {
    res.status(401).json({ error: 'Unauthorized' });
    return;
  }

  serverEventsMgr.broadcast(Topics.liveFs, {
    type: FsEvents.refetch,
    payload: { source: 'rotation-etl' },
  });

  res.json({ ok: true });
});

/**
 * POST /internal/artist-identity-sync-notify
 *
 * Called by the artist-identity ETL after copying reconciled external IDs
 * from LML's `entity.identity` table. No SSE consumer exists today (the
 * library views are read-on-demand), so this handler exists only to keep
 * the polling-mode notify call from logging 404s. It still authenticates
 * so a future SSE topic can be added without changing the contract.
 */
internal_route.post('/artist-identity-sync-notify', (req, res) => {
  if (!authenticateInternal(req.get('X-Internal-Key'))) {
    res.status(401).json({ error: 'Unauthorized' });
    return;
  }

  res.json({ ok: true });
});

const VALID_ROTATION_ACTIONS = new Set(['create', 'update', 'kill', 'unkill']);

/**
 * Resolve a Backend-Service album_id from a tubafrenzy LIBRARY_RELEASE_ID.
 * Returns null if the library release ID is 0 or not found.
 *
 * Thin wrapper over `library.service.getAlbumIdByLegacyId` — the legacy→serial
 * bridge now lives in one place (BS#1880). Kept so the inbound call sites below
 * read unchanged.
 */
function resolveAlbumId(legacyLibraryReleaseId: number): Promise<number | null> {
  return getAlbumIdByLegacyId(legacyLibraryReleaseId);
}

/**
 * Resolve a Backend-Service rotation_id from a tubafrenzy ROTATION_RELEASE_ID
 * (the `entry.rotationReleaseId` field on the flowsheet webhook payload, set
 * by tubafrenzy's `FlowsheetEntryAddServlet.populateRotationRelease()`).
 * Returns null if the legacy id is 0 / unset or no rotation row matches.
 *
 * Single indexed SELECT via `rotation_legacy_rotation_id_idx` (unique by the
 * tubafrenzy invariant — one rotation row per legacy_rotation_id). BS#1268.
 */
async function resolveRotationId(legacyRotationId: number): Promise<number | null> {
  if (!legacyRotationId) return null;

  const [row] = await db
    .select({ id: rotation.id })
    .from(rotation)
    .where(eq(rotation.legacy_rotation_id, legacyRotationId))
    .limit(1);
  return row?.id ?? null;
}

/**
 * POST /internal/rotation-webhook
 *
 * Receives rotation release events from tubafrenzy. Called by tubafrenzy's
 * WebhookRotationReleaseListener when releases are added, updated, killed, or unkilled.
 *
 * Payload:
 *   { action: "create"|"update", release: { id, artistName, albumTitle, rotationType, labelName, addDate, killDate, libraryReleaseId } }
 *   { action: "kill", release: { id, killDate } }
 *   { action: "unkill", releaseId: number }
 */
internal_route.post('/rotation-webhook', async (req, res) => {
  if (!authenticateInternal(req.get('X-Internal-Key'))) {
    res.status(401).json({ error: 'Unauthorized' });
    return;
  }

  const { action, release, releaseId } = req.body ?? {};

  if (!action || !VALID_ROTATION_ACTIONS.has(action)) {
    res.status(400).json({ error: 'Missing or invalid action. Expected: create, update, kill, or unkill.' });
    return;
  }

  try {
    if (action === 'unkill') {
      if (typeof releaseId !== 'number') {
        res.status(400).json({ error: 'Missing releaseId for unkill action.' });
        return;
      }
      await db.update(rotation).set({ kill_date: null }).where(eq(rotation.legacy_rotation_id, releaseId));
    } else if (action === 'kill') {
      if (!release || typeof release.id !== 'number') {
        res.status(400).json({ error: 'Missing release.id for kill action.' });
        return;
      }
      const killDate =
        release.killDate && release.killDate !== 0
          ? new Date(release.killDate).toISOString().split('T')[0]
          : new Date().toISOString().split('T')[0];
      await db.update(rotation).set({ kill_date: killDate }).where(eq(rotation.legacy_rotation_id, release.id));
    } else {
      // create or update — both use upsert
      if (!release || typeof release.id !== 'number') {
        res.status(400).json({ error: 'Missing release.id for create/update action.' });
        return;
      }

      // BS#2173: what `'N'` actually became was this line's fallback — the
      // value written whenever a payload carried no usable bin. `rotation_bin`
      // is NOT NULL, so a bin-less payload cannot materialize a row, and that
      // constraint is what pushed the original code into inventing one. The
      // cost is on the record: BS#1082's incident was partial updates flipping
      // live Heavy rows to 'N' until the rotation-etl tick repaired them, and
      // the value leaked outward from here into the catalog export, api.yaml,
      // and the iOS clone as a bin clients had to special-case.
      //
      // Split the two ways a bin goes missing instead of papering over both:
      // a payload carrying NO bin is the documented linkage-only partial update
      // (BS#1082/#1312), which updates in place and never inserts, while a bin
      // that is present but unrecognized is bad data (400 below).
      //
      // "No bin" has THREE wire forms, not one. tubafrenzy's
      // `BackendServiceWebhookClient.buildRotationPayload` serializes a null
      // ROTATION_TYPE as the empty string rather than omitting the key:
      //
      //     releaseJson.put("rotationType", release.getRotationType() != null
      //             ? release.getRotationType() : "");
      //
      // so `""` means "this release has no bin upstream", NOT "bad data" — and
      // it is the form that actually occurs. Rejecting it would drop the whole
      // event: an MD editing one of those releases would get a 400 and the kill
      // date would never land, with only a `logger.warn` upstream to show for
      // it. `parseRotationBin` collapses absent / null / blank to `missing`.
      const parsedBin = parseRotationBin(release.rotationType);
      if (parsedBin.kind === 'invalid') {
        res.status(400).json({
          error: `Invalid rotationType ${JSON.stringify(parsedBin.raw)}. Expected one of: ${ROTATION_BINS.join(', ')}.`,
        });
        return;
      }

      const rawLibraryId = release.libraryReleaseId ?? 0;
      // Resolved once, here, against whatever `library` holds at delivery time.
      // The librarian routinely files the physical release AFTER the MD bins
      // it, so this frequently returns null and the row keeps its denormalized
      // artist/album/label instead. `jobs/legacy-linkage-resolve/` re-runs the
      // join on a schedule and is the only thing that later links such a row
      // (and clears the denormalized columns) — it was a tail pass inside
      // rotation-etl until WXYC/wiki#88 Phase 3 unscheduled that job.
      const albumId = await resolveAlbumId(rawLibraryId);
      const addDate =
        release.addDate && release.addDate !== 0
          ? new Date(release.addDate).toISOString().split('T')[0]
          : new Date().toISOString().split('T')[0];
      const killDate =
        release.killDate && release.killDate !== 0 ? new Date(release.killDate).toISOString().split('T')[0] : null;

      if (parsedBin.kind === 'missing') {
        // BS#1082 + BS#1312: tubafrenzy's sendRotationLinked posts only {id,
        // libraryReleaseId, action: 'update'} on linkage. Those payloads carry
        // no bin, so there is nothing to INSERT — this arm updates the existing
        // row and stops. Presence-gating still applies to the fields the
        // payload may or may not carry, so a linkage event can't clobber the
        // row's kill_date or its denormalized artist/album/label snapshot with
        // the JS defaults computed above.
        //
        // BS#2173: this arm used to be the ON CONFLICT half of an upsert whose
        // INSERT half supplied the fictional 'N' for the NOT NULL bin. Gating
        // SET protected a row that already existed, but a payload naming a
        // release BS had never seen fell through to that INSERT and created a
        // phantom in-rotation row. Reaching that state now reports 404 rather
        // than inventing a bin.
        //
        // Be clear about what that costs, because the obvious reassurance is
        // wrong: rotation-etl is NOT a live repair path. It is a one-shot job,
        // unregistered from the deploy crontab, refusing to run without
        // LEGACY_ETL_ALLOW_BACKWARDS_WRITE=1, and documented as a backwards
        // write that reverts Backend-side edits. So a 404 here means the
        // linkage is dropped, not deferred — the caller only logs the status.
        // That is still better than the alternative it replaces, which was a
        // permanent phantom rotation row visible in the catalog export and
        // every client; a missing linkage is recoverable by hand, a fabricated
        // bin is invisible. If these start appearing, the fix is upstream: give
        // the release a real bin in tubafrenzy.
        //
        // BS#2109: tubafrenzy only asserts a link when it sends a
        // `libraryReleaseId`. When it doesn't (0/absent — it simply doesn't
        // know), leave `album_id` alone so a Backend-made link (`PATCH
        // /library/rotation/:id/link`) isn't downgraded to NULL; presence-gating
        // the key is how every other column here already expresses that. When
        // it does, write the resolved `albumId` outright — even null, since an
        // unresolved id is still tubafrenzy asserting a relink.
        const partialSet: Record<string, unknown> = {
          legacy_library_release_id: rawLibraryId || null,
        };
        if (rawLibraryId) {
          partialSet.album_id = albumId;
        }
        if (release.killDate !== undefined) {
          partialSet.kill_date = killDate;
        }
        if (release.artistName !== undefined) {
          partialSet.artist_name = albumId ? null : truncate(release.artistName, 128);
        }
        if (release.albumTitle !== undefined) {
          partialSet.album_title = albumId ? null : truncate(release.albumTitle, 128);
        }
        if (release.labelName !== undefined) {
          partialSet.record_label = albumId ? null : truncate(release.labelName, 128);
        }

        const updated = await db
          .update(rotation)
          .set(partialSet)
          .where(eq(rotation.legacy_rotation_id, release.id))
          .returning({ id: rotation.id });

        if (updated.length === 0) {
          res.status(404).json({
            error: `Unknown rotation release ${release.id}: cannot create a rotation row without a rotationType.`,
          });
          return;
        }
      } else {
        // A real bin is present, so the row can be created outright. Every SET
        // key here is presence-gated — a full-shape update overwrites, a
        // sparser one leaves alone — while the INSERT arm populates every
        // column on first delivery. `album_id` is gated on the same rule as
        // the plain-UPDATE arm above: tubafrenzy asserting a `libraryReleaseId`
        // means write it (a create, or a genuine `/wxycdb` relink to a
        // *different* release); tubafrenzy not knowing means leave the column
        // alone, so a `PATCH /library/rotation/:id/link` survives.
        //
        // The three snapshot columns write `excluded.*` gated only on
        // presence, same as every other column — this arm never re-decides the
        // trio based on whether the row resolves linked. Note that the value
        // it writes still can be NULL: the `.values()` below compute
        // `albumId ? null : truncate(...)`, so a delivery carrying a
        // *resolvable* `libraryReleaseId` nulls the trio. That is pre-existing
        // behavior, deliberately unchanged here; the case this arm protects is
        // the `libraryReleaseId: 0` delivery landing on a Backend-linked row,
        // where `albumId` is null and the free text is written through.
        //
        // Why the trio is worth keeping wherever it survives:
        //   (a) `linkRotationToAlbum` (`apps/backend/services/library.service.ts`)
        //       deliberately leaves a freshly-linked row's trio populated —
        //       nulling it broke the tracklist picker's tier-3 self-heal,
        //       which needs artist + title non-NULL to attempt a lookup.
        //   (b) `jobs/rotation-release-id-backfill`'s candidate query
        //       (`query.ts`) requires `artist_name IS NOT NULL AND
        //       album_title IS NOT NULL` to repair `discogs_release_id`, and
        //       also excludes killed rows — so a killed+linked row with a
        //       nulled trio has no repair path at all.
        //   (c) It costs nothing display-side: `getRotationFromDB` selects
        //       `COALESCE(artists.artist_name, rotation.artist_name)` (and the
        //       album/label siblings), so a linked row always reads the
        //       canonical `library`/`artists` value regardless.
        const setClause: Record<string, unknown> = {
          legacy_library_release_id: sql`excluded.legacy_library_release_id`,
          rotation_bin: sql`excluded.rotation_bin`,
        };
        if (rawLibraryId) {
          setClause.album_id = sql`excluded.album_id`;
        }
        if (release.killDate !== undefined) {
          setClause.kill_date = sql`excluded.kill_date`;
        }
        if (release.artistName !== undefined) {
          setClause.artist_name = sql`excluded.artist_name`;
        }
        if (release.albumTitle !== undefined) {
          setClause.album_title = sql`excluded.album_title`;
        }
        if (release.labelName !== undefined) {
          setClause.record_label = sql`excluded.record_label`;
        }

        await db
          .insert(rotation)
          .values({
            legacy_rotation_id: release.id,
            legacy_library_release_id: rawLibraryId || null,
            album_id: albumId,
            rotation_bin: parsedBin.bin,
            add_date: addDate,
            kill_date: killDate,
            artist_name: albumId ? null : truncate(release.artistName, 128),
            album_title: albumId ? null : truncate(release.albumTitle, 128),
            record_label: albumId ? null : truncate(release.labelName, 128),
          })
          .onConflictDoUpdate({
            target: rotation.legacy_rotation_id,
            set: setClause,
          });
      }
    }

    serverEventsMgr.broadcast(Topics.liveFs, {
      type: FsEvents.refetch,
      payload: { source: 'rotation-webhook' },
    });

    res.json({ ok: true });
  } catch (e) {
    console.error('[webhook] Rotation webhook error:', e);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// ---- Streaming Status Webhook ----

/**
 * Authenticate via Authorization: Bearer token (used by LML streaming webhook).
 * Separate from authenticateInternal which uses X-Internal-Key.
 */
function authenticateBearer(authHeader: string | undefined): boolean {
  if (!ETL_NOTIFY_KEY || !authHeader) return false;
  const match = authHeader.match(/^Bearer\s+(.+)$/i);
  return !!match && match[1] === ETL_NOTIFY_KEY;
}

interface StreamingChange {
  library_release_id: number;
  on_streaming: boolean | null;
}

/**
 * POST /internal/streaming-status-webhook
 *
 * Receives bulk ON_STREAMING updates from LML after each library.db upload.
 * Updates the `on_streaming` column in the `library` table for each change.
 *
 * Auth: Authorization: Bearer <ETL_NOTIFY_KEY>
 *
 * Payload:
 *   { changes: [{ library_release_id: number, on_streaming: boolean | null }], timestamp: string }
 */
internal_route.post('/streaming-status-webhook', async (req, res) => {
  if (!authenticateBearer(req.get('Authorization'))) {
    res.status(401).json({ error: 'Unauthorized' });
    return;
  }

  const { changes } = req.body ?? {};

  if (!Array.isArray(changes)) {
    res.status(400).json({ error: 'Missing or invalid field: changes (expected array)' });
    return;
  }

  let processed = 0;
  const failures: { library_release_id: number; error: string }[] = [];

  // Per-row autocommit (BS#1114). Each UPDATE runs as its own independent
  // statement rather than inside one shared `db.transaction`. The old shape wrapped
  // the whole loop in a single transaction with a per-row catch: when one row
  // raised, Postgres aborted the surrounding transaction, and every later
  // `tx.update(...)` threw `current transaction is aborted, commands ignored until
  // end of transaction block`. The per-row catch swallowed all of them into a
  // meaningless `errors` count while the first row's real error was lost. Without
  // the wrapper a bad row fails in isolation, the surviving rows still commit, and
  // the failing row's actual error is surfaced in the response (and to Sentry)
  // below. These updates are idempotent column writes, so there is no cross-row
  // invariant that needs the atomicity a shared transaction would give.
  for (const change of changes as StreamingChange[]) {
    const legacyId = change.library_release_id;
    try {
      const onStreaming = change.on_streaming ?? null;

      await db.update(library).set({ on_streaming: onStreaming }).where(eq(library.legacy_release_id, legacyId));

      processed++;
    } catch (e) {
      const message = e instanceof Error ? e.message : String(e);
      console.error(`[webhook] Streaming status update error (library_release_id=${legacyId}):`, e);
      failures.push({ library_release_id: legacyId, error: message });
    }
  }

  if (failures.length > 0) {
    Sentry.captureMessage(`[webhook] streaming-status: ${failures.length}/${changes.length} row update(s) failed`, {
      level: 'warning',
      extra: { failures: failures.slice(0, 20) },
    });
  }

  res.json({ processed, errors: failures.length, failures });
});
