/**
 * Empty-outcome classification for enrichment-worker Sentry observability
 * (BS#969 / Epic G G7).
 *
 * The legacy `Sentry.captureException` path in `apps/backend/services/metadata`
 * only fires when `lookupMetadata` throws — it catches LML timeouts but misses
 * the dominant failure mode: LML responds inside its budget with a degraded
 * result (artwork object present but `artwork_url` null, the LML#408 class).
 * The 2026-05-19 data pull on BS#692 quantified the gap at ~50–500× undercount
 * against the actual prod degradation rate.
 *
 * This module exports a pure predicate + cause classifier. The handler in
 * handler.ts uses both to decide whether to fire a structured
 * `Sentry.captureMessage('enrichment-empty-outcome', ...)` on an empty
 * outcome, with a stable fingerprint that survives release tag changes.
 *
 * "Empty outcome" is defined against the LML response, not the post-write
 * row state: the worker's write path always synthesizes fallback search URLs
 * (spotify/youtube/bandcamp/soundcloud), so the BS#969-original "all five row
 * columns IS NULL" predicate would never trigger after consumer writes. The
 * user-facing definition that matters is "no Discogs-derived artwork URL" —
 * that's what shows up as a blank cover tile on iOS / dj-site.
 *
 * Volume-control note (BS#1311): the call-site captureMessage in handler.ts
 * fires only on `lml_degraded` outcomes this worker actually wrote. The
 * `lml_no_match` cause is by-design Discogs miss (not a degradation) and is
 * suppressed at the call site; `lml_timeout` lives on the catch arm and was
 * dropped entirely (captureException there is the source of truth). The
 * classifier here still returns `lml_no_match` so dashboard aggregation off
 * the span attribute can split the classes; suppression is the caller's
 * decision, not this module's.
 */

import type { LookupResponse } from '@wxyc/lml-client';

import { extractArtwork } from './enrich.js';

export type EmptyOutcomeCause = 'lml_degraded' | 'lml_no_match' | 'lml_timeout' | 'unknown';

/**
 * True if the LML response will produce a user-visibly blank artwork tile:
 * either no Discogs match at all (artwork === null) or a match whose
 * `artwork_url` is missing (the LML#408 `_resolve_fallback_artwork` class).
 *
 * `requestedAlbum` must be the SAME value `finalizeRow` passed to
 * `extractArtwork` (BS#2217 review). This function's whole job is to describe
 * the write `finalizeRow` just made, and both share that one chokepoint — ask
 * it a different question and the two disagree. Concretely, once the BS#2217
 * correspondence carve-out can accept a row-less `alternative` match, omitting
 * the album here makes a blank-cover match classify as `lml_no_match` (which
 * `SUPPRESSED_EMPTY_CAUSES` drops) even though `finalizeRow` wrote
 * `enriched_match`. That row is then invisible to this alert AND to
 * `flowsheet-no-match-recheck`, which only re-asks `enriched_no_match` —
 * nothing revisits it. Passing the album classifies it `lml_degraded` and the
 * alert fires. Omitting it remains valid for a caller with no request context;
 * the carve-out simply stays inactive.
 *
 * Does NOT cover the LML-threw path; the caller in handler.ts fires the
 * `lml_timeout` cause separately from its catch arm.
 */
export const isEmptyOutcome = (response: LookupResponse, requestedAlbum?: string | null): boolean => {
  const artwork = extractArtwork(response, requestedAlbum);
  if (!artwork) return true;
  return !artwork.artwork_url;
};

/**
 * Classify an empty-outcome response into the cause tag that distinguishes
 * LML-side failure modes on the aggregated Sentry issue. Caller should only
 * invoke this when `isEmptyOutcome(response)` is true.
 *
 * The `lml_timeout` cause is unreachable from this function (the LML throw
 * path lives in handler.ts's catch arm); it exists in `EmptyOutcomeCause`
 * because the catch arm uses it as a tag value on its own captureMessage.
 */
export const classifyEmptyCause = (
  response: LookupResponse,
  requestedAlbum?: string | null
): Exclude<EmptyOutcomeCause, 'lml_timeout'> => {
  const artwork = extractArtwork(response, requestedAlbum);
  if (!artwork) return 'lml_no_match';
  if (!artwork.artwork_url) return 'lml_degraded';
  return 'unknown';
};

/**
 * Stable Sentry fingerprint so all four `cause` classifications group onto
 * a single long-lived issue that survives release tag changes. Tag-filter
 * within Sentry to split causes when triaging.
 */
export const EMPTY_OUTCOME_FINGERPRINT = ['enrichment-empty-outcome', 'subsystem-metadata'];
