import { Request, RequestHandler } from 'express';
import * as ScheduleService from '../services/schedule.service.js';
import { NewShift } from '@wxyc/database';

export const getSchedule: RequestHandler<object, unknown, object, object> = async (req, res) => {
  const schedule = await ScheduleService.getSchedule();
  res.status(200).json(schedule);
};

export const addToSchedule: RequestHandler = async (req: Request<object, object, NewShift>, res) => {
  const { body } = req;
  const response = await ScheduleService.addToSchedule(body);
  res.status(201).json(response);
};

/* TODO: stubbed out schedule controller logic
export const removeFromSchedule: RequestHandler<object, unknown, object, { show_id: number }> = async (req, res, next) => {
    if (req.query.show_id === undefined) {
        console.error('Bad Request, Missing Show Identifier: show_id');
        res.status(400).send('Bad Request, Missing Show Identifier: show_id');
    } else {
        try {
        const removed_show = await ScheduleService.removeFromSchedule(req.query.show_id);
        res.status(200).json(removed_show);
        } catch (e) {
        console.error(e);
        next(e);
        }
    }
};

export const addToSchedule: RequestHandler<object, unknown, object, { show_id: number }> = async (req, res, next) => {
    if (req.query.show_id === undefined) {
        console.error('Bad Request, Missing Show Identifier: show_id');
        res.status(400).send('Bad Request, Missing Show Identifier: show_id');
    } else {
        try {
        const added_show = await ScheduleService.addToSchedule(req.query.show_id);
        res.status(200).json(added_show);
        } catch (e) {
        console.error(e);
        next(e);
        }
    }
};

export const updateSchedule: RequestHandler<object, unknown, object, { show_id: number, start_time: string, end_time: string }> = async (req, res, next) => {
    if (req.query.show_id === undefined) {
        console.error('Bad Request, Missing Show Identifier: show_id');
        res.status(400).send('Bad Request, Missing Show Identifier: show_id');
    } else {
        try {
        const updated_show = await ScheduleService.updateSchedule(req.query.show_id, req.query.start_time, req.query.end_time);
        res.status(200).json(updated_show);
        } catch (e) {
        console.error(e);
        next(e);
        }
    }
};
*/
