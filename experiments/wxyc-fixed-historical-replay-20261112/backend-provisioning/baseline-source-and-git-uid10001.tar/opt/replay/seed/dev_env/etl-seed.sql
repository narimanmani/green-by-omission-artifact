-- =============================================================================
-- ETL E2E Test Seed Data
-- Creates tubafrenzy production table schemas and populates with test data
-- for end-to-end testing of the library and flowsheet ETL jobs.
--
-- Artist/album data is representative of what WXYC actually plays.
-- =============================================================================

-- ---- Library Tables ----

CREATE TABLE IF NOT EXISTS GENRE (
  ID int NOT NULL AUTO_INCREMENT,
  REFERENCE_NAME varchar(100) DEFAULT NULL,
  PRIMARY KEY (ID)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS FORMAT (
  ID int NOT NULL AUTO_INCREMENT,
  REFERENCE_NAME varchar(100) DEFAULT NULL,
  PRIMARY KEY (ID)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS LIBRARY_CODE (
  ID int NOT NULL AUTO_INCREMENT,
  PRESENTATION_NAME varchar(255) DEFAULT NULL,
  ALPHABETICAL_NAME varchar(255) DEFAULT NULL,
  CALL_LETTERS varchar(10) DEFAULT NULL,
  CALL_NUMBERS int DEFAULT NULL,
  GENRE_ID int NOT NULL,
  PRIMARY KEY (ID)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS LIBRARY_RELEASE (
  ID int NOT NULL AUTO_INCREMENT,
  TITLE varchar(255) DEFAULT NULL,
  LIBRARY_CODE_ID int NOT NULL,
  FORMAT_ID int NOT NULL,
  CALL_NUMBERS int DEFAULT NULL,
  CALL_LETTERS varchar(10) DEFAULT NULL,
  ALTERNATE_ARTIST_NAME varchar(255) DEFAULT NULL,
  TIME_LAST_MODIFIED bigint DEFAULT NULL,
  TIME_CREATED bigint DEFAULT NULL,
  DATE_LOST bigint DEFAULT NULL,
  DATE_FOUND bigint DEFAULT NULL,
  PRIMARY KEY (ID)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS LIBRARY_CODE_CROSS_REFERENCE (
  ID int NOT NULL AUTO_INCREMENT,
  CROSS_REFERENCING_ARTIST_ID int NOT NULL,
  CROSS_REFERENCED_LIBRARY_CODE_ID int NOT NULL,
  COMMENT varchar(100) DEFAULT NULL,
  TIME_LAST_MODIFIED bigint DEFAULT NULL,
  TIME_CREATED bigint DEFAULT NULL,
  PRIMARY KEY (ID)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS RELEASE_CROSS_REFERENCE (
  ID int NOT NULL AUTO_INCREMENT,
  CROSS_REFERENCING_ARTIST_ID int NOT NULL,
  CROSS_REFERENCED_RELEASE_ID int NOT NULL,
  COMMENT varchar(100) DEFAULT NULL,
  TIME_LAST_MODIFIED bigint DEFAULT NULL,
  TIME_CREATED bigint DEFAULT NULL,
  PRIMARY KEY (ID)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS COMPILATION_TRACK_ARTIST (
  LIBRARY_RELEASE_ID int NOT NULL,
  ARTIST_NAME varchar(255) NOT NULL,
  TRACK_TITLE varchar(255) DEFAULT NULL,
  TRACK_POSITION varchar(20) DEFAULT NULL,
  INDEX idx_cta_release (LIBRARY_RELEASE_ID),
  INDEX idx_cta_artist (ARTIST_NAME)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ---- Flowsheet Tables ----

CREATE TABLE IF NOT EXISTS FLOWSHEET_RADIO_SHOW_PROD (
  ID int NOT NULL AUTO_INCREMENT,
  STARTING_RADIO_HOUR bigint NOT NULL DEFAULT 0,
  DJ_NAME varchar(255) DEFAULT NULL,
  DJ_ID int DEFAULT NULL,
  DJ_HANDLE varchar(255) DEFAULT NULL,
  SHOW_NAME varchar(255) DEFAULT NULL,
  SPECIALTY_SHOW_ID int DEFAULT NULL,
  WORKING_HOUR bigint NOT NULL DEFAULT 0,
  SIGNON_TIME bigint DEFAULT NULL,
  SIGNOFF_TIME bigint DEFAULT NULL,
  TIME_LAST_MODIFIED bigint DEFAULT NULL,
  TIME_CREATED bigint DEFAULT NULL,
  MODLOCK int DEFAULT NULL,
  SHOW_ID int DEFAULT NULL,
  PRIMARY KEY (ID)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

CREATE TABLE IF NOT EXISTS FLOWSHEET_ENTRY_PROD (
  ID int NOT NULL AUTO_INCREMENT,
  ARTIST_NAME varchar(255) DEFAULT NULL,
  ARTIST_ID int DEFAULT NULL,
  SONG_TITLE varchar(255) DEFAULT NULL,
  RELEASE_TITLE varchar(255) DEFAULT NULL,
  RELEASE_FORMAT_ID int DEFAULT NULL,
  LIBRARY_RELEASE_ID int DEFAULT NULL,
  ROTATION_RELEASE_ID int DEFAULT NULL,
  LABEL_NAME varchar(255) DEFAULT NULL,
  RADIO_HOUR bigint DEFAULT NULL,
  START_TIME bigint DEFAULT NULL,
  STOP_TIME bigint DEFAULT NULL,
  RADIO_SHOW_ID int DEFAULT NULL,
  SEQUENCE_WITHIN_SHOW int DEFAULT NULL,
  NOW_PLAYING_FLAG int DEFAULT NULL,
  FLOWSHEET_ENTRY_TYPE_CODE_ID int DEFAULT NULL,
  TIME_LAST_MODIFIED bigint DEFAULT NULL,
  TIME_CREATED bigint DEFAULT NULL,
  REQUEST_FLAG int DEFAULT NULL,
  GLOBAL_ORDER_ID bigint DEFAULT NULL,
  BMI_COMPOSER varchar(255) DEFAULT NULL,
  SEGUE_FLAG int NOT NULL DEFAULT 0,
  PRIMARY KEY (ID)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- =============================================================================
-- Seed Data
-- =============================================================================

-- ---- Genres ----
INSERT INTO GENRE (ID, REFERENCE_NAME) VALUES
  (1, 'Rock'), (2, 'Electronic'), (3, 'Jazz'), (4, 'Hiphop'),
  (5, 'Reggae'), (6, 'Latin'), (7, 'db_only');

-- ---- Formats ----
INSERT INTO FORMAT (ID, REFERENCE_NAME) VALUES
  (1, 'CD'), (2, 'Vinyl 12"'), (3, 'Vinyl 7"'), (4, 'CDR');

-- ---- Artists (LIBRARY_CODE) ----
INSERT INTO LIBRARY_CODE (ID, PRESENTATION_NAME, ALPHABETICAL_NAME, CALL_LETTERS, CALL_NUMBERS, GENRE_ID) VALUES
  (1, 'Autechre', 'Autechre', 'AU', 5, 2),
  (2, 'Cat Power', 'Cat Power', 'CA', 12, 1),
  (3, 'Jessica Pratt', 'Pratt, Jessica', 'PR', 8, 1),
  (4, 'Chuquimamani-Condori', 'Chuquimamani-Condori', 'CH', 3, 2),
  (5, 'Duke Ellington & John Coltrane', 'Ellington, Duke & John Coltrane', 'EL', 1, 3),
  (6, 'Various Artists', NULL, 'V/A', 0, 1),
  (7, 'Large Professor', 'Large Professor', 'LA', 2, 4);

-- ---- Releases ----
INSERT INTO LIBRARY_RELEASE (ID, TITLE, LIBRARY_CODE_ID, FORMAT_ID, CALL_NUMBERS, CALL_LETTERS, ALTERNATE_ARTIST_NAME, TIME_LAST_MODIFIED, TIME_CREATED, DATE_LOST, DATE_FOUND) VALUES
  (101, 'Confield', 1, 1, 5, NULL, NULL, 1775000000000, 1700000000000, NULL, NULL),
  (102, 'Moon Pix', 2, 1, 12, NULL, NULL, 1775000000000, 1700000000000, NULL, NULL),
  (103, 'On Your Own Love Again', 3, 2, 8, 'A', NULL, 1775000000000, 1700000000000, NULL, NULL),
  (104, 'Edits', 4, 1, 3, NULL, NULL, 1775000000000, 1700000000000, NULL, NULL),
  (105, 'Duke Ellington & John Coltrane', 5, 2, 1, NULL, NULL, 1775000000000, 1700000000000, NULL, NULL),
  -- Missing release (date_lost set, not found)
  (106, 'Dada Damage: A Night People Compilation', 6, 2, 0, NULL, NULL, 1775100000000, 1700000000000, 1775050000000, NULL),
  -- Found after being lost
  (107, '1st Class', 7, 1, 2, NULL, NULL, 1775100000000, 1700000000000, 1775020000000, 1775080000000),
  -- db_only genre (should be skipped)
  (108, 'Internal Only', 1, 1, 99, NULL, NULL, 1775000000000, 1700000000000, NULL, NULL);

-- Override the artist for release 108 to use db_only genre
UPDATE LIBRARY_RELEASE SET LIBRARY_CODE_ID = 1 WHERE ID = 108;
-- Actually need a library_code entry with db_only genre
INSERT INTO LIBRARY_CODE (ID, PRESENTATION_NAME, ALPHABETICAL_NAME, CALL_LETTERS, CALL_NUMBERS, GENRE_ID) VALUES
  (8, 'Internal Artist', 'Internal Artist', 'IN', 1, 7);
UPDATE LIBRARY_RELEASE SET LIBRARY_CODE_ID = 8 WHERE ID = 108;

-- ---- Compilation Track Artists ----
INSERT INTO COMPILATION_TRACK_ARTIST (LIBRARY_RELEASE_ID, ARTIST_NAME, TRACK_TITLE, TRACK_POSITION) VALUES
  (106, 'Sharp Pins', 'You Turned off the Light', 'A1'),
  (106, 'Scott and Charlene''s Wedding', 'Footscray Station', 'A2'),
  (106, 'Naked on the Vague', 'Left Behind', 'B1');

-- Case-variant artist (same artist as ID=1 but uppercase name)
INSERT INTO LIBRARY_CODE (ID, PRESENTATION_NAME, ALPHABETICAL_NAME, CALL_LETTERS, CALL_NUMBERS, GENRE_ID) VALUES
  (10, 'AUTECHRE', 'Autechre', 'AU', 5, 2);

-- ---- Artist Cross-References ----
-- ID=1 uses the case-variant source (AUTECHRE) so it is processed FIRST by MySQL
-- (InnoDB returns rows in PK order). This ensures the case-insensitive cache
-- doesn't mask a DB-level exact-match bug in findArtistId.
INSERT INTO LIBRARY_CODE_CROSS_REFERENCE (ID, CROSS_REFERENCING_ARTIST_ID, CROSS_REFERENCED_LIBRARY_CODE_ID, COMMENT) VALUES
  (1, 10, 2, 'case test'),
  (2, 1, 4, 'see also');

-- ---- Release Cross-References ----
INSERT INTO RELEASE_CROSS_REFERENCE (ID, CROSS_REFERENCING_ARTIST_ID, CROSS_REFERENCED_RELEASE_ID, COMMENT) VALUES
  (1, 5, 105, 'featured artist');

-- ---- Shows ----
-- DJ_NAME holds the full real name in prod (BS forwards `realName || name` via
-- the legacy mirror); DJ_HANDLE holds the on-air alias. The ETL pulls
-- DJ_HANDLE into shows.legacy_dj_name (BS#1393 PII fix). Seed the columns
-- with DISTINCT values so the e2e ETL assertions act as a column-confusion
-- regression detector — if a refactor ever flips the ETL back to reading
-- DJ_NAME, `legacy_dj_name` lands the real-name value and the assertion fails.
INSERT INTO FLOWSHEET_RADIO_SHOW_PROD (ID, STARTING_RADIO_HOUR, DJ_NAME, DJ_ID, DJ_HANDLE, SHOW_NAME, SIGNON_TIME, SIGNOFF_TIME, TIME_LAST_MODIFIED, TIME_CREATED) VALUES
  (1001, 1775300400000, 'Jonathan Smith', 42, 'DJ Bluejay', 'The Nest', 1775300460000, 1775311200000, 1775311200000, 1775300460000),
  (1002, 1775311200000, 'Alice Wilde', NULL, 'dj wilde', NULL, 1775311260000, NULL, 1775311260000, 1775311260000);

-- ---- Flowsheet Entries ----
INSERT INTO FLOWSHEET_ENTRY_PROD (ID, ARTIST_NAME, ARTIST_ID, SONG_TITLE, RELEASE_TITLE, RELEASE_FORMAT_ID, LIBRARY_RELEASE_ID, ROTATION_RELEASE_ID, LABEL_NAME, RADIO_HOUR, START_TIME, STOP_TIME, RADIO_SHOW_ID, SEQUENCE_WITHIN_SHOW, NOW_PLAYING_FLAG, FLOWSHEET_ENTRY_TYPE_CODE_ID, TIME_LAST_MODIFIED, TIME_CREATED, REQUEST_FLAG, GLOBAL_ORDER_ID, BMI_COMPOSER, SEGUE_FLAG) VALUES
  -- Show start
  (2001, 'START OF SHOW: DJ Bluejay SIGNED ON at 12:01 PM (4/4/26)', 0, '', '', 0, 0, 0, '', 1775300400000, 1775300460000, 0, 1001, 1, 0, 9, 1775300460000, 1775300460000, 0, 1001001, '', 0),
  -- Track entries (type 6 = LIBRARY)
  (2002, 'Autechre', 0, 'VI Scose Poise', 'Confield', 0, 101, 0, 'Warp', 1775300400000, 1775301000000, 0, 1001, 2, 0, 6, 1775301000000, 1775301000000, 0, 1001002, '', 0),
  -- Segued track
  (2003, 'Cat Power', 0, 'American Flag', 'Moon Pix', 0, 102, 0, 'Matador Records', 1775300400000, 1775301300000, 0, 1001, 3, 0, 6, 1775301300000, 1775301300000, 0, 1001003, '', 1),
  -- Talkset
  (2004, 'TALKSET', 0, '', '', 0, 0, 0, '', 1775300400000, 1775301600000, 0, 1001, 4, 0, 7, 1775301600000, 1775301600000, 0, 1001004, '', 0),
  -- Request
  (2005, 'Jessica Pratt', 0, 'Back, Baby', 'On Your Own Love Again', 0, 103, 0, 'Drag City', 1775304000000, 1775304100000, 0, 1001, 5, 0, 6, 1775304100000, 1775304100000, 1, 1001005, '', 0),
  -- Breakpoint
  (2006, '--- 1:00 PM BREAKPOINT ---', 0, '', '', 0, 0, 0, '', 1775304000000, 1775304000000, 0, 1001, 6, 0, 8, 1775304000000, 1775304000000, 0, 1001006, '', 0),
  -- Rotation track (type 1 = HEAVY)
  (2007, 'Chuquimamani-Condori', 0, 'Call Your Name', 'Edits', 0, 104, 25099, 'self-released', 1775304000000, 1775304300000, 0, 1001, 7, 0, 1, 1775304300000, 1775304300000, 0, 1001007, '', 0),
  -- Show end
  (2008, 'END OF SHOW: DJ Bluejay SIGNED OFF at 3:00 PM (4/4/26)', 0, '', '', 0, 0, 0, '', 1775311200000, 1775311200000, 0, 1001, 8, 0, 10, 1775311200000, 1775311200000, 0, 1001008, '', 0),
  -- Second show start
  (2009, 'START OF SHOW: dj wilde SIGNED ON at 3:01 PM (4/4/26)', 0, '', '', 0, 0, 0, '', 1775311200000, 1775311260000, 0, 1002, 1, 0, 9, 1775311260000, 1775311260000, 0, 1002001, '', 0),
  -- Non-rotation track (type 0 = OTHER)
  (2010, 'Duke Ellington & John Coltrane', 0, 'In a Sentimental Mood', 'Duke Ellington & John Coltrane', 0, 105, 0, 'Impulse Records', 1775311200000, 1775311500000, 0, 1002, 2, 0, 0, 1775311500000, 1775311500000, 0, 1002002, '', 0);
