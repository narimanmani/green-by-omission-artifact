-- ==============================================================================
-- Test Users for E2E Authentication Tests
-- ==============================================================================
-- Note: In production, users should be created via better-auth service
-- For test/dev environments, we create test users directly in the seed file
--
-- IMPORTANT: These users are created without passwords in the seed.
-- Passwords are set by the auth service at startup (CREATE_DEFAULT_USER=TRUE)
-- or can be set by running the auth service's user creation flow.
--
-- For E2E tests, all test users use password: testpassword123
-- The auth service should be configured to create these accounts on startup.
-- ==============================================================================

-- Create test organization first (required for member roles)
INSERT INTO auth_organization (id, name, slug, created_at)
VALUES ('test-org-id-0000000000000000001', 'Test Organization', 'test-org', NOW())
ON CONFLICT (id) DO NOTHING;

-- Create test users for test automation
-- These users are required for the E2E test suite to function
INSERT INTO auth_user (id, name, email, email_verified, username, dj_name, real_name, role, created_at, updated_at, app_skin, has_completed_onboarding)
VALUES
  -- Member (no org role beyond member)
  ('test-member-id-000000000000000001', 'test_member', 'test_member@wxyc.org', true, 'test_member', 'Test Member DJ', 'Test Member', NULL, NOW(), NOW(), 'modern-light', true),
  -- DJ users
  ('test-dj1-id-00000000000000000001', 'test_dj1', 'test_dj1@wxyc.org', true, 'test_dj1', 'Test dj1', 'Test DJ 1', NULL, NOW(), NOW(), 'modern-light', true),
  ('test-dj2-id-00000000000000000002', 'test_dj2', 'test_dj2@wxyc.org', true, 'test_dj2', 'Test dj2', 'Test DJ 2', NULL, NOW(), NOW(), 'modern-light', true),
  -- Music Director
  ('test-md-id-0000000000000000001', 'test_music_director', 'test_music_director@wxyc.org', true, 'test_music_director', 'Test MD', 'Test Music Director', NULL, NOW(), NOW(), 'modern-light', true),
  -- Station Manager (with admin role for Better Auth Admin plugin)
  ('test-sm-id-0000000000000000001', 'test_station_manager', 'test_station_manager@wxyc.org', true, 'test_station_manager', 'Test SM', 'Test Station Manager', 'admin', NOW(), NOW(), 'modern-light', true),
  -- Incomplete user (has not completed onboarding, missing realName and djName)
  ('test-incomplete-id-0000000000001', 'test_incomplete', 'test_incomplete@wxyc.org', true, 'test_incomplete', '', '', NULL, NOW(), NOW(), 'modern-light', false),
  -- Deletable user (for admin deletion tests)
  ('test-deletable-id-00000000000001', 'test_deletable_user', 'test_deletable@wxyc.org', true, 'test_deletable_user', 'Deletable DJ', 'Test Deletable', NULL, NOW(), NOW(), 'modern-light', true),
  -- Promotable user (for role modification tests)
  ('test-promotable-id-0000000000001', 'test_promotable_user', 'test_promotable@wxyc.org', true, 'test_promotable_user', 'Promotable DJ', 'Test Promotable', NULL, NOW(), NOW(), 'modern-light', true),
  -- Demotable Station Manager (for role demotion tests)
  ('test-demotable-sm-id-000000000001', 'test_demotable_sm', 'test_demotable_sm@wxyc.org', true, 'test_demotable_sm', 'Demotable SM', 'Test Demotable SM', 'admin', NOW(), NOW(), 'modern-light', true),
  -- Password reset test users (dedicated users for password reset tests to avoid conflicts)
  ('test-reset1-id-000000000000000001', 'test_reset1', 'test_reset1@wxyc.org', true, 'test_reset1', 'Reset DJ 1', 'Test Reset 1', NULL, NOW(), NOW(), 'modern-light', true),
  ('test-reset2-id-000000000000000002', 'test_reset2', 'test_reset2@wxyc.org', true, 'test_reset2', 'Reset DJ 2', 'Test Reset 2', NULL, NOW(), NOW(), 'modern-light', true),
  -- Admin password reset test user (dedicated for admin-initiated password reset tests)
  ('test-adminreset1-id-00000000001', 'test_adminreset1', 'test_adminreset1@wxyc.org', true, 'test_adminreset1', 'AdminReset DJ', 'Test AdminReset 1', NULL, NOW(), NOW(), 'modern-light', true)
ON CONFLICT (id) DO UPDATE SET
  dj_name = EXCLUDED.dj_name,
  real_name = EXCLUDED.real_name,
  email_verified = EXCLUDED.email_verified,
  role = EXCLUDED.role,
  has_completed_onboarding = EXCLUDED.has_completed_onboarding,
  updated_at = NOW();

-- Create credential accounts for all test users
-- Password hash is for 'testpassword123' using scrypt (Better Auth parameters: N=16384, r=16, p=1, dkLen=64)
-- Format: salt:hash (both hex encoded, salt passed as string to scrypt)
INSERT INTO auth_account (id, user_id, account_id, provider_id, password, created_at, updated_at)
VALUES
  ('test-account-member-00000000001', 'test-member-id-000000000000000001', 'test-member-id-000000000000000001', 'credential', 'a1b2c3d4e5f6a7b8a1b2c3d4e5f6a7b8:05891b04ad22fe3cc64671a93657e9503e08bbe12193287ebc6944d4b3c12ef16e4a796f4f723920798e9911ae21306009e92b6a1f79d155835085e7efd77aa8', NOW(), NOW()),
  ('test-account-dj1-000000000001', 'test-dj1-id-00000000000000000001', 'test-dj1-id-00000000000000000001', 'credential', 'a1b2c3d4e5f6a7b8a1b2c3d4e5f6a7b8:05891b04ad22fe3cc64671a93657e9503e08bbe12193287ebc6944d4b3c12ef16e4a796f4f723920798e9911ae21306009e92b6a1f79d155835085e7efd77aa8', NOW(), NOW()),
  ('test-account-dj2-000000000001', 'test-dj2-id-00000000000000000002', 'test-dj2-id-00000000000000000002', 'credential', 'a1b2c3d4e5f6a7b8a1b2c3d4e5f6a7b8:05891b04ad22fe3cc64671a93657e9503e08bbe12193287ebc6944d4b3c12ef16e4a796f4f723920798e9911ae21306009e92b6a1f79d155835085e7efd77aa8', NOW(), NOW()),
  ('test-account-md-0000000000001', 'test-md-id-0000000000000000001', 'test-md-id-0000000000000000001', 'credential', 'a1b2c3d4e5f6a7b8a1b2c3d4e5f6a7b8:05891b04ad22fe3cc64671a93657e9503e08bbe12193287ebc6944d4b3c12ef16e4a796f4f723920798e9911ae21306009e92b6a1f79d155835085e7efd77aa8', NOW(), NOW()),
  ('test-account-sm-0000000000001', 'test-sm-id-0000000000000000001', 'test-sm-id-0000000000000000001', 'credential', 'a1b2c3d4e5f6a7b8a1b2c3d4e5f6a7b8:05891b04ad22fe3cc64671a93657e9503e08bbe12193287ebc6944d4b3c12ef16e4a796f4f723920798e9911ae21306009e92b6a1f79d155835085e7efd77aa8', NOW(), NOW()),
  -- Incomplete user uses temppass123 (for onboarding password change tests)
  ('test-account-incomplete-00001', 'test-incomplete-id-0000000000001', 'test-incomplete-id-0000000000001', 'credential', '5fa267eec9d6a94701575fce7b835466:805e0eef8140a9663c1f92dc6b66bb4f895d97f5be798dea9cf6d6cafc7ad68b63f0d8da6374bb3ca8185b96260ab94cdfc2e65aae4c305ebd3da787c05cecab', NOW(), NOW()),
  ('test-account-deletable-00001', 'test-deletable-id-00000000000001', 'test-deletable-id-00000000000001', 'credential', 'a1b2c3d4e5f6a7b8a1b2c3d4e5f6a7b8:05891b04ad22fe3cc64671a93657e9503e08bbe12193287ebc6944d4b3c12ef16e4a796f4f723920798e9911ae21306009e92b6a1f79d155835085e7efd77aa8', NOW(), NOW()),
  ('test-account-promotable-0001', 'test-promotable-id-0000000000001', 'test-promotable-id-0000000000001', 'credential', 'a1b2c3d4e5f6a7b8a1b2c3d4e5f6a7b8:05891b04ad22fe3cc64671a93657e9503e08bbe12193287ebc6944d4b3c12ef16e4a796f4f723920798e9911ae21306009e92b6a1f79d155835085e7efd77aa8', NOW(), NOW()),
  ('test-account-demotable-sm-01', 'test-demotable-sm-id-000000000001', 'test-demotable-sm-id-000000000001', 'credential', 'a1b2c3d4e5f6a7b8a1b2c3d4e5f6a7b8:05891b04ad22fe3cc64671a93657e9503e08bbe12193287ebc6944d4b3c12ef16e4a796f4f723920798e9911ae21306009e92b6a1f79d155835085e7efd77aa8', NOW(), NOW()),
  -- Password reset test user accounts
  ('test-account-reset1-0000000001', 'test-reset1-id-000000000000000001', 'test-reset1-id-000000000000000001', 'credential', 'a1b2c3d4e5f6a7b8a1b2c3d4e5f6a7b8:05891b04ad22fe3cc64671a93657e9503e08bbe12193287ebc6944d4b3c12ef16e4a796f4f723920798e9911ae21306009e92b6a1f79d155835085e7efd77aa8', NOW(), NOW()),
  ('test-account-reset2-0000000001', 'test-reset2-id-000000000000000002', 'test-reset2-id-000000000000000002', 'credential', 'a1b2c3d4e5f6a7b8a1b2c3d4e5f6a7b8:05891b04ad22fe3cc64671a93657e9503e08bbe12193287ebc6944d4b3c12ef16e4a796f4f723920798e9911ae21306009e92b6a1f79d155835085e7efd77aa8', NOW(), NOW()),
  -- Admin password reset test user account
  ('test-account-adminreset1-001', 'test-adminreset1-id-00000000001', 'test-adminreset1-id-00000000001', 'credential', 'a1b2c3d4e5f6a7b8a1b2c3d4e5f6a7b8:05891b04ad22fe3cc64671a93657e9503e08bbe12193287ebc6944d4b3c12ef16e4a796f4f723920798e9911ae21306009e92b6a1f79d155835085e7efd77aa8', NOW(), NOW())
ON CONFLICT (id) DO UPDATE SET
  password = EXCLUDED.password,
  updated_at = NOW();

-- Create organization memberships with appropriate roles
INSERT INTO auth_member (id, organization_id, user_id, role, created_at)
VALUES
  -- Member role
  ('test-membership-member-00001', 'test-org-id-0000000000000000001', 'test-member-id-000000000000000001', 'member', NOW()),
  -- DJ roles
  ('test-membership-dj1-0000001', 'test-org-id-0000000000000000001', 'test-dj1-id-00000000000000000001', 'dj', NOW()),
  ('test-membership-dj2-0000001', 'test-org-id-0000000000000000001', 'test-dj2-id-00000000000000000002', 'dj', NOW()),
  -- Music Director role
  ('test-membership-md-00000001', 'test-org-id-0000000000000000001', 'test-md-id-0000000000000000001', 'musicDirector', NOW()),
  -- Station Manager role
  ('test-membership-sm-00000001', 'test-org-id-0000000000000000001', 'test-sm-id-0000000000000000001', 'stationManager', NOW()),
  -- Incomplete user as DJ
  ('test-membership-incomplete', 'test-org-id-0000000000000000001', 'test-incomplete-id-0000000000001', 'dj', NOW()),
  -- Deletable user as DJ
  ('test-membership-deletable-1', 'test-org-id-0000000000000000001', 'test-deletable-id-00000000000001', 'dj', NOW()),
  -- Promotable user as member (for promotion tests)
  ('test-membership-promotable1', 'test-org-id-0000000000000000001', 'test-promotable-id-0000000000001', 'member', NOW()),
  -- Demotable SM as stationManager (for demotion tests)
  ('test-membership-demotable01', 'test-org-id-0000000000000000001', 'test-demotable-sm-id-000000000001', 'stationManager', NOW()),
  -- Password reset test users as DJ (for password reset tests)
  ('test-membership-reset1-0001', 'test-org-id-0000000000000000001', 'test-reset1-id-000000000000000001', 'dj', NOW()),
  ('test-membership-reset2-0001', 'test-org-id-0000000000000000001', 'test-reset2-id-000000000000000002', 'dj', NOW()),
  -- Admin password reset test user as DJ
  ('test-membership-adminres01', 'test-org-id-0000000000000000001', 'test-adminreset1-id-00000000001', 'dj', NOW())
ON CONFLICT (id) DO NOTHING;

-- Genres and media formats matching the legacy tubafrenzy database.
-- The library ETL job looks up genres/formats by name and skips releases
-- where the genre or format is missing, so all legacy values must be seeded.
-- Genre IDs must match production (alphabetical assignment from the initial ETL sync).
-- Using explicit IDs ensures compatibility with pg_dump snapshots and crossreference data.
INSERT INTO wxyc_schema.genres(id, genre_name) VALUES
  (1, 'Africa'), (2, 'Asia'), (3, 'Blues'), (4, 'Classical'), (5, 'Comedy'),
  (6, 'Hiphop'), (7, 'Jazz'), (8, 'Latin'), (9, 'OCS'), (10, 'Reggae'),
  (11, 'Rock'), (12, 'Soundtracks'), (13, 'Spoken'), (14, 'Xmas'), (15, 'Electronic')
ON CONFLICT (id) DO NOTHING;
SELECT setval('wxyc_schema.genres_id_seq', 15, true);

INSERT INTO wxyc_schema.format(format_name) VALUES
  ('cd'), ('vinyl'), ('vinyl 12"'), ('vinyl 7"'), ('vinyl 10"'), ('cdr')
ON CONFLICT DO NOTHING;

INSERT INTO wxyc_schema.artists(artist_name, alphabetical_name, code_letters)
	VALUES ('Built to Spill', 'Built to Spill', 'BU');

INSERT INTO wxyc_schema.artists(artist_name, alphabetical_name, code_letters)
	VALUES ('Ravyn Lenae', 'Ravyn Lenae', 'LE');

INSERT INTO wxyc_schema.artists(artist_name, alphabetical_name, code_letters)
	VALUES ('Jockstrap', 'Jockstrap', 'JO');

INSERT INTO wxyc_schema.genre_artist_crossreference(artist_id, genre_id, artist_genre_code)
	VALUES (1, 11, 60);
INSERT INTO wxyc_schema.genre_artist_crossreference(artist_id, genre_id, artist_genre_code)
	VALUES (2, 6, 35);
INSERT INTO wxyc_schema.genre_artist_crossreference(artist_id, genre_id, artist_genre_code)
	VALUES (3, 11, 108);

INSERT INTO wxyc_schema.library(
    artist_id, genre_id, format_id, album_title, code_number)
    VALUES (1, 11, 1, 'Keep it Like a Secret', 8);

INSERT INTO wxyc_schema.library(
    artist_id, genre_id, format_id, album_title, code_number)
    VALUES (2, 6, 1, 'Crush', 1);

INSERT INTO wxyc_schema.library(
    artist_id, genre_id, format_id, album_title, code_number)
    VALUES (3, 11, 2, 'I Love You Jennifer B', 1);

-- Additional artists for parallel test isolation (metadata.spec.js uses albums 4-6)
INSERT INTO wxyc_schema.artists(artist_name, alphabetical_name, code_letters)
	VALUES ('Sufjan Stevens', 'Sufjan Stevens', 'ST');

INSERT INTO wxyc_schema.artists(artist_name, alphabetical_name, code_letters)
	VALUES ('Kendrick Lamar', 'Kendrick Lamar', 'LA');

INSERT INTO wxyc_schema.artists(artist_name, alphabetical_name, code_letters)
	VALUES ('Bjork', 'Bjork', 'BJ');

INSERT INTO wxyc_schema.genre_artist_crossreference(artist_id, genre_id, artist_genre_code)
	VALUES (4, 11, 42);
INSERT INTO wxyc_schema.genre_artist_crossreference(artist_id, genre_id, artist_genre_code)
	VALUES (5, 6, 15);
INSERT INTO wxyc_schema.genre_artist_crossreference(artist_id, genre_id, artist_genre_code)
	VALUES (6, 11, 22);

-- Additional albums for parallel test isolation (IDs 4, 5, 6 for metadata.spec.js)
INSERT INTO wxyc_schema.library(
    artist_id, genre_id, format_id, album_title, code_number)
    VALUES (4, 11, 1, 'Illinois', 1);

INSERT INTO wxyc_schema.library(
    artist_id, genre_id, format_id, album_title, code_number)
    VALUES (5, 6, 1, 'To Pimp a Butterfly', 1);

INSERT INTO wxyc_schema.library(
    artist_id, genre_id, format_id, album_title, code_number)
    VALUES (6, 11, 2, 'Homogenic', 1);

INSERT INTO wxyc_schema.rotation(album_id, rotation_bin) VALUES (1, 'L');

-- Add album 4 to rotation for metadata.spec.js rotation tests
INSERT INTO wxyc_schema.rotation(album_id, rotation_bin) VALUES (4, 'M');

-- Stereolab + multiple albums for catalog-search ranking tests (Epic A.6).
-- Two albums on the same artist let `stereolab transient` exercise tsvector
-- AND-semantics: only the Transient-Random-Noise-Bursts row contains both
-- tokens, and the other Stereolab row must drop out of the result set.
INSERT INTO wxyc_schema.artists(artist_name, alphabetical_name, code_letters)
  VALUES ('Stereolab', 'Stereolab', 'ST');

INSERT INTO wxyc_schema.genre_artist_crossreference(artist_id, genre_id, artist_genre_code)
  VALUES (7, 11, 200);

INSERT INTO wxyc_schema.library(
    artist_id, genre_id, format_id, album_title, code_number)
    VALUES (7, 11, 2, 'Transient Random-Noise Bursts With Announcements', 1);

INSERT INTO wxyc_schema.library(
    artist_id, genre_id, format_id, album_title, code_number)
    VALUES (7, 11, 2, 'Mars Audiac Quintet', 2);

-- Autechre + Confield for the B-2.1 forward-path linkage E2E. The mock LML
-- fixture (dev_env/mock-api-server/src/fixtures/lml.json) returns release_id
-- 4080 for an "autechre" lookup; pre-stamping the library row with the
-- matching canonical entity id lets the resolver find a single library row
-- and link the flowsheet entry without any additional setup.
INSERT INTO wxyc_schema.artists(artist_name, alphabetical_name, code_letters)
  VALUES ('Autechre', 'Autechre', 'AU');

INSERT INTO wxyc_schema.genre_artist_crossreference(artist_id, genre_id, artist_genre_code)
  VALUES (8, 15, 1);

INSERT INTO wxyc_schema.library(
    artist_id, genre_id, format_id, album_title, code_number,
    canonical_entity_id, canonical_entity_confidence, canonical_entity_resolved_at)
    VALUES (8, 15, 1, 'Confield', 1,
            'discogs:release:4080', 0.9, NOW());

-- Jazz row for GET /library/query genres-filter integration tests (OR Rock,Jazz).
INSERT INTO wxyc_schema.artists(artist_name, alphabetical_name, code_letters)
  VALUES ('Miles Davis', 'Davis, Miles', 'DA');

INSERT INTO wxyc_schema.genre_artist_crossreference(artist_id, genre_id, artist_genre_code)
  VALUES (9, 7, 1);

INSERT INTO wxyc_schema.library(
    artist_id, genre_id, format_id, album_title, code_number)
    VALUES (9, 7, 1, 'Kind of Blue', 1);

-- Mirror the A.2 backfill outcome for all seeded library rows so the new
-- tsvector path (which reads library.artist_name directly) and the trigram
-- fallback (which uses the GIN index on library.artist_name) have populated
-- data to match against. In production this is owned by the
-- @wxyc/library-artist-name-backfill job; the seed has to do it inline
-- because new fixture rows are inserted by SQL, not the API.
UPDATE wxyc_schema.library l
   SET artist_name = a.artist_name
  FROM wxyc_schema.artists a
 WHERE l.artist_id = a.id
   AND l.artist_name IS NULL;