/**
 * Data transformers for the flowsheet ETL.
 *
 * Maps tubafrenzy entry types and data shapes to Backend-Service schema.
 * All functions are pure (no side effects) for easy testing.
 */

// Import shared utilities for local use and re-export so existing imports continue to work
import { epochMsToDate as _epochMsToDate, truncate as _truncate, isBeyondFutureTolerance } from '@wxyc/database';
export const epochMsToDate = _epochMsToDate;
export const truncate = _truncate;

/**
 * tubafrenzy entry_type codes:
 *   0 = track
 *   1 = show_start
 *   2 = show_end
 *   3 = breakpoint
 *   4 = talkset
 *   5 = dj_join
 *   6 = dj_leave
 *   7 = message (PSA, announcement)
 *   8-10 = reserved (treated as message)
 */
type BackendEntryType =
  'track' | 'show_start' | 'show_end' | 'breakpoint' | 'talkset' | 'dj_join' | 'dj_leave' | 'message';

const ENTRY_TYPE_MAP: Record<number, BackendEntryType> = {
  0: 'track',
  1: 'show_start',
  2: 'show_end',
  3: 'breakpoint',
  4: 'talkset',
  5: 'dj_join',
  6: 'dj_leave',
  7: 'message',
};

export const mapEntryType = (legacyType: number): BackendEntryType => {
  return ENTRY_TYPE_MAP[legacyType] ?? 'message';
};

/**
 * FLOWSHEET_ENTRY_TYPE_CODE_ID codes (production FLOWSHEET_ENTRY_PROD table):
 *   0 = OTHER (non-rotation track)
 *   1-4 = HEAVY/MEDIUM/LIGHT/SINGLES (rotation tracks)
 *   5 = NEW (new vinyl, not yet in rotation)
 *   6 = LIBRARY (existing library release)
 *   7 = TALKSET
 *   8 = HOURLY_BREAK
 *   9 = START_OF_SHOW
 *   10 = END_OF_SHOW
 */
const PROD_ENTRY_TYPE_MAP: Record<number, BackendEntryType> = {
  0: 'track',
  1: 'track',
  2: 'track',
  3: 'track',
  4: 'track',
  5: 'track',
  6: 'track',
  7: 'talkset',
  8: 'breakpoint',
  9: 'show_start',
  10: 'show_end',
};

export const mapProdEntryType = (typeCode: number): BackendEntryType => {
  return PROD_ENTRY_TYPE_MAP[typeCode] ?? 'message';
};

/**
 * Resolve the UTC offset for America/New_York at a given instant.
 * Returns a string like "-05:00" (EST) or "-04:00" (EDT).
 *
 * See also: `@wxyc/database`'s `shared/database/src/ny-time.ts`
 * (`nyWallClockToUtc`) is the newer shared sibling of this same two-pass
 * NY offset converge, with an explicit DST-gap policy. A DST- or
 * Intl-parsing fix here almost certainly applies there too; consolidating
 * this module onto ny-time is a known follow-up — until then, patch both.
 */
const easternOffsetAt = (probeUtc: Date): string => {
  const parts = new Intl.DateTimeFormat('en-US', {
    timeZone: 'America/New_York',
    timeZoneName: 'shortOffset',
  }).formatToParts(probeUtc);
  const tz = parts.find((p) => p.type === 'timeZoneName')?.value ?? 'GMT-5';
  // tz is "GMT-5" or "GMT-4"; normalize to "-05:00" / "-04:00"
  const hours = parseInt(tz.replace('GMT', ''), 10);
  const sign = hours <= 0 ? '-' : '+';
  return `${sign}${String(Math.abs(hours)).padStart(2, '0')}:00`;
};

/**
 * Convert a MySQL DATETIME string (e.g. '2023-10-15 14:30:00') to a JS Date.
 * tubafrenzy stores times as America/New_York wall-clock values with no
 * offset, so we determine whether EST or EDT applies for the given date and
 * append the correct offset before parsing.
 * Returns null if the input is null, empty, or unparseable.
 */
export const parseMySQLDatetime = (datetime: string | null): Date | null => {
  if (!datetime || datetime.trim().length === 0 || datetime === 'NULL') return null;
  const isoString = datetime.trim().replace(' ', 'T');
  // First pass: treat the wall-clock time as UTC to probe the Eastern offset
  const probeUtc = new Date(isoString + 'Z');
  if (Number.isNaN(probeUtc.getTime())) return null;
  const offset1 = easternOffsetAt(probeUtc);
  const date1 = new Date(isoString + offset1);
  // Second pass: the first result is the true UTC instant (within 1 hour);
  // re-probe to handle the edge case near DST transitions where the UTC
  // probe date falls on the wrong side of the boundary.
  const offset2 = easternOffsetAt(date1);
  if (offset2 !== offset1) {
    const date2 = new Date(isoString + offset2);
    return Number.isNaN(date2.getTime()) ? null : date2;
  }
  return Number.isNaN(date1.getTime()) ? null : date1;
};

// epochMsToDate is re-exported from @wxyc/database above

/**
 * Resolve the best available timestamp for a FLOWSHEET_ENTRY_PROD row.
 * Prefers START_TIME (epoch ms), falls back to TIME_CREATED, then TIME_LAST_MODIFIED.
 * Most track entries have START_TIME = 0, so the fallback is essential.
 *
 * BS#2143: a candidate that resolves to a Date more than
 * `FUTURE_TIMESTAMP_TOLERANCE_MS` ahead of `now` is treated exactly like a
 * null/0 candidate — skipped in favour of the next one in the preference
 * chain. If every candidate is beyond tolerance (or absent), this returns
 * `null`, same as it always has for an unresolvable row; every caller
 * (`jobs/flowsheet-etl/job.ts` `importEntries`/`runIncremental`,
 * `jobs/flowsheet-april-gap-import/build-row.ts` `buildInsertRow`,
 * `jobs/flowsheet-april-gap-import/orchestrate.ts` `discoverCandidates`)
 * already `continue`s or returns `null` on a null result, so this introduces
 * no new failure mode at any call site — a future-dated candidate just joins
 * the existing "couldn't resolve a timestamp" bucket.
 *
 * Deliberately FALLS THROUGH rather than CLAMPING (contrast with the webhook
 * receiver's `markerTimestamp` in apps/backend/routes/internal.route.ts,
 * which clamps to the delivery clock — see that assignment's doc comment for
 * the full webhook-side reasoning and the cross-reference back to here).
 * This function feeds two importers
 * (`jobs/flowsheet-etl`, `jobs/flowsheet-april-gap-import`) that legitimately
 * write HISTORICAL rows, sometimes months old. Clamping a bad `startTime` to
 * the import's wall clock would stamp a months-old row with `now()` and land
 * it at the head of exactly the three `add_time DESC`-sorted windows BS#2143
 * exists to protect (`fetchRecentRows`, `X-Last-Modified`,
 * `getEntriesByPage`/`GET /flowsheet/latest`) — converting a rare upstream
 * defect into a guaranteed self-inflicted one on every import. Falling
 * through to the next real (non-future) candidate timestamp avoids that
 * entirely, at the cost of occasionally landing on a slightly-stale
 * TIME_CREATED/TIME_LAST_MODIFIED instead of a bogus START_TIME — an
 * acceptable trade for an importer, unacceptable for a live write.
 */
export const resolveEntryTimestamp = (
  startTime: number | null,
  timeCreated: number | null,
  timeLastModified: number | null,
  now: Date = new Date()
): Date | null => {
  const candidates = [epochMsToDate(startTime), epochMsToDate(timeCreated), epochMsToDate(timeLastModified)];
  for (const candidate of candidates) {
    if (candidate !== null && !isBeyondFutureTolerance(candidate, now)) {
      return candidate;
    }
  }
  return null;
};

/**
 * Resolve the breakpoint top-of-hour for a flowsheet entry (BS#1449).
 *
 * tubafrenzy's RADIO_HOUR (epoch ms) is the authoritative top-of-hour a
 * breakpoint marks (e.g. 12:00 PM) — distinct from add_time, the ~1-min-early
 * logging instant that floors one hour early when a client formats "h a".
 * Only breakpoint rows carry it; every other type stores null. epochMsToDate
 * maps 0/absent → null, so a breakpoint missing RADIO_HOUR also yields null.
 */
export const resolveRadioHour = (entryType: BackendEntryType, radioHourMs: number | null): Date | null =>
  entryType === 'breakpoint' ? epochMsToDate(radioHourMs) : null;

// truncate is re-exported from @wxyc/database above

/**
 * Entry types whose legacy ARTIST_NAME text is display content, not a real
 * artist (BS#2119 PR 0: moved out of jobs/flowsheet-etl/job.ts, which
 * self-invokes its ETL `run()` at module scope — importing anything from it,
 * including this pure predicate, opens a MirrorSQL connection and trips the
 * backwards-write refusal. Extracting the pure mappers here lets
 * jobs/flowsheet-april-gap-import reuse them without executing the ETL).
 */
export const isMessageEntryType = (entryType: string): boolean =>
  entryType === 'breakpoint' || entryType === 'talkset' || entryType === 'message';

/**
 * Resolve the artist_name for a flowsheet entry.
 *
 * For message-bearing types (breakpoint, talkset, message), the text belongs in
 * the message field instead — return null here.
 *
 * For show_start / show_end markers, the ARTIST_NAME column in tubafrenzy holds
 * the full marker text (e.g. "START OF SHOW: DJ Aubrey Hearst SIGNED ON at
 * 7:43 PM (6/2/26)"). Preserve it verbatim — V1 surfaces (dj-site flowsheet,
 * wxyc.info) render `artist_name` directly, and reducing it to the bare DJ
 * name strips information the writer put there on purpose. The ETL stays
 * shape-agnostic about marker templates; whatever TF holds is what BS persists,
 * truncated to the 128-char column limit. See #1287 and epic #1288.
 */
export const resolveArtistName = (rawArtistName: string | null, entryType: string): string | null => {
  if (!rawArtistName) return null;
  if (isMessageEntryType(entryType)) return null;
  return truncate(rawArtistName, 128);
};

/**
 * Resolve the message field for a flowsheet entry. For breakpoint, talkset, and
 * message entries, the legacy ARTIST_NAME column contains the display text.
 */
export const resolveMessage = (rawArtistName: string | null, entryType: string): string | null => {
  if (!rawArtistName || !isMessageEntryType(entryType)) return null;
  return truncate(rawArtistName, 250);
};

export type TransformedShow = {
  legacy_show_id: number;
  start_time: Date;
  end_time: Date | null;
  show_name: string | null;
};

export type TransformedEntry = {
  legacy_entry_id: number;
  legacy_show_id: number;
  entry_type: BackendEntryType;
  artist_name: string | null;
  album_title: string | null;
  track_title: string | null;
  record_label: string | null;
  message: string | null;
  request_flag: boolean;
  segue: boolean;
  play_order: number;
  add_time: Date;
};

/**
 * Transform a raw show tuple from a MySQL dump into a TransformedShow.
 * Expects columns: [id, start_time, end_time].
 */
export const transformShow = (row: [number, string, string | null]): TransformedShow | null => {
  const startTime = parseMySQLDatetime(row[1]);
  if (!startTime) return null;
  return {
    legacy_show_id: row[0],
    start_time: startTime,
    end_time: parseMySQLDatetime(row[2]),
    show_name: null,
  };
};

/**
 * Transform a raw entry tuple from a MySQL dump into a TransformedEntry.
 * Expects columns from tubafrenzy PLAYLIST_ENTRY:
 *   [id, show_id, entry_type, artist_name, album_title, track_title, label, message, request_flag, play_order, time_played]
 */
export const transformEntry = (row: (string | number | null)[]): TransformedEntry | null => {
  if (row[0] == null || row[1] == null) return null;
  const entryId = Number(row[0]);
  const showId = Number(row[1]);
  const addTime = parseMySQLDatetime(row[10] as string | null);
  if (!addTime || !Number.isFinite(entryId) || !Number.isFinite(showId)) return null;

  return {
    legacy_entry_id: entryId,
    legacy_show_id: showId,
    entry_type: mapEntryType(Number(row[2]) || 0),
    artist_name: truncate(row[3] as string | null, 128),
    album_title: truncate(row[4] as string | null, 128),
    track_title: truncate(row[5] as string | null, 128),
    record_label: truncate(row[6] as string | null, 128),
    message: truncate(row[7] as string | null, 250),
    request_flag: row[8] === 1 || row[8] === '1',
    segue: false,
    play_order: Number(row[9]) || 0,
    add_time: addTime,
  };
};
