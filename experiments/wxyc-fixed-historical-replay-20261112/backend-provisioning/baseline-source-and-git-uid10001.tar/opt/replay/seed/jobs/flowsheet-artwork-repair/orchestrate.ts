/**
 * Orchestrator for flowsheet-artwork-repair drain (BS#1209).
 *
 * Two-phase one-shot:
 *
 *   1. **Free-form phase**: SELECT every flowsheet row where
 *      `metadata_status = 'enriched_match' AND artwork_url IS NULL AND
 *      album_id IS NULL`. For each row: lookup → repairFreeFormRow → count.
 *   2. **Linked phase**: SELECT album_metadata rows where `artwork_url IS
 *      NULL`, joined to library for (artist_name, album_title). For each
 *      album: lookup → repairLinkedAlbum → count.
 *
 * The orchestrator does NOT throttle per-row directly. LML pacing is
 * delegated to `@wxyc/lml-client`'s shared chokepoint (the `defaultLmlLimiter`
 * singleton in `lml-limiter.ts`, wired with `BACKFILL_LML_RATE_PER_MIN=20`
 * + `BACKFILL_LML_MAX_CONCURRENT=1` env defaults so a runaway pace can't
 * repeat the BS#994 monopolization incident). No per-job rate limiter that
 * bypasses the chokepoint — that's BS#1137.
 *
 * Cooperative pause mirrors `jobs/flowsheet-metadata-backfill/orchestrate.ts`:
 * probe `flowsheet` for any track row added within `LIVE_ACTIVITY_LOOKBACK_SECONDS`
 * (default 60 s); if found, defer the next row for `LIVE_ACTIVITY_PAUSE_MS`
 * (default 30 s) and re-probe. Set lookback to 0 for catch-up runs.
 *
 * Status read-only. The two repair writers are responsible for ensuring
 * `metadata_status` never appears in their .set() blocks; the orchestrator
 * trusts them. The "status-update-count == 0 from this job" acceptance
 * criterion is satisfied by the writer test pinning `'metadata_status' in
 * setArgs === false` (see repair.test.ts).
 *
 * The free-form enumeration runs in a `db.transaction` with `SET LOCAL
 * statement_timeout` because the predicate isn't covered by an existing
 * partial index — the planner falls back to a seq scan over flowsheet's
 * 2.6M+ rows. The backend's 5 s default would trip. Mirrors
 * `jobs/album-level-backfill/job.ts#enumeratePendingAlbumIds`. Linked
 * enumeration is bounded by `album_metadata`'s much smaller row count, so
 * the same wrapper is applied but the timeout rarely matters.
 */

import { sql } from 'drizzle-orm';
import {
  db,
  checkLiveActivity as defaultCheckLiveActivity,
  LIVE_ACTIVITY_LOOKBACK_SECONDS_DEFAULT,
  LIVE_ACTIVITY_MAX_PAUSE_MS_ENV,
  resolveLiveActivityPauseMs as resolveLiveActivityPauseMsShared,
  resolveLiveActivityMaxPauseMs as resolveLiveActivityMaxPauseMsShared,
  buildWaitForQuietPeriod,
  requireNonNegativeInt,
  type CheckLiveActivityFn,
} from '@wxyc/database';
import type { LookupResponse } from '@wxyc/lml-client';
import type { FreeFormRow, LinkedAlbum, RepairOutcome } from './repair.js';
import { captureError, log } from './logger.js';

const JOB_NAME = 'flowsheet-artwork-repair';

const SCHEMA = (process.env.WXYC_SCHEMA_NAME || 'wxyc_schema').replace(/"/g, '""');
const FLOWSHEET_TABLE = sql.raw(`"${SCHEMA}"."flowsheet"`);
const ALBUM_METADATA_TABLE = sql.raw(`"${SCHEMA}"."album_metadata"`);
const LIBRARY_TABLE = sql.raw(`"${SCHEMA}"."library"`);
const ARTISTS_TABLE = sql.raw(`"${SCHEMA}"."artists"`);

/** Default statement_timeout for the enumeration queries. The free-form
 * predicate isn't covered by an existing partial index; the planner falls
 * back to a seq scan over flowsheet's 2.6M+ rows. 5 min covers observed
 * runtime with comfortable margin. Mirrors `album-metadata-backfill#verifyComplete`. */
export const ENUMERATE_TIMEOUT_MS = 5 * 60 * 1000;

export const resolveLiveActivityLookback = (
  raw: string | undefined = process.env.LIVE_ACTIVITY_LOOKBACK_SECONDS
): number =>
  requireNonNegativeInt(raw, 'LIVE_ACTIVITY_LOOKBACK_SECONDS', LIVE_ACTIVITY_LOOKBACK_SECONDS_DEFAULT, {
    unit: 's',
    note: 'Use 0 to disable.',
  });

/**
 * BS#2147: delegates to the shared floored resolver so `LIVE_ACTIVITY_PAUSE_MS`
 * below `LIVE_ACTIVITY_MIN_PAUSE_MS` (including `0`) is rejected at init
 * instead of degrading the cooperative-pause loop into a hot loop against
 * RDS. `LIVE_ACTIVITY_LOOKBACK_SECONDS=0` remains the sole disable knob.
 */
export const resolveLiveActivityPauseMs = (raw: string | undefined = process.env.LIVE_ACTIVITY_PAUSE_MS): number =>
  resolveLiveActivityPauseMsShared(raw, 'LIVE_ACTIVITY_PAUSE_MS');

/**
 * BS#2147 review round 2, finding 5: wires `LIVE_ACTIVITY_MAX_PAUSE_MS` at
 * this job's own call site. Before this, `buildWaitForQuietPeriod`'s
 * `maxTotalPauseMs` always took its hardcoded 30-minute default — the env
 * var read like a tunable knob but no TypeScript job ever read it, the
 * exact failure shape BS#2147 exists to close. `0` = uncapped.
 */
export const resolveLiveActivityMaxPauseMs = (
  raw: string | undefined = process.env.LIVE_ACTIVITY_MAX_PAUSE_MS
): number => resolveLiveActivityMaxPauseMsShared(raw, LIVE_ACTIVITY_MAX_PAUSE_MS_ENV);

/**
 * SELECT every flowsheet row stranded by the LML#408 bug in the free-form
 * (no album_id) population. Wrapped in a transaction with `SET LOCAL
 * statement_timeout` so the predicate's uncovered seq scan can't blow the
 * backend's 5 s default.
 */
export const enumerateFreeFormResidue = async (timeoutMs: number = ENUMERATE_TIMEOUT_MS): Promise<FreeFormRow[]> => {
  return await db.transaction(async (tx) => {
    await tx.execute(sql.raw(`SET LOCAL statement_timeout = '${timeoutMs}ms'`));
    const rows = (await tx.execute(sql`
      SELECT
        "id",
        "artist_name",
        "album_title",
        "track_title"
      FROM ${FLOWSHEET_TABLE}
      WHERE "entry_type" = 'track'
        AND "artist_name" IS NOT NULL
        AND "metadata_status" = 'enriched_match'
        AND "artwork_url" IS NULL
        AND "album_id" IS NULL
      ORDER BY "id" ASC
    `)) as unknown as FreeFormRow[];
    return rows ?? [];
  });
};

/**
 * SELECT distinct album_ids whose `album_metadata` row carries NULL artwork,
 * joined to `library` for the (artist_name, album_title) lookup keys.
 * Album-level dedup: one row per album_id, even when many flowsheet rows
 * point at the same album. Mirrors the same `COALESCE(artists.artist_name,
 * library.artist_name)` shape as `album-level-backfill#resolveAlbums` so
 * legacy-and-unbackfilled library rows don't surface as the literal string
 * "null".
 */
export const enumerateLinkedResidue = async (timeoutMs: number = ENUMERATE_TIMEOUT_MS): Promise<LinkedAlbum[]> => {
  return await db.transaction(async (tx) => {
    await tx.execute(sql.raw(`SET LOCAL statement_timeout = '${timeoutMs}ms'`));
    const rows = (await tx.execute(sql`
      SELECT DISTINCT
        am."album_id" AS album_id,
        COALESCE(a."artist_name", l."artist_name") AS artist_name,
        l."album_title" AS album_title
      FROM ${ALBUM_METADATA_TABLE} am
      JOIN ${LIBRARY_TABLE} l ON l."id" = am."album_id"
      LEFT JOIN ${ARTISTS_TABLE} a ON l."artist_id" = a."id"
      WHERE am."artwork_url" IS NULL
        AND l."album_title" IS NOT NULL
        AND COALESCE(a."artist_name", l."artist_name") IS NOT NULL
      ORDER BY am."album_id" ASC
    `)) as unknown as Array<{ album_id: number; artist_name: string; album_title: string }>;
    return rows.map((r) => ({
      album_id: Number(r.album_id),
      artist_name: String(r.artist_name),
      album_title: String(r.album_title),
    }));
  });
};

export type LookupFn = (artist: string, album?: string, track?: string) => Promise<LookupResponse>;

export type FreeFormRepairFn = (row: FreeFormRow, response: LookupResponse) => Promise<RepairOutcome>;
export type LinkedRepairFn = (album: LinkedAlbum, response: LookupResponse) => Promise<RepairOutcome>;

export type Totals = {
  free_form_scanned: number;
  free_form_repaired: number;
  free_form_raced: number;
  linked_scanned: number;
  linked_repaired: number;
  linked_raced: number;
  still_null_after_lml: number;
  error: number;
};

export type RunResult = { totals: Totals };

const emptyTotals = (): Totals => ({
  free_form_scanned: 0,
  free_form_repaired: 0,
  free_form_raced: 0,
  linked_scanned: 0,
  linked_repaired: 0,
  linked_raced: 0,
  still_null_after_lml: 0,
  error: 0,
});

export type RunRepairOptions = {
  lookup: LookupFn;
  repairFreeForm: FreeFormRepairFn;
  repairLinked: LinkedRepairFn;
  /** Pre-loaded rows. In production, supplied by `enumerateFreeFormResidue()`. */
  freeFormRows?: FreeFormRow[];
  /** Pre-loaded albums. In production, supplied by `enumerateLinkedResidue()`. */
  linkedAlbums?: LinkedAlbum[];
  liveActivityLookbackSeconds?: number;
  liveActivityPauseMs?: number;
  /** Cumulative cooperative-pause budget ceiling; 0 = uncapped. */
  liveActivityMaxPauseMs?: number;
  checkLiveActivity?: CheckLiveActivityFn;
};

/**
 * Drive both phases end-to-end. Pre-loaded population can be passed via
 * `freeFormRows` / `linkedAlbums`; when omitted, the orchestrator calls
 * the enumeration helpers itself.
 *
 * Each row's LML call is wrapped in a try/catch — a single LML failure
 * is logged + counted as `error` and the loop continues. The row stays
 * in its original state (`metadata_status='enriched_match' AND artwork_url
 * IS NULL` for free-form; `album_metadata.artwork_url IS NULL` for linked),
 * so the next sweep can retry it. Idempotent.
 */
export const runRepair = async (opts: RunRepairOptions): Promise<RunResult> => {
  const lookbackSeconds = opts.liveActivityLookbackSeconds ?? resolveLiveActivityLookback();
  const pauseMs = opts.liveActivityPauseMs ?? resolveLiveActivityPauseMs();
  const maxTotalPauseMs = opts.liveActivityMaxPauseMs ?? resolveLiveActivityMaxPauseMs();
  const probe = opts.checkLiveActivity ?? defaultCheckLiveActivity;

  // BS#2147: the loop itself (probe + elapsed-time cap) now lives in the
  // shared `buildWaitForQuietPeriod`. `onPause` reproduces this job's exact
  // prior `live_activity_pause` log line/fields so ops greps don't drift.
  // This job gains fail-open probe-error handling here for the first time —
  // a probe throw used to propagate out of `runRepair` and abort the whole
  // drain; it is now logged/captured and treated as "no activity" for that
  // iteration, matching six of the ten sibling jobs. No SIGTERM/stop
  // handling existed here before and none is added (`shouldStop` defaults
  // to `() => false`) — out of scope for BS#2147. `maxTotalPauseMs`
  // (finding 5) is wired so `LIVE_ACTIVITY_MAX_PAUSE_MS` actually reaches
  // the shared ceiling; on exhaustion the closure throws (findings 1+2) and
  // this job's own top-level `catch` in `job.ts` already logs + captures +
  // exits non-zero.
  const waitForQuietPeriod = buildWaitForQuietPeriod({
    lookbackSeconds,
    pauseMs,
    maxTotalPauseMs,
    probe,
    onPause: () => {
      log('info', 'live_activity_pause', `live flowsheet activity detected; pausing ${pauseMs}ms`, {
        lookback_seconds: lookbackSeconds,
        pause_ms: pauseMs,
      });
    },
    onProbeError: (error) => {
      // BS#2147 review round 2, finding 6: `(error as Error).message` throws
      // a TypeError when the probe rejects with a non-Error value (`null`,
      // `undefined`, a thrown string) — a throw from inside this callback
      // escapes `safeProbe`'s try/catch in the shared `buildWaitForQuietPeriod`
      // and aborts the whole run, defeating the fail-open this handler exists
      // to provide. Guard with `instanceof Error`, as the sibling jobs do.
      log('warn', 'probe_error', 'checkLiveActivity threw; assuming no activity', {
        error_message: error instanceof Error ? error.message : String(error),
      });
      captureError(error, 'probe_error');
    },
    onBudgetExhausted: (pausedMs) => {
      log(
        'error',
        'live_activity_pause_ceiling_exceeded',
        `cooperative-pause budget exceeded (${pausedMs}ms >= LIVE_ACTIVITY_MAX_PAUSE_MS=${maxTotalPauseMs}ms); aborting instead of pausing indefinitely`,
        { paused_ms: pausedMs, live_activity_max_pause_ms: maxTotalPauseMs }
      );
    },
  });

  const freeFormRows = opts.freeFormRows ?? (await enumerateFreeFormResidue());
  const linkedAlbums = opts.linkedAlbums ?? (await enumerateLinkedResidue());

  log('info', 'started', `${JOB_NAME} starting`, {
    free_form_residue: freeFormRows.length,
    linked_residue: linkedAlbums.length,
    live_activity_lookback_seconds: lookbackSeconds,
    live_activity_pause_ms: pauseMs,
    live_activity_max_pause_ms: maxTotalPauseMs,
  });

  const totals = emptyTotals();

  // Phase 1: free-form residue
  for (const row of freeFormRows) {
    await waitForQuietPeriod();
    totals.free_form_scanned += 1;

    let response: LookupResponse;
    try {
      response = await opts.lookup(row.artist_name, row.album_title ?? undefined, row.track_title ?? undefined);
    } catch (error) {
      log('warn', 'lml_error', `LML lookup failed for flowsheet.id=${row.id}`, {
        flowsheet_id: row.id,
        error_message: (error as Error).message,
      });
      captureError(error, 'lml_error', {
        phase: 'free_form',
        flowsheet_id: row.id,
        artist: row.artist_name,
        album: row.album_title,
        track: row.track_title,
      });
      totals.error += 1;
      continue;
    }

    const outcome = await opts.repairFreeForm(row, response);
    if (outcome === 'still_null_after_lml') totals.still_null_after_lml += 1;
    else if (outcome === 'free_form_repaired') totals.free_form_repaired += 1;
    else if (outcome === 'free_form_raced') totals.free_form_raced += 1;
  }

  // Phase 2: linked residue
  for (const album of linkedAlbums) {
    await waitForQuietPeriod();
    totals.linked_scanned += 1;

    let response: LookupResponse;
    try {
      response = await opts.lookup(album.artist_name, album.album_title, undefined);
    } catch (error) {
      log('warn', 'lml_error', `LML lookup failed for album_id=${album.album_id}`, {
        album_id: album.album_id,
        error_message: (error as Error).message,
      });
      captureError(error, 'lml_error', {
        phase: 'linked',
        album_id: album.album_id,
        artist: album.artist_name,
        album: album.album_title,
      });
      totals.error += 1;
      continue;
    }

    const outcome = await opts.repairLinked(album, response);
    if (outcome === 'still_null_after_lml') totals.still_null_after_lml += 1;
    else if (outcome === 'linked_repaired') totals.linked_repaired += 1;
    else if (outcome === 'linked_raced') totals.linked_raced += 1;
  }

  log('info', 'finished', `${JOB_NAME} done`, { ...totals });
  return { totals };
};
