/**
 * Observability for metadata-no-match-digest: Sentry init + JSON logs.
 *
 * Mirrors jobs/flowsheet-ghost-row-sweep/logger.ts verbatim -- the contract
 * is identical, the duplication keeps this job's build graph independent of
 * the sibling job packages.
 */

import * as Sentry from '@sentry/node';
import { randomUUID } from 'crypto';

export type LoggerConfig = {
  repo: string;
  tool: string;
  runId?: string;
};

export type LogLevel = 'info' | 'warn' | 'error';

type BaseTags = { repo: string; tool: string; run_id: string };

let baseTags: BaseTags | null = null;

export const resolveTracesSampleRate = (raw: string | undefined = process.env.SENTRY_TRACES_SAMPLE_RATE): number => {
  if (raw === undefined) return 1;
  const parsed = Number(raw);
  if (!Number.isFinite(parsed) || parsed < 0 || parsed > 1) return 1;
  return parsed;
};

export const initLogger = (config: LoggerConfig): string => {
  const runId = config.runId ?? randomUUID();
  baseTags = { repo: config.repo, tool: config.tool, run_id: runId };

  Sentry.init({
    dsn: process.env.SENTRY_DSN,
    release: process.env.SENTRY_RELEASE,
    environment: process.env.NODE_ENV || 'production',
    tracesSampleRate: resolveTracesSampleRate(),
  });
  Sentry.setTag('repo', config.repo);
  Sentry.setTag('tool', config.tool);
  Sentry.setTag('run_id', runId);

  return runId;
};

export const log = (level: LogLevel, step: string, message: string, fields: Record<string, unknown> = {}): void => {
  if (!baseTags) return;
  const line =
    JSON.stringify({
      timestamp: new Date().toISOString(),
      level,
      step,
      message,
      ...baseTags,
      ...fields,
    }) + '\n';
  if (level === 'error') {
    process.stderr.write(line);
  } else {
    process.stdout.write(line);
  }
};

export const captureError = (error: unknown, step: string, extra: Record<string, unknown> = {}): void => {
  Sentry.captureException(error, { tags: { step }, extra });
};

/**
 * Defend against non-Error throws (`throw 'string'`, `throw { code: x }`) --
 * `(err as Error).message` would emit `undefined` and the JSON logger would
 * drop the key. The canonical safe pattern from
 * flowsheet-metadata-backfill/orchestrate.ts.
 *
 * Also appends `error.cause.message` when present and distinct: Drizzle wraps
 * driver errors as `DrizzleQueryError: Failed query: <sql>` and hides the real
 * failure (a PG error, or the postgres-js/Node `TypeError` from the date
 * serializer passthrough -- see `query.ts`) on `.cause`. Logging only
 * `.message` made the original enriched_no_match-digest failure undiagnosable
 * from stdout; surfacing the cause mirrors BS#975's observability fix.
 */
export const errorMessage = (error: unknown): string => {
  if (!(error instanceof Error)) return String(error);
  // Only Error and string causes are surfaced -- the realistic shapes here
  // (Drizzle wraps an underlying driver Error; a `throw 'msg'` carries a
  // string). An exotic object cause is left off rather than emit a useless
  // `[object Object]`.
  const cause: unknown = (error as { cause?: unknown }).cause;
  const causeText = cause instanceof Error ? cause.message : typeof cause === 'string' ? cause : undefined;
  return causeText && causeText !== error.message ? `${error.message} [cause: ${causeText}]` : error.message;
};

export const closeLogger = async (): Promise<void> => {
  await Sentry.close(2000);
  baseTags = null;
};
