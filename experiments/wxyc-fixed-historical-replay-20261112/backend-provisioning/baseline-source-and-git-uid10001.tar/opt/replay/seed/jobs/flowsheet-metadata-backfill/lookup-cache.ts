/**
 * Run-scoped (artist, album) lookup dedup cache for the historical
 * metadata drain (peer ticket to BS#1011 / Slot 6 of BS#1279).
 *
 * Prod measurement on 2026-06-03: 628,561 pending unlinked flowsheet rows
 * resolve to 362,258 distinct (artist_name, album_title) pairs — a 1.74×
 * multiplier. A cron-lifetime Map cuts the LML call budget by ~42% without
 * pacing changes, schema changes, or cross-repo work.
 *
 * Lifetime is the cron container — daily `docker rm -f` is the eviction
 * strategy. No LRU, no size cap. Worst-case memory at today's volume is
 * ~40MB; container has tens of GB of headroom. A soft warning log fires
 * at `size > 50000` so a regression that would push past ~250MB surfaces
 * in logs.
 *
 * Per-track URL stripping is the cache's concern, not the orchestrator's.
 * `get()` returns a shallow-copied response with five per-track URL fields
 * deleted: `spotify_url`, `youtube_music_url`, `bandcamp_url`,
 * `soundcloud_url`, and `apple_music_url`. All FIVE columns are
 * track-aware URL columns on `album_metadata`; on a cache hit, enrich.ts
 * uses a conditional spread on the `'<field>' in artwork` witness for
 * each one and OMITS the column from the album_metadata UPSERT (both
 * INSERT and onConflictDoUpdate.set) AND the inline unlinked flowsheet
 * UPDATE so a prior verified value is preserved instead of being
 * clobbered via the UPSERT's `updated_at < NOW()` setWhere — that guard
 * always passes within a single backfill batch because R1's `updated_at`
 * is microseconds in the past when R2's statement evaluates `NOW()`.
 *
 * The strip MUST use `delete` (never assignment to `undefined`). enrich.ts
 * uses `'<field>' in artwork` as the witness for "LML decided" vs "cache
 * stripped"; the `in` operator still returns `true` for a key whose value
 * is `undefined`, so reassigning would silently break the contract and
 * re-introduce the cache-hit overwrite. See enrich.ts payload comment for
 * the full reasoning. Both classes documented at BS#1192 (apple_music_url
 * — `null` is load-bearing) and BS#1338 (the four search URLs — verified
 * deep-link would otherwise be replaced by R2's per-row synthesized
 * search URL).
 *
 * Stripping is required because every URL in this set is track-aware on
 * LML's side: the four search URLs are synthesized per (artist, track)
 * (BS#1185), and `apple_music_url` is per-track verified by LML's
 * `find_track_url` returning `/song/<id>` URLs. Caching them at the
 * album level and applying to a different track would surface a
 * mismatched query (search URLs) or, worse, a confidently-wrong
 * track-direct link (Apple Music).
 *
 * The non-stripped, album-level metadata is shared verbatim across rows
 * sharing the same (artist, album): `release_id`, `release_url`,
 * `artwork_url`, `release_year`, `artist_bio`, `wikipedia_url`. Caveat
 * acknowledged: caching on (artist, album) and applying to multiple
 * tracks accepts a small risk that LML's track-presence verification
 * would have returned a different release for a different track. For
 * the backfill's use case (album-level metadata for historical
 * flowsheet views), this is acceptable.
 */

import type { LookupResponse } from '@wxyc/lml-client';

import { log } from './logger.js';

const SIZE_WARN_THRESHOLD = 50_000;

const normalize = (s: string): string => s.trim().normalize('NFKC').toLowerCase();

const makeKey = (artist: string, album: string | null | undefined): string =>
  normalize(artist) + '\0' + normalize(album ?? '');

/**
 * Per-track URL fields deleted when reading from the cache. The four
 * search URLs (spotify/youtube_music/bandcamp/soundcloud) are
 * track-aware synthesized URLs (BS#1185); `apple_music_url` is
 * LML's per-track iTunes-verified URL (BS#1192). Both classes must
 * be regenerated per-row to avoid one track's URL leaking onto
 * another row sharing the same (artist, album).
 *
 * Fields are deleted (not reassigned to `undefined`) so downstream
 * consumers using `'field' in obj`, `Object.keys`, or `Object.assign`
 * see them as truly absent — matching JSON-serialization semantics.
 * `enrich.ts` relies on this for ALL FIVE track-aware URL columns
 * (apple_music_url + the four search URLs): it uses `'<field>' in
 * artwork` as the witness for "LML decided" vs "cache stripped" and
 * OMITS the column from both the album_metadata UPSERT (INSERT +
 * onConflictDoUpdate.set) and the inline unlinked flowsheet UPDATE on
 * stripped hits so a prior verified URL isn't clobbered via the
 * `updated_at < NOW()` setWhere guard. The strip MUST use `delete`;
 * assigning `undefined` would leave `'<field>' in artwork === true` and
 * silently break the contract — re-introducing R2's per-row
 * search-URL/null overwrite of R1's verified deep-link. See enrich.ts
 * payload comment for the full reasoning (BS#1192 + BS#1338).
 */
const TRACK_AWARE_URL_FIELDS = [
  'spotify_url',
  'youtube_music_url',
  'bandcamp_url',
  'soundcloud_url',
  'apple_music_url',
] as const;

type ArtworkBlock = NonNullable<LookupResponse['results'][number]['artwork']>;

const stripTrackAwareUrls = (response: LookupResponse): LookupResponse => ({
  ...response,
  results: response.results.map((item) => {
    if (!item.artwork) return { ...item };
    const stripped: ArtworkBlock = { ...item.artwork };
    for (const field of TRACK_AWARE_URL_FIELDS) {
      delete stripped[field];
    }
    return { ...item, artwork: stripped };
  }),
});

export class LookupCache {
  private readonly store = new Map<string, LookupResponse>();
  private hits = 0;
  private misses = 0;
  private overwrites = 0;
  private warnedOversize = false;

  get(artist: string, album?: string | null): LookupResponse | undefined {
    const key = makeKey(artist, album);
    const entry = this.store.get(key);
    if (entry === undefined) return undefined;
    this.hits += 1;
    return stripTrackAwareUrls(entry);
  }

  /**
   * Store a response and count the miss it represents. Misses are counted
   * here (not in `get()` on the not-found branch) so that an LML error
   * doesn't inflate `misses` — the caller must successfully fetch and
   * decide to store before the miss counts. `overwrites` tracks the
   * race-to-store case (two concurrent callers raced past `get()`, both
   * went to LML, both call `set()`); under today's sequential
   * orchestrator this is always zero, so any non-zero value signals a
   * concurrency regression.
   */
  set(artist: string, album: string | null | undefined, response: LookupResponse): void {
    const key = makeKey(artist, album);
    if (this.store.has(key)) {
      this.overwrites += 1;
    } else {
      this.misses += 1;
    }
    this.store.set(key, response);
    if (!this.warnedOversize && this.store.size > SIZE_WARN_THRESHOLD) {
      this.warnedOversize = true;
      log('warn', 'lookup_cache_oversize', `LookupCache size exceeded ${SIZE_WARN_THRESHOLD}`, {
        cache_size: this.store.size,
        threshold: SIZE_WARN_THRESHOLD,
      });
    }
  }

  stats(): { size: number; hits: number; misses: number; overwrites: number } {
    return { size: this.store.size, hits: this.hits, misses: this.misses, overwrites: this.overwrites };
  }
}

/**
 * Module-level singleton wired into `lml-fetch.ts`. Tests construct their
 * own `LookupCache` instance via `__setLookupCacheForTesting`; production
 * code reads via `getLookupCache()`. Importing this singleton directly
 * from a test is convention-discouraged but not lint-enforced — keep
 * cache-touching tests local to their own `LookupCache` instances.
 */
export const defaultLookupCache = new LookupCache();
